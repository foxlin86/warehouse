import { supabase } from './supabase';
import type {
  Profile,
  Product,
  Customer,
  Supplier,
  Warehouse,
  Shelf,
  Dictionary,
  InboundOrder,
  InboundOrderItem,
  OutboundOrder,
  OutboundOrderItem,
  TransferOrder,
  TransferOrderItem,
  SerialNumber,
  InventoryView,
  SyncLog,
  Version,
  SalesContract,
  Invoice,
  Application,
  TableConfig,
  FieldConfig,
  ViewConfig,
} from '@/types/database';

// ==================== Profiles ====================
export const getProfiles = async () => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const updateProfile = async (id: string, updates: Partial<Profile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

// ==================== Products ====================
export const getProducts = async () => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getProduct = async (id: string) => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const createProduct = async (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('products')
    .insert({
      ...product,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateProduct = async (id: string, updates: Partial<Product>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('products')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteProduct = async (id: string) => {
  // 1. 检查是否有库存
  const { data: inventory, error: invError } = await supabase
    .from('inventory')
    .select('id')
    .eq('product_id', id)
    .limit(1);
  
  if (invError) throw invError;
  if (inventory && inventory.length > 0) {
    throw new Error('该产品有库存记录,无法删除。请先清空库存。');
  }

  // 2. 检查是否有序列号
  const { data: serialNumbers, error: snError } = await supabase
    .from('serial_numbers')
    .select('id')
    .eq('product_id', id)
    .limit(1);
  
  if (snError) throw snError;
  if (serialNumbers && serialNumbers.length > 0) {
    throw new Error('该产品有序列号记录,无法删除。请先删除相关序列号。');
  }

  // 3. 执行删除
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Customers ====================
export const getCustomers = async () => {
  const { data, error } = await supabase
    .from('customers')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createCustomer = async (customer: Omit<Customer, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('customers')
    .insert({
      ...customer,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateCustomer = async (id: string, updates: Partial<Customer>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('customers')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteCustomer = async (id: string) => {
  // 1. 检查是否有出库单
  const { data: orders, error: ordersError } = await supabase
    .from('outbound_orders')
    .select('id')
    .eq('customer_id', id)
    .limit(1);
  
  if (ordersError) throw ordersError;
  if (orders && orders.length > 0) {
    throw new Error('该客户有出库单记录,无法删除。');
  }

  // 2. 检查是否有销售合同
  const { data: contracts, error: contractsError } = await supabase
    .from('sales_contracts')
    .select('id')
    .eq('customer_id', id)
    .limit(1);
  
  if (contractsError) throw contractsError;
  if (contracts && contracts.length > 0) {
    throw new Error('该客户有销售合同记录,无法删除。');
  }

  // 3. 执行删除
  const { error } = await supabase
    .from('customers')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Suppliers ====================
export const getSuppliers = async () => {
  const { data, error } = await supabase
    .from('suppliers')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createSupplier = async (supplier: Omit<Supplier, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('suppliers')
    .insert({
      ...supplier,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateSupplier = async (id: string, updates: Partial<Supplier>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('suppliers')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteSupplier = async (id: string) => {
  // 1. 检查是否有入库单
  const { data: orders, error: ordersError } = await supabase
    .from('inbound_orders')
    .select('id')
    .eq('supplier_id', id)
    .limit(1);
  
  if (ordersError) throw ordersError;
  if (orders && orders.length > 0) {
    throw new Error('该供应商有入库单记录,无法删除。');
  }

  // 2. 执行删除
  const { error } = await supabase
    .from('suppliers')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Warehouses ====================
export const getWarehouses = async () => {
  const { data, error } = await supabase
    .from('warehouses')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createWarehouse = async (warehouse: Omit<Warehouse, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('warehouses')
    .insert({
      ...warehouse,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateWarehouse = async (id: string, updates: Partial<Warehouse>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('warehouses')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteWarehouse = async (id: string) => {
  const { error } = await supabase
    .from('warehouses')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Shelves ====================
export const getShelves = async () => {
  const { data, error } = await supabase
    .from('shelves')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createShelf = async (shelf: Omit<Shelf, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('shelves')
    .insert({
      ...shelf,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateShelf = async (id: string, updates: Partial<Shelf>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('shelves')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteShelf = async (id: string) => {
  // 1. 检查是否有库存
  const { data: inventory, error: invError } = await supabase
    .from('inventory')
    .select('id')
    .eq('shelf_id', id)
    .limit(1);
  
  if (invError) throw invError;
  if (inventory && inventory.length > 0) {
    throw new Error('该货架有库存,无法删除。请先清空货架库存。');
  }

  // 2. 执行删除
  const { error } = await supabase
    .from('shelves')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Dictionaries ====================
export const getDictionaries = async (category?: string) => {
  let query = supabase
    .from('dictionaries')
    .select('*')
    .eq('is_active', true)
    .order('sort_order', { ascending: true });
  
  if (category) {
    query = query.eq('category', category);
  }
  
  const { data, error } = await query;
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// ==================== Inbound Orders ====================
export const getInboundOrders = async () => {
  const { data, error } = await supabase
    .from('inbound_orders')
    .select('*')
    .order('order_date', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getInboundOrder = async (id: string) => {
  const { data, error } = await supabase
    .from('inbound_orders')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const createInboundOrder = async (order: Omit<InboundOrder, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('inbound_orders')
    .insert({
      ...order,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateInboundOrder = async (id: string, updates: Partial<InboundOrder>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('inbound_orders')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const approveInboundOrder = async (id: string) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('inbound_orders')
    .update({
      status: 'approved',
      approved_at: new Date().toISOString(),
      approved_by: user?.id,
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteInboundOrder = async (id: string) => {
  const { error } = await supabase
    .from('inbound_orders')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Inbound Order Items ====================
export const getInboundOrderItems = async (orderId: string) => {
  const { data, error } = await supabase
    .from('inbound_order_items')
    .select(`
      *,
      products!inner(id, code, name),
      shelves!inner(id, name)
    `)
    .eq('inbound_order_id', orderId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data || []).map((item: any) => ({
    ...item,
    product_name: item.products?.name,
    product_code: item.products?.code,
    shelf_name: item.shelves?.name,
  }));
};

export const createInboundOrderItem = async (item: Omit<InboundOrderItem, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('inbound_order_items')
    .insert(item)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteInboundOrderItem = async (id: string) => {
  const { error } = await supabase
    .from('inbound_order_items')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Outbound Orders ====================
export const getOutboundOrders = async () => {
  const { data, error } = await supabase
    .from('outbound_orders')
    .select('*')
    .order('order_date', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getOutboundOrder = async (id: string) => {
  const { data, error } = await supabase
    .from('outbound_orders')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const createOutboundOrder = async (order: Omit<OutboundOrder, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('outbound_orders')
    .insert({
      ...order,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateOutboundOrder = async (id: string, updates: Partial<OutboundOrder>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('outbound_orders')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const approveOutboundOrder = async (id: string) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('outbound_orders')
    .update({
      status: 'approved',
      approved_at: new Date().toISOString(),
      approved_by: user?.id,
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteOutboundOrder = async (id: string) => {
  // 1. 获取出库明细
  const { data: items, error: itemsError } = await supabase
    .from('outbound_order_items')
    .select('id, serial_numbers_text')
    .eq('outbound_order_id', id);
  
  if (itemsError) throw itemsError;

  // 2. 恢复序列号状态
  if (items && items.length > 0) {
    for (const item of items) {
      if (item.serial_numbers_text) {
        const serialNumbers = item.serial_numbers_text.split(',').map((s: string) => s.trim()).filter(Boolean);
        if (serialNumbers.length > 0) {
          // 恢复序列号状态为在库
          const { error: snError } = await supabase
            .from('serial_numbers')
            .update({
              status: 'in_stock',
              outbound_order_item_id: null,
              updated_at: new Date().toISOString(),
            })
            .in('serial_number', serialNumbers);
          
          if (snError) throw snError;
        }
      }
    }
  }

  // 3. 删除出库单(级联删除明细)
  const { error } = await supabase
    .from('outbound_orders')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Outbound Order Items ====================
export const getOutboundOrderItems = async (orderId: string) => {
  const { data, error } = await supabase
    .from('outbound_order_items')
    .select(`
      *,
      products!inner(id, code, name),
      shelves!inner(id, name)
    `)
    .eq('outbound_order_id', orderId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data || []).map((item: any) => ({
    ...item,
    product_name: item.products?.name,
    product_code: item.products?.code,
    shelf_name: item.shelves?.name,
  }));
};

export const createOutboundOrderItem = async (item: Omit<OutboundOrderItem, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('outbound_order_items')
    .insert(item)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteOutboundOrderItem = async (id: string) => {
  const { error } = await supabase
    .from('outbound_order_items')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Transfer Orders ====================
export const getTransferOrders = async () => {
  const { data, error } = await supabase
    .from('transfer_orders')
    .select('*')
    .order('transfer_date', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getTransferOrder = async (id: string) => {
  const { data, error } = await supabase
    .from('transfer_orders')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const createTransferOrder = async (order: Omit<TransferOrder, 'id' | 'created_at' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('transfer_orders')
    .insert({
      ...order,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateTransferOrder = async (id: string, updates: Partial<TransferOrder>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('transfer_orders')
    .update({
      ...updates,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const approveTransferOrder = async (id: string) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('transfer_orders')
    .update({
      status: 'approved',
      approved_at: new Date().toISOString(),
      approved_by: user?.id,
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteTransferOrder = async (id: string) => {
  const { error } = await supabase
    .from('transfer_orders')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Transfer Order Items ====================
export const getTransferOrderItems = async (orderId: string) => {
  const { data, error } = await supabase
    .from('transfer_order_items')
    .select(`
      *,
      products!inner(id, code, name),
      from_shelves:shelves!transfer_order_items_from_shelf_id_fkey(id, name),
      to_shelves:shelves!transfer_order_items_to_shelf_id_fkey(id, name)
    `)
    .eq('transfer_order_id', orderId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data || []).map((item: any) => ({
    ...item,
    product_name: item.products?.name,
    product_code: item.products?.code,
    from_shelf_name: item.from_shelves?.name,
    to_shelf_name: item.to_shelves?.name,
  }));
};

export const createTransferOrderItem = async (item: Omit<TransferOrderItem, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('transfer_order_items')
    .insert(item)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteTransferOrderItem = async (id: string) => {
  const { error } = await supabase
    .from('transfer_order_items')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Serial Numbers ====================
export const getSerialNumbers = async () => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getSerialNumbersByProduct = async (productId: string) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .select('*')
    .eq('product_id', productId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getAvailableSerialNumbers = async (productId: string) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .select('*')
    .eq('product_id', productId)
    .eq('status', 'in_stock')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createSerialNumber = async (serialNumber: Omit<SerialNumber, 'id' | 'created_at' | 'updated_at'>) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .insert(serialNumber)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const bulkCreateSerialNumbers = async (serialNumbers: Omit<SerialNumber, 'id' | 'created_at' | 'updated_at'>[]) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .insert(serialNumbers)
    .select();
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const updateSerialNumber = async (id: string, updates: Partial<SerialNumber>) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateSerialNumbersByNumbers = async (serialNumbers: string[], updates: Partial<SerialNumber>) => {
  const { data, error } = await supabase
    .from('serial_numbers')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .in('serial_number', serialNumbers)
    .select();
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const deleteSerialNumber = async (id: string) => {
  // 检查序列号状态
  const { data: serialNumber, error: fetchError } = await supabase
    .from('serial_numbers')
    .select('status, serial_number')
    .eq('id', id)
    .single();
  
  if (fetchError) throw fetchError;
  
  // 只允许删除在库状态的序列号
  if (serialNumber.status !== 'in_stock') {
    throw new Error('只能删除在库状态的序列号');
  }
  
  const { error } = await supabase
    .from('serial_numbers')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Inventory View ====================
export const getInventory = async () => {
  const { data, error } = await supabase
    .from('inventory_view')
    .select('*')
    .order('product_code', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// ==================== Settings ====================
export const getSettings = async () => {
  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .order('setting_key', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getSetting = async (key: string) => {
  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .eq('setting_key', key)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateSetting = async (key: string, value: any) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('settings')
    .update({
      setting_value: value,
      updated_by: user?.id,
      updated_at: new Date().toISOString(),
    })
    .eq('setting_key', key)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

// ==================== Sync Logs ====================
export const getSyncLogs = async () => {
  const { data, error } = await supabase
    .from('sync_logs')
    .select('*')
    .order('started_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createSyncLog = async (log: Partial<SyncLog>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('sync_logs')
    .insert({
      ...log,
      created_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateSyncLog = async (id: string, updates: Partial<SyncLog>) => {
  const { data, error } = await supabase
    .from('sync_logs')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

// ==================== Versions ====================
export const getVersions = async () => {
  const { data, error } = await supabase
    .from('versions')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getVersion = async (id: string) => {
  const { data, error } = await supabase
    .from('versions')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const createVersion = async (version: Omit<Version, 'id' | 'created_at' | 'created_by'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('versions')
    .insert({
      ...version,
      created_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateVersion = async (id: string, updates: Partial<Version>) => {
  const { data, error } = await supabase
    .from('versions')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteVersion = async (id: string) => {
  const { error } = await supabase
    .from('versions')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Sales Contracts ====================
export const getSalesContracts = async () => {
  const { data, error } = await supabase
    .from('sales_contracts')
    .select('*, customers(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createSalesContract = async (contract: Omit<SalesContract, 'id' | 'created_at' | 'created_by' | 'updated_at' | 'updated_by'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('sales_contracts')
    .insert({
      ...contract,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateSalesContract = async (id: string, updates: Partial<SalesContract>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('sales_contracts')
    .update({
      ...updates,
      updated_by: user?.id,
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteSalesContract = async (id: string) => {
  const { error } = await supabase
    .from('sales_contracts')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Invoices ====================
export const getInvoices = async () => {
  const { data, error } = await supabase
    .from('invoices')
    .select('*, customers(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createInvoice = async (invoice: Omit<Invoice, 'id' | 'created_at' | 'created_by' | 'updated_at' | 'updated_by'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('invoices')
    .insert({
      ...invoice,
      created_by: user?.id,
      updated_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateInvoice = async (id: string, updates: Partial<Invoice>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('invoices')
    .update({
      ...updates,
      updated_by: user?.id,
    })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteInvoice = async (id: string) => {
  const { error } = await supabase
    .from('invoices')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// ==================== Field Config System ====================
// Applications
export const getApplications = async () => {
  const { data, error } = await supabase
    .from('applications')
    .select('*')
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// Table Configs
export const getTableConfigs = async (applicationId?: string) => {
  let query = supabase
    .from('table_configs')
    .select('*')
    .order('sort_order', { ascending: true });
  
  if (applicationId) {
    query = query.eq('application_id', applicationId);
  }
  
  const { data, error } = await query;
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getTableConfig = async (id: string) => {
  const { data, error } = await supabase
    .from('table_configs')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
};

// Field Configs
export const getFieldConfigs = async (tableConfigId: string) => {
  const { data, error } = await supabase
    .from('field_configs')
    .select('*')
    .eq('table_config_id', tableConfigId)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createFieldConfig = async (fieldConfig: Omit<FieldConfig, 'id' | 'created_at' | 'created_by' | 'updated_at'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('field_configs')
    .insert({
      ...fieldConfig,
      created_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateFieldConfig = async (id: string, updates: Partial<FieldConfig>) => {
  const { data, error } = await supabase
    .from('field_configs')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteFieldConfig = async (id: string) => {
  const { error } = await supabase
    .from('field_configs')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

// View Configs
export const getViewConfigs = async (tableConfigId: string) => {
  const { data, error } = await supabase
    .from('view_configs')
    .select('*')
    .eq('table_config_id', tableConfigId)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createViewConfig = async (viewConfig: Omit<ViewConfig, 'id' | 'created_at' | 'created_by'>) => {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from('view_configs')
    .insert({
      ...viewConfig,
      created_by: user?.id,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const updateViewConfig = async (id: string, updates: Partial<ViewConfig>) => {
  const { data, error } = await supabase
    .from('view_configs')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const deleteViewConfig = async (id: string) => {
  const { error } = await supabase
    .from('view_configs')
    .delete()
    .eq('id', id);
  if (error) throw error;
};

