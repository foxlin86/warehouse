import { Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ProductsPage from './pages/ProductsPage';
import CustomersPage from './pages/CustomersPage';
import SuppliersPage from './pages/SuppliersPage';
import WarehousesPage from './pages/WarehousesPage';
import InboundPage from './pages/InboundPage';
import InboundFormPage from './pages/InboundFormPage';
import OutboundPage from './pages/OutboundPage';
import OutboundFormPage from './pages/OutboundFormPage';
import TransferPage from './pages/TransferPage';
import TransferFormPage from './pages/TransferFormPage';
import SerialNumbersPage from './pages/SerialNumbersPage';
import InventoryPage from './pages/InventoryPage';
import SettingsPage from './pages/SettingsPage';
import MySQLSyncPage from './pages/MySQLSyncPage';
import VersionsPage from './pages/VersionsPage';
import FieldConfigPage from './pages/FieldConfigPage';
import DynamicFormDemoPage from './pages/DynamicFormDemoPage';
import InvoicesPage from './pages/InvoicesPage';
import SalesContractsPage from './pages/SalesContractsPage';
import AdminPage from './pages/AdminPage';
import AITextGeneratorPage from './pages/AITextGeneratorPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    visible: false,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <DashboardPage />,
  },
  {
    name: 'Products',
    path: '/products',
    element: <ProductsPage />,
  },
  {
    name: 'Customers',
    path: '/customers',
    element: <CustomersPage />,
  },
  {
    name: 'Suppliers',
    path: '/suppliers',
    element: <SuppliersPage />,
  },
  {
    name: 'Warehouses',
    path: '/warehouses',
    element: <WarehousesPage />,
  },
  {
    name: 'Inbound',
    path: '/inbound',
    element: <InboundPage />,
  },
  {
    name: 'InboundCreate',
    path: '/inbound/create',
    element: <InboundFormPage />,
    visible: false,
  },
  {
    name: 'InboundEdit',
    path: '/inbound/edit/:id',
    element: <InboundFormPage />,
    visible: false,
  },
  {
    name: 'Outbound',
    path: '/outbound',
    element: <OutboundPage />,
  },
  {
    name: 'OutboundCreate',
    path: '/outbound/create',
    element: <OutboundFormPage />,
    visible: false,
  },
  {
    name: 'OutboundEdit',
    path: '/outbound/edit/:id',
    element: <OutboundFormPage />,
    visible: false,
  },
  {
    name: 'Transfer',
    path: '/transfer',
    element: <TransferPage />,
  },
  {
    name: 'TransferCreate',
    path: '/transfer/create',
    element: <TransferFormPage />,
    visible: false,
  },
  {
    name: 'TransferEdit',
    path: '/transfer/edit/:id',
    element: <TransferFormPage />,
    visible: false,
  },
  {
    name: 'SerialNumbers',
    path: '/serial-numbers',
    element: <SerialNumbersPage />,
  },
  {
    name: 'Invoices',
    path: '/invoices',
    element: <InvoicesPage />,
  },
  {
    name: 'SalesContracts',
    path: '/sales-contracts',
    element: <SalesContractsPage />,
  },
  {
    name: 'Inventory',
    path: '/inventory',
    element: <InventoryPage />,
  },
  {
    name: 'Versions',
    path: '/versions',
    element: <VersionsPage />,
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <SettingsPage />,
  },
  {
    name: 'AITextGenerator',
    path: '/ai-text-generator',
    element: <AITextGeneratorPage />,
  },
  {
    name: 'FieldConfig',
    path: '/field-config',
    element: <FieldConfigPage />,
  },
  {
    name: 'DynamicFormDemo',
    path: '/dynamic-form-demo',
    element: <DynamicFormDemoPage />,
  },
  {
    name: 'MySQLSync',
    path: '/mysql-sync',
    element: <MySQLSyncPage />,
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <AdminPage />,
  },
  {
    name: 'Root',
    path: '/',
    element: <Navigate to="/dashboard" replace />,
    visible: false,
  },
];

export default routes;
