import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import type { FieldConfig } from '@/types/database';
import { FormControl, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

interface DynamicFieldProps {
  field: FieldConfig;
  value: any;
  onChange: (value: any) => void;
  error?: string;
}

export function DynamicField({ field, value, onChange, error }: DynamicFieldProps) {
  const renderField = () => {
    switch (field.field_type) {
      case 'text':
        if (field.options?.maxLength && field.options.maxLength > 100) {
          return (
            <Textarea
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              placeholder={field.description || `请输入${field.display_name}`}
              rows={3}
            />
          );
        }
        return (
          <Input
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.description || `请输入${field.display_name}`}
          />
        );

      case 'number':
        return (
          <Input
            type="number"
            value={value || ''}
            onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
            placeholder={field.description || `请输入${field.display_name}`}
            min={field.options?.min}
            max={field.options?.max}
            step={field.options?.precision ? Math.pow(10, -field.options.precision) : 1}
          />
        );

      case 'date':
        return (
          <Input
            type="date"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
          />
        );

      case 'datetime':
        return (
          <Input
            type="datetime-local"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
          />
        );

      case 'select':
        const selectChoices = field.options?.choices || [];
        return (
          <Select value={value || ''} onValueChange={onChange}>
            <SelectTrigger>
              <SelectValue placeholder={`请选择${field.display_name}`} />
            </SelectTrigger>
            <SelectContent>
              {selectChoices.map((choice: any) => (
                <SelectItem key={choice.value} value={choice.value}>
                  {choice.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'multi_select':
        const multiChoices = field.options?.choices || [];
        const selectedValues = Array.isArray(value) ? value : [];
        return (
          <div className="space-y-2">
            {multiChoices.map((choice: any) => (
              <div key={choice.value} className="flex items-center space-x-2">
                <Checkbox
                  checked={selectedValues.includes(choice.value)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      onChange([...selectedValues, choice.value]);
                    } else {
                      onChange(selectedValues.filter((v: string) => v !== choice.value));
                    }
                  }}
                />
                <label className="text-sm">{choice.label}</label>
              </div>
            ))}
          </div>
        );

      case 'checkbox':
        return (
          <Switch
            checked={!!value}
            onCheckedChange={onChange}
          />
        );

      case 'url':
        return (
          <Input
            type="url"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`请输入${field.display_name}`}
          />
        );

      case 'email':
        return (
          <Input
            type="email"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`请输入${field.display_name}`}
          />
        );

      case 'phone':
        return (
          <Input
            type="tel"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`请输入${field.display_name}`}
          />
        );

      case 'created_time':
      case 'updated_time':
        return (
          <Input
            value={value ? new Date(value).toLocaleString('zh-CN') : ''}
            disabled
            className="bg-muted"
          />
        );

      case 'created_by':
      case 'updated_by':
        return (
          <Input
            value={value || ''}
            disabled
            className="bg-muted"
          />
        );

      default:
        return (
          <Input
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`请输入${field.display_name}`}
          />
        );
    }
  };

  return (
    <FormItem>
      <FormLabel>
        {field.display_name}
        {field.is_required && <span className="text-destructive ml-1">*</span>}
      </FormLabel>
      <FormControl>
        {renderField()}
      </FormControl>
      {field.description && !error && (
        <p className="text-xs text-muted-foreground">{field.description}</p>
      )}
      {error && <FormMessage>{error}</FormMessage>}
    </FormItem>
  );
}

// 动态表单组件
interface DynamicFormProps {
  fields: FieldConfig[];
  values: Record<string, any>;
  onChange: (fieldName: string, value: any) => void;
  errors?: Record<string, string>;
}

export function DynamicForm({ fields, values, onChange, errors = {} }: DynamicFormProps) {
  // 过滤掉不可见和系统自动字段
  const visibleFields = fields.filter(
    (f) => f.is_visible && !['created_time', 'updated_time', 'created_by', 'updated_by'].includes(f.field_type)
  );

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
      {visibleFields.map((field) => (
        <div key={field.id} className={field.field_type === 'multi_select' ? 'xl:col-span-2' : ''}>
          <DynamicField
            field={field}
            value={values[field.field_name]}
            onChange={(value) => onChange(field.field_name, value)}
            error={errors[field.field_name]}
          />
        </div>
      ))}
    </div>
  );
}

// 验证函数
export function validateField(field: FieldConfig, value: any): string | null {
  // 必填验证
  if (field.is_required) {
    if (value === null || value === undefined || value === '') {
      return `${field.display_name}为必填项`;
    }
  }

  // 类型验证
  if (value !== null && value !== undefined && value !== '') {
    switch (field.field_type) {
      case 'number':
        if (isNaN(Number(value))) {
          return `${field.display_name}必须是数字`;
        }
        if (field.options?.min !== undefined && Number(value) < field.options.min) {
          return `${field.display_name}不能小于${field.options.min}`;
        }
        if (field.options?.max !== undefined && Number(value) > field.options.max) {
          return `${field.display_name}不能大于${field.options.max}`;
        }
        break;

      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          return `${field.display_name}格式不正确`;
        }
        break;

      case 'url':
        try {
          new URL(value);
        } catch {
          return `${field.display_name}格式不正确`;
        }
        break;

      case 'phone':
        const phoneRegex = /^1[3-9]\d{9}$/;
        if (!phoneRegex.test(value.replace(/\s|-/g, ''))) {
          return `${field.display_name}格式不正确`;
        }
        break;
    }
  }

  return null;
}

// 验证所有字段
export function validateFields(fields: FieldConfig[], values: Record<string, any>): Record<string, string> {
  const errors: Record<string, string> = {};

  fields.forEach((field) => {
    const error = validateField(field, values[field.field_name]);
    if (error) {
      errors[field.field_name] = error;
    }
  });

  return errors;
}
