import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Upload, Download, AlertCircle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { bulkCreateSerialNumbers } from '@/db/api';
import type { SerialNumber, Product } from '@/types/database';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface ImportSerialNumbersDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  products: Product[];
  onSuccess: () => void;
}

interface ImportResult {
  success: number;
  failed: number;
  errors: string[];
}

export function ImportSerialNumbersDialog({
  open,
  onOpenChange,
  products,
  onSuccess,
}: ImportSerialNumbersDialogProps) {
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const downloadTemplate = () => {
    // 创建模板数据
    const templateData = [
      {
        '序列号': 'SN001',
        '产品编号': products[0]?.code || 'P001',
        '型号': 'M001',
        '备注': '示例备注',
      },
      {
        '序列号': 'SN002',
        '产品编号': products[1]?.code || 'P002',
        '型号': 'M002',
        '备注': '示例备注',
      },
    ];

    // 创建工作簿
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '序列号模板');

    // 下载文件
    XLSX.writeFile(wb, '序列号导入模板.xlsx');
    toast.success('模板下载成功');
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // 检查文件类型
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast.error('请上传Excel文件(.xlsx或.xls)');
      return;
    }

    setImporting(true);
    setResult(null);

    try {
      // 读取文件
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

      if (jsonData.length === 0) {
        toast.error('Excel文件为空');
        setImporting(false);
        return;
      }

      // 验证和转换数据
      const serialNumbers: Omit<SerialNumber, 'id' | 'created_at' | 'updated_at'>[] = [];
      const errors: string[] = [];

      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i];
        const rowNum = i + 2; // Excel行号从2开始(第1行是表头)

        // 验证必填字段
        if (!row['序列号']) {
          errors.push(`第${rowNum}行: 序列号不能为空`);
          continue;
        }

        if (!row['产品编号']) {
          errors.push(`第${rowNum}行: 产品编号不能为空`);
          continue;
        }

        // 查找产品ID
        const product = products.find(p => p.code === row['产品编号']);
        if (!product) {
          errors.push(`第${rowNum}行: 找不到产品编号"${row['产品编号']}"`);
          continue;
        }

        // 构建序列号对象
        serialNumbers.push({
          serial_number: String(row['序列号']).trim(),
          product_id: product.id,
          product_model: row['型号'] ? String(row['型号']).trim() : undefined,
          product_name_text: product.name,
          product_code_text: product.code,
          current_style: '新品',
          status: 'in_stock',
          notes: row['备注'] ? String(row['备注']).trim() : undefined,
        });
      }

      // 如果有错误,显示错误信息
      if (errors.length > 0) {
        setResult({
          success: 0,
          failed: errors.length,
          errors: errors.slice(0, 10), // 只显示前10个错误
        });
        setImporting(false);
        return;
      }

      // 批量创建序列号
      try {
        await bulkCreateSerialNumbers(serialNumbers);
        setResult({
          success: serialNumbers.length,
          failed: 0,
          errors: [],
        });
        toast.success(`成功导入${serialNumbers.length}条序列号`);
        onSuccess();
      } catch (error: any) {
        // 处理数据库错误
        if (error.message.includes('duplicate key')) {
          errors.push('存在重复的序列号');
        } else {
          errors.push(error.message || '导入失败');
        }
        setResult({
          success: 0,
          failed: serialNumbers.length,
          errors,
        });
      }
    } catch (error: any) {
      toast.error(error.message || '文件解析失败');
    } finally {
      setImporting(false);
      // 清空文件选择
      event.target.value = '';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>批量导入序列号</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* 说明 */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <p>请按照以下步骤导入序列号:</p>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  <li>下载Excel模板</li>
                  <li>在模板中填写序列号数据</li>
                  <li>上传填写好的Excel文件</li>
                </ol>
                <p className="text-sm text-muted-foreground mt-2">
                  注意: 序列号和产品编号为必填项
                </p>
              </div>
            </AlertDescription>
          </Alert>

          {/* 操作按钮 */}
          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={downloadTemplate}
              className="flex-1"
            >
              <Download className="mr-2 h-4 w-4" />
              下载模板
            </Button>

            <Button
              variant="default"
              className="flex-1"
              disabled={importing}
              onClick={() => document.getElementById('file-upload')?.click()}
            >
              <Upload className="mr-2 h-4 w-4" />
              {importing ? '导入中...' : '上传文件'}
            </Button>

            <input
              id="file-upload"
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          {/* 导入结果 */}
          {result && (
            <Alert variant={result.failed > 0 ? 'destructive' : 'default'}>
              {result.failed > 0 ? (
                <AlertCircle className="h-4 w-4" />
              ) : (
                <CheckCircle className="h-4 w-4" />
              )}
              <AlertDescription>
                <div className="space-y-2">
                  <p className="font-semibold">
                    导入完成: 成功 {result.success} 条, 失败 {result.failed} 条
                  </p>
                  {result.errors.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-sm font-semibold">错误信息:</p>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        {result.errors.map((error, index) => (
                          <li key={index}>{error}</li>
                        ))}
                      </ul>
                      {result.failed > 10 && (
                        <p className="text-sm text-muted-foreground">
                          还有 {result.failed - 10} 个错误未显示
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Excel格式说明 */}
          <div className="border rounded-lg p-4 bg-muted/50">
            <h4 className="font-semibold mb-2">Excel格式说明</h4>
            <div className="space-y-2 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-medium">序列号</span>
                  <span className="text-destructive ml-1">*</span>
                </div>
                <div className="text-muted-foreground">唯一标识,不能重复</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-medium">产品编号</span>
                  <span className="text-destructive ml-1">*</span>
                </div>
                <div className="text-muted-foreground">必须是系统中已存在的产品编号</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-medium">型号</span>
                </div>
                <div className="text-muted-foreground">产品型号,可选</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-medium">备注</span>
                </div>
                <div className="text-muted-foreground">备注信息,可选</div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
