import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Sidebar,
  SidebarContent as SidebarContentUI,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import {
  LayoutDashboard,
  Package,
  Users,
  Warehouse,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
  Hash,
  Search,
  Settings,
  Settings2,
  Building2,
  Sparkles,
  Database,
  Tag,
  FileText,
} from 'lucide-react';

const menuItems = [
  {
    title: '仪表板',
    icon: LayoutDashboard,
    href: '/dashboard',
  },
  {
    title: '基础数据',
    items: [
      { title: '产品管理', icon: Package, href: '/products' },
      { title: '客户管理', icon: Users, href: '/customers' },
      { title: '供应商管理', icon: Building2, href: '/suppliers' },
      { title: '仓库货架', icon: Warehouse, href: '/warehouses' },
    ],
  },
  {
    title: '业务管理',
    items: [
      { title: '入库管理', icon: ArrowDownToLine, href: '/inbound' },
      { title: '出库管理', icon: ArrowUpFromLine, href: '/outbound' },
      { title: '调拨管理', icon: ArrowLeftRight, href: '/transfer' },
      { title: '序列号管理', icon: Hash, href: '/serial-numbers' },
      { title: '发票管理', icon: FileText, href: '/invoices' },
      { title: '合同管理', icon: FileText, href: '/sales-contracts' },
      { title: '版本管理', icon: Tag, href: '/versions' },
    ],
  },
  {
    title: '查询报表',
    items: [
      { title: '库存查询', icon: Search, href: '/inventory' },
    ],
  },
];

export function SidebarContent() {
  const location = useLocation();
  const { profile } = useAuth();

  return (
    <div className="flex h-full flex-col bg-sidebar">
      <div className="flex h-16 items-center border-b border-sidebar-border px-6">
        <Link to="/dashboard" className="flex items-center gap-2 font-semibold text-sidebar-foreground">
          <Package className="h-6 w-6" />
          <span>库存系统</span>
        </Link>
      </div>
      <div className="flex-1 overflow-auto py-4">
        <nav className="space-y-2 px-3">
          {menuItems.map((section, idx) => {
            if ('href' in section && section.href) {
              const isActive = location.pathname === section.href;
              const Icon = section.icon;
              return (
                <Link
                  key={section.href}
                  to={section.href}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                    isActive
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  {Icon && <Icon className="h-4 w-4" />}
                  {section.title}
                </Link>
              );
            }

            return (
              <div key={idx} className="space-y-1">
                <div className="px-3 py-2 text-xs font-semibold text-sidebar-foreground/70">
                  {section.title}
                </div>
                {section.items?.map((item) => {
                  const isActive = location.pathname === item.href;
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      to={item.href}
                      className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                        isActive
                          ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                          : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      {item.title}
                    </Link>
                  );
                })}
              </div>
            );
          })}

          {profile?.role === 'admin' && (
            <div className="space-y-1">
              <div className="px-3 py-2 text-xs font-semibold text-sidebar-foreground/70">
                系统管理
              </div>
              <Link
                to="/settings"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/settings'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Settings className="h-4 w-4" />
                系统设置
              </Link>
              <Link
                to="/ai-text-generator"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/ai-text-generator'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >{"AI库存查询"}</Link>
              <Link
                to="/field-config"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/field-config'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Settings2 className="h-4 w-4" />
                字段配置
              </Link>
              <Link
                to="/dynamic-form-demo"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/dynamic-form-demo'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Sparkles className="h-4 w-4" />
                动态表单演示
              </Link>
              <Link
                to="/mysql-sync"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/mysql-sync'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Database className="h-4 w-4" />
                MySQL同步
              </Link>
              <Link
                to="/admin"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  location.pathname === '/admin'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Users className="h-4 w-4" />
                用户管理
              </Link>
            </div>
          )}
        </nav>
      </div>
    </div>
  );
}

export function AppSidebar() {
  return (
    <Sidebar className="hidden xl:block">
      <SidebarContentUI>
        <SidebarContent />
      </SidebarContentUI>
    </Sidebar>
  );
}
