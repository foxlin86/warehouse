// 数据库类型定义

export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  username: string;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  specification?: string;
  unit?: string;
  manufacturer?: string;
  license_number?: string;
  registration_number?: string;
  default_shelf_id?: string;
  default_style?: string;
  storage_conditions?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface Customer {
  id: string;
  name: string;
  contact_person?: string;
  phone?: string;
  address?: string;
  category?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact_person?: string;
  phone?: string;
  address?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface Warehouse {
  id: string;
  code: string;
  name: string;
  location?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface Shelf {
  id: string;
  code: string;
  name: string;
  warehouse_id?: string;
  location?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface Dictionary {
  id: string;
  category: string;
  code: string;
  name: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
}

export type OrderStatus = 'draft' | 'approved';

export interface InboundOrder {
  id: string;
  order_number: string;
  order_type: string;
  supplier_id?: string;
  order_date: string;
  status: OrderStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
  approved_at?: string;
  approved_by?: string;
}

export interface InboundOrderItem {
  id: string;
  inbound_order_id: string;
  product_id: string;
  quantity: number;
  initial_quantity?: number;
  return_quantity?: number;
  batch_number?: string;
  production_date?: string;
  shelf_id: string;
  style: string;
  serial_numbers_text?: string;
  notes?: string;
  created_at: string;
}

export interface OutboundOrder {
  id: string;
  order_number: string;
  order_type: string;
  customer_id?: string;
  recipient?: string;
  order_date: string;
  version_id?: string;
  fill_id?: string;
  customer_name?: string;
  contact_name?: string;
  phone?: string;
  address?: string;
  express_number?: string;
  status: OrderStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
  approved_at?: string;
  approved_by?: string;
  versions?: Version;
}

export interface OutboundOrderItem {
  id: string;
  outbound_order_id: string;
  product_id: string;
  quantity: number;
  shelf_id: string;
  style: string;
  unit_price?: number;
  total_amount?: number;
  color?: string;
  product_type?: string;
  location?: string;
  serial_numbers_text?: string;
  production_batch?: string;
  production_date?: string;
  software_version?: string;
  manufacturer_registration?: string;
  batch_expiry_date?: string;
  storage_conditions?: string;
  version_id?: string;
  notes?: string;
  created_at: string;
}

export interface TransferOrder {
  id: string;
  order_number: string;
  transfer_date: string;
  status: OrderStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
  approved_at?: string;
  approved_by?: string;
}

export interface TransferOrderItem {
  id: string;
  transfer_order_id: string;
  product_id: string;
  quantity: number;
  from_shelf_id: string;
  to_shelf_id: string;
  from_style: string;
  to_style: string;
  notes?: string;
  created_at: string;
}

export interface SerialNumber {
  id: string;
  serial_number: string;
  product_id: string;
  product_model?: string;
  product_name_text?: string;
  product_code_text?: string;
  inbound_order_item_id?: string;
  outbound_order_item_id?: string;
  current_shelf_id?: string;
  current_style?: string;
  status: 'in_stock' | 'out_stock';
  notes?: string;
  created_at: string;
  updated_at: string;
}


export interface Version {
  id: string;
  version_number: string;
  version_name: string;
  atp_btps?: string;
  applicable_products?: string;
  version_time?: string;
  description?: string;
  release_date?: string;
  status: 'active' | 'archived';
  created_at: string;
  created_by?: string;
}

export interface SalesContract {
  id: string;
  contract_number: string;
  contract_name: string;
  customer_id?: string;
  customer_name?: string;
  contract_amount?: number;
  contract_date?: string;
  signing_date?: string;
  expiry_date?: string;
  file_url?: string;
  file_name?: string;
  status: 'active' | 'expired' | 'terminated';
  ocr_data?: any;
  notes?: string;
  created_at: string;
  created_by?: string;
  updated_at: string;
  updated_by?: string;
  customers?: Customer;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  invoice_type?: string;
  invoice_code?: string;
  customer_id?: string;
  customer_name?: string;
  invoice_amount?: number;
  tax_amount?: number;
  total_amount?: number;
  invoice_date?: string;
  file_url?: string;
  file_name?: string;
  status: 'valid' | 'invalid' | 'cancelled';
  ocr_data?: any;
  notes?: string;
  created_at: string;
  created_by?: string;
  updated_at: string;
  updated_by?: string;
  customers?: Customer;
}

// 字段配置系统类型
export type FieldType = 
  | 'text' 
  | 'number' 
  | 'date' 
  | 'datetime' 
  | 'select' 
  | 'multi_select' 
  | 'relation' 
  | 'attachment' 
  | 'checkbox' 
  | 'url' 
  | 'email' 
  | 'phone' 
  | 'formula' 
  | 'created_time' 
  | 'updated_time' 
  | 'created_by' 
  | 'updated_by';

export type ViewType = 'table' | 'kanban' | 'calendar' | 'gallery' | 'form';

export interface Application {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  color?: string;
  sort_order: number;
  created_at: string;
  created_by?: string;
  updated_at: string;
}

export interface TableConfig {
  id: string;
  application_id?: string;
  table_name: string;
  display_name: string;
  description?: string;
  icon?: string;
  sort_order: number;
  created_at: string;
  created_by?: string;
  updated_at: string;
}

export interface FieldConfig {
  id: string;
  table_config_id: string;
  field_name: string;
  display_name: string;
  field_type: FieldType;
  is_required: boolean;
  is_unique: boolean;
  is_primary: boolean;
  default_value?: string;
  options?: any; // 字段选项配置
  validation?: any; // 验证规则
  description?: string;
  sort_order: number;
  is_system: boolean;
  is_visible: boolean;
  width: number;
  created_at: string;
  created_by?: string;
  updated_at: string;
}

export interface ViewConfig {
  id: string;
  table_config_id: string;
  view_name: string;
  view_type: ViewType;
  is_default: boolean;
  config?: any; // 视图配置
  sort_order: number;
  created_at: string;
  created_by?: string;
  updated_at: string;
}

export interface InventoryView {
  product_id: string;
  product_code: string;
  product_name: string;
  shelf_id: string;
  shelf_code: string;
  shelf_name: string;
  style: string;
  total_inbound: number;
  total_outbound: number;
  current_stock: number;
}

export interface Setting {
  id: string;
  setting_key: string;
  setting_value: any;
  description?: string;
  created_at: string;
  updated_at: string;
  updated_by?: string;
}

export interface AIProvider {
  id: string;
  name: string;
  models: string[];
}

export interface AIConfig {
  provider: string;
  api_key: string;
  api_url: string;
  model: string;
}

export interface DatabaseConfig {
  host: string;
  port: string;
  database: string;
  username: string;
  password: string;
}

export interface MySQLConfig extends DatabaseConfig {
  enabled: boolean;
}

export interface SyncLog {
  id: string;
  sync_type: 'export' | 'import' | 'full_sync' | 'test_connection';
  status: 'success' | 'failed' | 'running';
  message?: string;
  details?: any;
  started_at: string;
  completed_at?: string;
  created_by?: string;
}
