import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';
import {
  getProducts,
  getShelves,
  getSuppliers,
  createInboundOrder,
  updateInboundOrder,
  getInboundOrder,
  getInboundOrderItems,
  createInboundOrderItem,
  deleteInboundOrderItem,
  deleteInboundOrder,
} from '@/db/api';
import type { Product, Shelf, Supplier, InboundOrderItem } from '@/types/database';

export default function InboundFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // 表单数据
  const [orderNumber, setOrderNumber] = useState('');
  const [orderType, setOrderType] = useState('采购入库');
  const [supplierId, setSupplierId] = useState('');
  const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<InboundOrderItem[]>([]);

  // 新增明细项
  const [newItem, setNewItem] = useState({
    product_id: '',
    quantity: '',
    batch_number: '',
    production_date: '',
    shelf_id: '',
    style: '新品',
    serial_numbers_text: '',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const [productsData, shelvesData, suppliersData] = await Promise.all([
        getProducts(),
        getShelves(),
        getSuppliers(),
      ]);
      setProducts(productsData);
      setShelves(shelvesData);
      setSuppliers(suppliersData);

      if (id) {
        const order = await getInboundOrder(id);
        if (order) {
          setOrderNumber(order.order_number);
          setOrderType(order.order_type);
          setSupplierId(order.supplier_id || '');
          setOrderDate(order.order_date);
          setNotes(order.notes || '');

          const itemsData = await getInboundOrderItems(id);
          setItems(itemsData);
        }
      } else {
        // 生成入库单号
        const timestamp = Date.now().toString().slice(-8);
        setOrderNumber(`IN${timestamp}`);
      }
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = () => {
    if (!newItem.product_id || !newItem.quantity || !newItem.shelf_id) {
      toast.error('请填写必填项');
      return;
    }

    const product = products.find((p) => p.id === newItem.product_id);
    const shelf = shelves.find((s) => s.id === newItem.shelf_id);

    if (!product || !shelf) return;

    const item: any = {
      id: `temp-${Date.now()}`,
      product_id: newItem.product_id,
      product_name: product.name,
      product_code: product.code,
      quantity: Number(newItem.quantity),
      batch_number: newItem.batch_number,
      production_date: newItem.production_date || null,
      shelf_id: newItem.shelf_id,
      shelf_name: shelf.name,
      style: newItem.style,
      serial_numbers_text: newItem.serial_numbers_text,
      notes: newItem.notes,
    };

    setItems([...items, item]);
    setNewItem({
      product_id: '',
      quantity: '',
      batch_number: '',
      production_date: '',
      shelf_id: '',
      style: '新品',
      serial_numbers_text: '',
      notes: '',
    });
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!orderNumber || items.length === 0) {
      toast.error('请填写入库单号并添加至少一条明细');
      return;
    }

    setSaving(true);
    try {
      let orderId = id;

      if (!orderId) {
        // 创建入库单
        const order = await createInboundOrder({
          order_number: orderNumber,
          order_type: orderType,
          supplier_id: supplierId && supplierId !== 'none' ? supplierId : undefined,
          order_date: orderDate,
          status: 'draft',
          notes: notes || undefined,
        });
        orderId = order?.id;
      } else {
        // 更新入库单
        await updateInboundOrder(orderId, {
          order_type: orderType,
          supplier_id: supplierId && supplierId !== 'none' ? supplierId : undefined,
          order_date: orderDate,
          notes: notes || undefined,
        });
      }

      if (!orderId) {
        throw new Error('创建入库单失败');
      }

      // 删除旧明细(如果是编辑模式)
      if (isEdit) {
        const oldItems = await getInboundOrderItems(orderId);
        for (const item of oldItems) {
          await deleteInboundOrderItem(item.id);
        }
      }

      // 添加新明细
      for (const item of items) {
        await createInboundOrderItem({
          inbound_order_id: orderId,
          product_id: item.product_id,
          quantity: item.quantity,
          batch_number: item.batch_number || undefined,
          production_date: item.production_date || undefined,
          shelf_id: item.shelf_id,
          style: item.style,
          notes: item.notes || undefined,
        });
      }

      toast.success(isEdit ? '入库单更新成功' : '入库单创建成功');
      navigate('/inbound');
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteClick = () => {
    if (!id) {
      toast.error('无法删除未保存的入库单');
      return;
    }
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!id) return;

    try {
      setDeleting(true);
      await deleteInboundOrder(id);
      toast.success('入库单删除成功');
      navigate('/inbound');
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/inbound')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">
            {isEdit ? '编辑入库单' : '创建入库单'}
          </h1>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-3">
            <div className="space-y-2">
              <Label>入库单号 *</Label>
              <Input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>入库类型 *</Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="采购入库">采购入库</SelectItem>
                  <SelectItem value="退货入库">退货入库</SelectItem>
                  <SelectItem value="调拨入库">调拨入库</SelectItem>
                  <SelectItem value="期初入库">期初入库</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>入库日期 *</Label>
              <Input type="date" value={orderDate} onChange={(e) => setOrderDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>供应商</Label>
              <Select value={supplierId} onValueChange={setSupplierId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择供应商" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无</SelectItem>
                  {suppliers.map((supplier) => (
                    <SelectItem key={supplier.id} value={supplier.id}>
                      {supplier.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 xl:col-span-2">
              <Label>备注</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="请输入备注"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>入库明细</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-7">
            <div className="space-y-2">
              <Label>产品 *</Label>
              <Select value={newItem.product_id} onValueChange={(v) => setNewItem({ ...newItem, product_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择产品" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>数量 *</Label>
              <Input
                type="number"
                value={newItem.quantity}
                onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
                placeholder="入库数量"
              />
            </div>
            <div className="space-y-2">
              <Label>货架 *</Label>
              <Select value={newItem.shelf_id} onValueChange={(v) => setNewItem({ ...newItem, shelf_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择货架" />
                </SelectTrigger>
                <SelectContent>
                  {shelves.map((shelf) => (
                    <SelectItem key={shelf.id} value={shelf.id}>
                      {shelf.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>样式 *</Label>
              <Select value={newItem.style} onValueChange={(v) => setNewItem({ ...newItem, style: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="新品">新品</SelectItem>
                  <SelectItem value="样机">样机</SelectItem>
                  <SelectItem value="损坏报废">损坏报废</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>批次号</Label>
              <Input
                value={newItem.batch_number}
                onChange={(e) => setNewItem({ ...newItem, batch_number: e.target.value })}
                placeholder="批次号"
              />
            </div>
            <div className="space-y-2">
              <Label>生产日期</Label>
              <Input
                type="date"
                value={newItem.production_date}
                onChange={(e) => setNewItem({ ...newItem, production_date: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>序列号</Label>
              <Input
                value={newItem.serial_numbers_text}
                onChange={(e) => setNewItem({ ...newItem, serial_numbers_text: e.target.value })}
                placeholder="多个序列号用逗号分隔"
              />
            </div>
            <div className="space-y-2">
              <Label>备注</Label>
              <Input
                value={newItem.notes}
                onChange={(e) => setNewItem({ ...newItem, notes: e.target.value })}
                placeholder="备注信息"
              />
            </div>
            <div className="space-y-2 flex items-end">
              <Button onClick={handleAddItem} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                添加
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>产品编号</TableHead>
                  <TableHead>产品名称</TableHead>
                  <TableHead>入库数量</TableHead>
                  <TableHead>货架</TableHead>
                  <TableHead>样式</TableHead>
                  <TableHead>批次号</TableHead>
                  <TableHead>生产日期</TableHead>
                  <TableHead>序列号</TableHead>
                  <TableHead>备注</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center text-muted-foreground">
                      暂无明细,请添加
                    </TableCell>
                  </TableRow>
                ) : (
                  items.map((item, index) => {
                    const product = products.find((p) => p.id === item.product_id);
                    const shelf = shelves.find((s) => s.id === item.shelf_id);
                    return (
                      <TableRow key={index}>
                        <TableCell>{product?.code}</TableCell>
                        <TableCell>{product?.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>{shelf?.name}</TableCell>
                        <TableCell>{item.style}</TableCell>
                        <TableCell>{item.batch_number || '-'}</TableCell>
                        <TableCell>
                          {item.production_date
                            ? new Date(item.production_date).toLocaleDateString()
                            : '-'}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{item.serial_numbers_text || '-'}</TableCell>
                        <TableCell className="max-w-xs truncate">{item.notes || '-'}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between gap-2">
        <div>
          {isEdit && (
            <Button 
              variant="destructive" 
              onClick={handleDeleteClick} 
              disabled={deleting || saving}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {deleting ? '删除中...' : '删除入库单'}
            </Button>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate('/inbound')}>
            取消
          </Button>
          <Button onClick={handleSave} disabled={saving || deleting}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </div>
      </div>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该入库单及其所有明细,请输入您的密码以确认"
      />
    </div>
  );
}
