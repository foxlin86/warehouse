import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Sparkles, Copy, Download, RotateCcw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  getInventory, 
  getInboundOrders, 
  getOutboundOrders, 
  getProducts,
  getCustomers,
  getSalesContracts,
  getInvoices 
} from '@/db/api';

type GenerateType = 'inventory_report' | 'inbound_analysis' | 'outbound_analysis' | 'product_description' | 'contract_content' | 'custom';

export default function AITextGeneratorPage() {
  const [generateType, setGenerateType] = useState<GenerateType>('inventory_report');
  const [prompt, setPrompt] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);
  const [contextData, setContextData] = useState<any>(null);

  // 模板提示词
  const templates = {
    inventory_report: '请根据以下库存数据生成一份详细的库存统计报告,包括总库存量、各产品库存分布、库存预警等关键信息。',
    inbound_analysis: '请根据以下入库数据生成入库分析报告,包括入库趋势、主要供应商、入库产品类型分布等。',
    outbound_analysis: '请根据以下出库数据生成出库分析报告,包括出库趋势、主要客户、出库产品类型分布等。',
    product_description: '请为以下产品生成专业的产品描述,包括产品特点、规格参数、适用场景等。',
    contract_content: '请根据以下信息生成销售合同内容,包括合同条款、双方权利义务、付款方式等。',
    custom: '请输入您的自定义需求...',
  };

  // 加载上下文数据
  const loadContextData = async (type: GenerateType) => {
    setDataLoading(true);
    try {
      let data: any = null;
      switch (type) {
        case 'inventory_report':
          data = await getInventory();
          break;
        case 'inbound_analysis':
          data = await getInboundOrders();
          break;
        case 'outbound_analysis':
          data = await getOutboundOrders();
          break;
        case 'product_description':
          data = await getProducts();
          break;
        case 'contract_content':
          const [contracts, customers] = await Promise.all([
            getSalesContracts(),
            getCustomers(),
          ]);
          data = { contracts, customers };
          break;
      }
      setContextData(data);
    } catch (error) {
      toast.error('加载数据失败');
    } finally {
      setDataLoading(false);
    }
  };

  useEffect(() => {
    if (generateType !== 'custom') {
      loadContextData(generateType);
    }
    setPrompt(templates[generateType]);
  }, [generateType]);

  // 生成统计摘要
  const generateDataSummary = () => {
    if (!contextData) return '';

    switch (generateType) {
      case 'inventory_report':
        const totalQuantity = contextData.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0);
        const productCount = contextData.length;
        return `\n\n数据摘要:\n- 产品种类: ${productCount}\n- 总库存量: ${totalQuantity}\n- 前5个产品: ${contextData.slice(0, 5).map((item: any) => `${item.product_name}(${item.quantity})`).join(', ')}`;
      
      case 'inbound_analysis':
        const inboundCount = contextData.length;
        const draftCount = contextData.filter((item: any) => item.status === 'draft').length;
        const approvedCount = contextData.filter((item: any) => item.status === 'approved').length;
        return `\n\n数据摘要:\n- 入库单总数: ${inboundCount}\n- 草稿: ${draftCount}\n- 已审核: ${approvedCount}`;
      
      case 'outbound_analysis':
        const outboundCount = contextData.length;
        const salesCount = contextData.filter((item: any) => item.order_type === '销售出库').length;
        const useCount = contextData.filter((item: any) => item.order_type === '领用出库').length;
        return `\n\n数据摘要:\n- 出库单总数: ${outboundCount}\n- 销售出库: ${salesCount}\n- 领用出库: ${useCount}`;
      
      case 'product_description':
        return `\n\n产品列表:\n${contextData.slice(0, 10).map((item: any, index: number) => `${index + 1}. ${item.name} - ${item.model || '无型号'}`).join('\n')}`;
      
      case 'contract_content':
        return `\n\n合同数量: ${contextData.contracts?.length || 0}\n客户数量: ${contextData.customers?.length || 0}`;
      
      default:
        return '';
    }
  };

  // 模拟AI生成(实际应该调用Edge Function)
  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('请输入生成需求');
      return;
    }

    setLoading(true);
    try {
      // 构建完整提示词
      const fullPrompt = prompt + generateDataSummary();
      
      // 模拟AI生成(实际项目中应该调用Supabase Edge Function)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 根据类型生成不同的示例文本
      let generatedContent = '';
      
      switch (generateType) {
        case 'inventory_report':
          generatedContent = `# 库存统计报告

## 一、总体概况
截至${new Date().toLocaleDateString()},系统共管理${contextData?.length || 0}种产品,总库存量为${contextData?.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0) || 0}件。

## 二、库存分布
${contextData?.slice(0, 5).map((item: any, index: number) => 
  `${index + 1}. **${item.product_name}**
   - 型号: ${item.product_model || '无'}
   - 库存数量: ${item.quantity || 0}
   - 货架位置: ${item.shelf_name || '未指定'}
   - 样式: ${item.style || '新品'}`
).join('\n\n') || '暂无数据'}

## 三、库存预警
- 低库存产品: ${contextData?.filter((item: any) => (item.quantity || 0) < 10).length || 0}种
- 零库存产品: ${contextData?.filter((item: any) => (item.quantity || 0) === 0).length || 0}种

## 四、建议
1. 对低库存产品及时补货
2. 优化库存结构,减少积压
3. 定期盘点,确保数据准确性`;
          break;

        case 'inbound_analysis':
          generatedContent = `# 入库分析报告

## 一、入库概况
本期共完成入库单${contextData?.length || 0}笔,其中已审核${contextData?.filter((item: any) => item.status === 'approved').length || 0}笔。

## 二、入库趋势
- 采购入库: ${contextData?.filter((item: any) => item.order_type === '采购入库').length || 0}笔
- 退货入库: ${contextData?.filter((item: any) => item.order_type === '退货入库').length || 0}笔
- 其他入库: ${contextData?.filter((item: any) => item.order_type === '其他入库').length || 0}笔

## 三、主要供应商
${contextData?.slice(0, 5).map((item: any, index: number) => 
  `${index + 1}. 入库单号: ${item.order_number} - ${item.order_type} - ${new Date(item.order_date).toLocaleDateString()}`
).join('\n') || '暂无数据'}

## 四、优化建议
1. 加强与主要供应商的合作关系
2. 优化入库流程,提高审核效率
3. 建立供应商评价体系`;
          break;

        case 'outbound_analysis':
          generatedContent = `# 出库分析报告

## 一、出库概况
本期共完成出库单${contextData?.length || 0}笔,其中销售出库${contextData?.filter((item: any) => item.order_type === '销售出库').length || 0}笔。

## 二、出库类型分布
- 销售出库: ${contextData?.filter((item: any) => item.order_type === '销售出库').length || 0}笔
- 领用出库: ${contextData?.filter((item: any) => item.order_type === '领用出库').length || 0}笔
- 报废出库: ${contextData?.filter((item: any) => item.order_type === '报废出库').length || 0}笔

## 三、出库明细
${contextData?.slice(0, 5).map((item: any, index: number) => 
  `${index + 1}. 出库单号: ${item.order_number} - ${item.order_type} - ${new Date(item.order_date).toLocaleDateString()}`
).join('\n') || '暂无数据'}

## 四、改进建议
1. 优化出库流程,提高效率
2. 加强客户关系管理
3. 分析销售数据,指导采购决策`;
          break;

        case 'product_description':
          const product = contextData?.[0];
          generatedContent = `# ${product?.name || '产品名称'}

## 产品概述
${product?.name || '产品名称'}是一款专业的医疗设备,具有高精度、高可靠性的特点,广泛应用于医疗机构。

## 规格参数
- 产品型号: ${product?.model || '标准型'}
- 产品编号: ${product?.code || 'N/A'}
- 单位: ${product?.unit || '台'}
- 分类: ${product?.category || '医疗设备'}

## 产品特点
1. **高精度**: 采用先进的传感技术,确保测量精度
2. **易操作**: 人性化设计,操作简单便捷
3. **高可靠**: 经过严格质量检测,性能稳定可靠
4. **多功能**: 集成多种功能,满足不同需求

## 适用场景
- 医院临床科室
- 体检中心
- 社区卫生服务中心
- 医疗研究机构

## 售后服务
提供完善的售后服务体系,包括安装调试、操作培训、定期维护等。`;
          break;

        case 'contract_content':
          generatedContent = `# 销售合同

## 甲方(卖方)
公司名称: [贵公司名称]
地址: [公司地址]
联系电话: [联系电话]

## 乙方(买方)
公司名称: ${contextData?.customers?.[0]?.name || '[客户名称]'}
地址: ${contextData?.customers?.[0]?.address || '[客户地址]'}
联系电话: ${contextData?.customers?.[0]?.phone || '[联系电话]'}

## 第一条 产品信息
根据《中华人民共和国合同法》及相关法律法规,甲乙双方在平等、自愿的基础上,就医疗设备销售事宜达成如下协议:

## 第二条 产品规格及数量
[详细列出产品名称、型号、数量、单价等]

## 第三条 合同金额
合同总金额: 人民币[金额]元整(¥[金额])

## 第四条 交货方式
1. 交货地点: [交货地点]
2. 交货时间: [交货时间]
3. 运输方式: [运输方式]
4. 运费承担: [运费承担方]

## 第五条 付款方式
1. 签订合同后[X]日内,乙方支付合同总额的[X]%作为预付款
2. 货物验收合格后[X]日内,乙方支付合同总额的[X]%
3. 质保期满后[X]日内,乙方支付剩余款项

## 第六条 质量保证
1. 甲方保证所售产品符合国家相关标准
2. 产品质保期为[X]年
3. 质保期内免费维修,质保期外提供有偿服务

## 第七条 违约责任
1. 任何一方违约,应承担违约责任
2. 违约金为合同总额的[X]%

## 第八条 争议解决
因本合同引起的争议,双方应友好协商解决;协商不成的,提交合同签订地人民法院诉讼解决。

## 第九条 其他约定
[其他需要约定的事项]

## 第十条 合同生效
本合同一式两份,甲乙双方各执一份,自双方签字盖章之日起生效。

甲方(盖章):                    乙方(盖章):
法定代表人:                    法定代表人:
日期:                          日期:`;
          break;

        case 'custom':
          generatedContent = `根据您的需求,我为您生成了以下内容:

${prompt}

[这里是AI生成的内容,实际使用时会调用真实的大模型API生成更准确的内容]

如需修改,请调整提示词后重新生成。`;
          break;
      }

      setGeneratedText(generatedContent);
      toast.success('生成成功');
    } catch (error: any) {
      toast.error(error.message || '生成失败');
    } finally {
      setLoading(false);
    }
  };

  // 复制到剪贴板
  const handleCopy = () => {
    navigator.clipboard.writeText(generatedText);
    toast.success('已复制到剪贴板');
  };

  // 下载为文本文件
  const handleDownload = () => {
    const blob = new Blob([generatedText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generateType}_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('下载成功');
  };

  // 重置
  const handleReset = () => {
    setGeneratedText('');
    setPrompt(templates[generateType]);
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl xl:text-3xl font-bold">AI文本生成</h1>
        <p className="text-muted-foreground">使用AI大模型生成库存报告、数据分析和文档内容</p>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {/* 左侧:输入区域 */}
        <Card>
          <CardHeader>
            <CardTitle>生成配置</CardTitle>
            <CardDescription>选择生成类型并输入需求</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>生成类型</Label>
              <Select value={generateType} onValueChange={(value) => setGenerateType(value as GenerateType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inventory_report">库存统计报告</SelectItem>
                  <SelectItem value="inbound_analysis">入库分析报告</SelectItem>
                  <SelectItem value="outbound_analysis">出库分析报告</SelectItem>
                  <SelectItem value="product_description">产品描述生成</SelectItem>
                  <SelectItem value="contract_content">合同内容生成</SelectItem>
                  <SelectItem value="custom">自定义生成</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>生成需求</Label>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="请输入您的生成需求..."
                rows={8}
                className="resize-none"
              />
            </div>

            {dataLoading && (
              <div className="space-y-2">
                <Skeleton className="h-4 bg-muted" />
                <Skeleton className="h-4 bg-muted w-3/4" />
              </div>
            )}

            {contextData && !dataLoading && generateType !== 'custom' && (
              <div className="p-3 bg-muted rounded-md text-sm">
                <p className="font-medium mb-1">数据已加载</p>
                <p className="text-muted-foreground">
                  {generateType === 'inventory_report' && `${contextData.length}种产品`}
                  {generateType === 'inbound_analysis' && `${contextData.length}条入库记录`}
                  {generateType === 'outbound_analysis' && `${contextData.length}条出库记录`}
                  {generateType === 'product_description' && `${contextData.length}个产品`}
                  {generateType === 'contract_content' && `${contextData.contracts?.length || 0}份合同`}
                </p>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleGenerate} disabled={loading} className="flex-1">
                <Sparkles className="w-4 h-4 mr-2" />
                {loading ? '生成中...' : '生成内容'}
              </Button>
              <Button onClick={handleReset} variant="outline" disabled={loading}>
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 右侧:输出区域 */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>生成结果</CardTitle>
                <CardDescription>AI生成的内容将显示在这里</CardDescription>
              </div>
              {generatedText && (
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={handleCopy}>
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleDownload}>
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 10 }).map((_, i) => (
                  <Skeleton key={i} className="h-4 bg-muted" />
                ))}
              </div>
            ) : generatedText ? (
              <div className="prose prose-sm max-w-none">
                <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-md overflow-auto max-h-[600px]">
                  {generatedText}
                </pre>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[400px] text-center text-muted-foreground">
                <Sparkles className="w-12 h-12 mb-4 opacity-50" />
                <p>点击"生成内容"按钮开始生成</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 使用说明 */}
      <Card>
        <CardHeader>
          <CardTitle>使用说明</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>1. <strong>库存统计报告</strong>: 自动分析当前库存数据,生成包含库存分布、预警信息的详细报告</p>
          <p>2. <strong>入库/出库分析</strong>: 分析入库或出库趋势,生成数据分析报告</p>
          <p>3. <strong>产品描述生成</strong>: 为产品生成专业的产品描述和规格说明</p>
          <p>4. <strong>合同内容生成</strong>: 根据客户和产品信息生成标准销售合同模板</p>
          <p>5. <strong>自定义生成</strong>: 输入自定义需求,AI将根据您的描述生成相应内容</p>
          <p className="mt-4 text-xs">
            <strong>注意</strong>: 当前为演示版本,实际使用时需要配置AI服务商API密钥(在系统设置中配置)
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
