import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';
import {
  getProducts,
  getShelves,
  createTransferOrder,
  updateTransferOrder,
  getTransferOrder,
  getTransferOrderItems,
  createTransferOrderItem,
  deleteTransferOrderItem,
  deleteTransferOrder,
  getInventory,
} from '@/db/api';
import type { Product, Shelf, TransferOrderItem } from '@/types/database';

export default function TransferFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [inventory, setInventory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // 表单数据
  const [orderNumber, setOrderNumber] = useState('');
  const [transferDate, setTransferDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<TransferOrderItem[]>([]);

  // 新增明细项
  const [newItem, setNewItem] = useState({
    product_id: '',
    quantity: '',
    from_shelf_id: '',
    to_shelf_id: '',
    from_style: '新品',
    to_style: '新品',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const [productsData, shelvesData, inventoryData] = await Promise.all([
        getProducts(),
        getShelves(),
        getInventory(),
      ]);
      setProducts(productsData);
      setShelves(shelvesData);
      setInventory(inventoryData);

      if (id) {
        const order = await getTransferOrder(id);
        if (order) {
          setOrderNumber(order.order_number);
          setTransferDate(order.transfer_date);
          setNotes(order.notes || '');

          const itemsData = await getTransferOrderItems(id);
          setItems(itemsData);
        }
      } else {
        // 生成调拨单号
        const timestamp = Date.now().toString().slice(-8);
        setOrderNumber(`TF${timestamp}`);
      }
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const getAvailableStock = (productId: string, shelfId: string, style: string) => {
    const item = inventory.find(
      (inv) =>
        inv.product_id === productId && inv.shelf_id === shelfId && inv.style === style
    );
    return item?.current_stock || 0;
  };

  const handleAddItem = () => {
    if (!newItem.product_id || !newItem.quantity || !newItem.from_shelf_id || !newItem.to_shelf_id) {
      toast.error('请填写必填项');
      return;
    }

    if (newItem.from_shelf_id === newItem.to_shelf_id && newItem.from_style === newItem.to_style) {
      toast.error('调出和调入的货架和样式不能完全相同');
      return;
    }

    const availableStock = getAvailableStock(newItem.product_id, newItem.from_shelf_id, newItem.from_style);
    if (Number(newItem.quantity) > availableStock) {
      toast.error(`库存不足,当前可用库存: ${availableStock}`);
      return;
    }

    const product = products.find((p) => p.id === newItem.product_id);
    const fromShelf = shelves.find((s) => s.id === newItem.from_shelf_id);
    const toShelf = shelves.find((s) => s.id === newItem.to_shelf_id);

    if (!product || !fromShelf || !toShelf) return;

    const item: any = {
      id: `temp-${Date.now()}`,
      product_id: newItem.product_id,
      product_name: product.name,
      product_code: product.code,
      quantity: Number(newItem.quantity),
      from_shelf_id: newItem.from_shelf_id,
      from_shelf_name: fromShelf.name,
      to_shelf_id: newItem.to_shelf_id,
      to_shelf_name: toShelf.name,
      from_style: newItem.from_style,
      to_style: newItem.to_style,
      notes: newItem.notes,
    };

    setItems([...items, item]);
    setNewItem({
      product_id: '',
      quantity: '',
      from_shelf_id: '',
      to_shelf_id: '',
      from_style: '新品',
      to_style: '新品',
      notes: '',
    });
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!orderNumber || items.length === 0) {
      toast.error('请填写调拨单号并添加至少一条明细');
      return;
    }

    setSaving(true);
    try {
      let orderId = id;

      if (!orderId) {
        // 创建调拨单
        const order = await createTransferOrder({
          order_number: orderNumber,
          transfer_date: transferDate,
          status: 'draft',
          notes: notes || undefined,
        });
        orderId = order?.id;
      } else {
        // 更新调拨单
        await updateTransferOrder(orderId, {
          transfer_date: transferDate,
          notes: notes || undefined,
        });
      }

      if (!orderId) {
        throw new Error('创建调拨单失败');
      }

      // 删除旧明细(如果是编辑模式)
      if (isEdit) {
        const oldItems = await getTransferOrderItems(orderId);
        for (const item of oldItems) {
          await deleteTransferOrderItem(item.id);
        }
      }

      // 添加新明细
      for (const item of items) {
        await createTransferOrderItem({
          transfer_order_id: orderId,
          product_id: item.product_id,
          quantity: item.quantity,
          from_shelf_id: item.from_shelf_id,
          to_shelf_id: item.to_shelf_id,
          from_style: item.from_style,
          to_style: item.to_style,
          notes: item.notes || undefined,
        });
      }

      toast.success(isEdit ? '调拨单更新成功' : '调拨单创建成功');
      navigate('/transfer');
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteClick = () => {
    if (!id) {
      toast.error('无法删除未保存的调拨单');
      return;
    }
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!id) return;

    try {
      setDeleting(true);
      await deleteTransferOrder(id);
      toast.success('调拨单删除成功');
      navigate('/transfer');
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/transfer')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">
            {isEdit ? '编辑调拨单' : '创建调拨单'}
          </h1>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-3">
            <div className="space-y-2">
              <Label>调拨单号 *</Label>
              <Input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>调拨日期 *</Label>
              <Input type="date" value={transferDate} onChange={(e) => setTransferDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>备注</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="请输入备注"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>调拨明细</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-7">
            <div className="space-y-2">
              <Label>产品 *</Label>
              <Select value={newItem.product_id} onValueChange={(v) => setNewItem({ ...newItem, product_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择产品" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>调出货架 *</Label>
              <Select value={newItem.from_shelf_id} onValueChange={(v) => setNewItem({ ...newItem, from_shelf_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择货架" />
                </SelectTrigger>
                <SelectContent>
                  {shelves.map((shelf) => (
                    <SelectItem key={shelf.id} value={shelf.id}>
                      {shelf.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>调出样式 *</Label>
              <Select value={newItem.from_style} onValueChange={(v) => setNewItem({ ...newItem, from_style: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="新品">新品</SelectItem>
                  <SelectItem value="样机">样机</SelectItem>
                  <SelectItem value="损坏报废">损坏报废</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>调入货架 *</Label>
              <Select value={newItem.to_shelf_id} onValueChange={(v) => setNewItem({ ...newItem, to_shelf_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择货架" />
                </SelectTrigger>
                <SelectContent>
                  {shelves.map((shelf) => (
                    <SelectItem key={shelf.id} value={shelf.id}>
                      {shelf.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>调入样式 *</Label>
              <Select value={newItem.to_style} onValueChange={(v) => setNewItem({ ...newItem, to_style: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="新品">新品</SelectItem>
                  <SelectItem value="样机">样机</SelectItem>
                  <SelectItem value="损坏报废">损坏报废</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>数量 *</Label>
              <Input
                type="number"
                value={newItem.quantity}
                onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
                placeholder="数量"
              />
              {newItem.product_id && newItem.from_shelf_id && (
                <p className="text-xs text-muted-foreground">
                  可用: {getAvailableStock(newItem.product_id, newItem.from_shelf_id, newItem.from_style)}
                </p>
              )}
            </div>
            <div className="space-y-2 flex items-end">
              <Button onClick={handleAddItem} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                添加
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>产品编号</TableHead>
                  <TableHead>产品名称</TableHead>
                  <TableHead>数量</TableHead>
                  <TableHead>调出货架</TableHead>
                  <TableHead>调出样式</TableHead>
                  <TableHead>调入货架</TableHead>
                  <TableHead>调入样式</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      暂无明细,请添加
                    </TableCell>
                  </TableRow>
                ) : (
                  items.map((item, index) => {
                    const product = products.find((p) => p.id === item.product_id);
                    const fromShelf = shelves.find((s) => s.id === item.from_shelf_id);
                    const toShelf = shelves.find((s) => s.id === item.to_shelf_id);
                    return (
                      <TableRow key={index}>
                        <TableCell>{product?.code}</TableCell>
                        <TableCell>{product?.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>{fromShelf?.name}</TableCell>
                        <TableCell>{item.from_style}</TableCell>
                        <TableCell>{toShelf?.name}</TableCell>
                        <TableCell>{item.to_style}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between gap-2">
        <div>
          {isEdit && (
            <Button 
              variant="destructive" 
              onClick={handleDeleteClick} 
              disabled={deleting || saving}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {deleting ? '删除中...' : '删除调拨单'}
            </Button>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate('/transfer')}>
            取消
          </Button>
          <Button onClick={handleSave} disabled={saving || deleting}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </div>
      </div>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该调拨单及其所有明细,请输入您的密码以确认"
      />
    </div>
  );
}
