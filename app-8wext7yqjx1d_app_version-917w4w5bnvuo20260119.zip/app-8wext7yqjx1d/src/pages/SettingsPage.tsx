import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { getSetting, updateSetting } from '@/db/api';
import type { AIConfig, DatabaseConfig, AIProvider } from '@/types/database';
import { Skeleton } from '@/components/ui/skeleton';
import { Database, Brain, Save } from 'lucide-react';

export default function SettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // 数据库配置
  const [dbConfig, setDbConfig] = useState<DatabaseConfig>({
    host: '',
    port: '',
    database: '',
    username: '',
    password: '',
  });

  // AI配置
  const [aiConfig, setAiConfig] = useState<AIConfig>({
    provider: 'bailian',
    api_key: '',
    api_url: '',
    model: 'qwen-max',
  });

  // AI服务商列表
  const [aiProviders, setAiProviders] = useState<AIProvider[]>([]);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const [dbSetting, aiSetting, providersSetting] = await Promise.all([
        getSetting('database_config'),
        getSetting('ai_config'),
        getSetting('ai_providers'),
      ]);

      if (dbSetting) {
        setDbConfig(dbSetting.setting_value);
      }
      if (aiSetting) {
        setAiConfig(aiSetting.setting_value);
      }
      if (providersSetting) {
        setAiProviders(providersSetting.setting_value);
      }
    } catch (error) {
      toast.error('获取设置失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveDbConfig = async () => {
    setSaving(true);
    try {
      await updateSetting('database_config', dbConfig);
      toast.success('数据库配置保存成功');
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAiConfig = async () => {
    setSaving(true);
    try {
      await updateSetting('ai_config', aiConfig);
      toast.success('AI配置保存成功');
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const currentProvider = aiProviders.find((p) => p.id === aiConfig.provider);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold xl:text-3xl">系统设置</h1>
        <p className="text-muted-foreground">配置数据库连接和AI模型</p>
      </div>

      <Tabs defaultValue="ai" className="w-full">
        <TabsList className="grid w-full grid-cols-2 xl:w-96">
          <TabsTrigger value="ai">
            <Brain className="mr-2 h-4 w-4" />
            AI配置
          </TabsTrigger>
          <TabsTrigger value="database">
            <Database className="mr-2 h-4 w-4" />
            数据库配置
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ai" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI模型配置</CardTitle>
              <CardDescription>
                配置AI服务商和API密钥,用于智能分析库存数据
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 xl:grid-cols-2">
                <div className="space-y-2">
                  <Label>AI服务商</Label>
                  <Select
                    value={aiConfig.provider}
                    onValueChange={(value) => {
                      const provider = aiProviders.find((p) => p.id === value);
                      setAiConfig({
                        ...aiConfig,
                        provider: value,
                        model: provider?.models[0] || '',
                      });
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {aiProviders.map((provider) => (
                        <SelectItem key={provider.id} value={provider.id}>
                          {provider.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>模型</Label>
                  <Select
                    value={aiConfig.model}
                    onValueChange={(value) => setAiConfig({ ...aiConfig, model: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currentProvider?.models.map((model) => (
                        <SelectItem key={model} value={model}>
                          {model}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 xl:col-span-2">
                  <Label>API密钥 {aiConfig.provider === 'ollama' && <span className="text-muted-foreground">(Ollama无需密钥)</span>}</Label>
                  <Input
                    type="password"
                    value={aiConfig.api_key}
                    onChange={(e) => setAiConfig({ ...aiConfig, api_key: e.target.value })}
                    placeholder={aiConfig.provider === 'ollama' ? '本地模型无需API密钥' : '请输入API密钥'}
                    disabled={aiConfig.provider === 'ollama'}
                  />
                </div>

                <div className="space-y-2 xl:col-span-2">
                  <Label>API地址 {aiConfig.provider === 'ollama' && <span className="text-muted-foreground">(默认: http://localhost:11434/api/chat)</span>}</Label>
                  <Input
                    value={aiConfig.api_url}
                    onChange={(e) => setAiConfig({ ...aiConfig, api_url: e.target.value })}
                    placeholder={
                      aiConfig.provider === 'ollama' 
                        ? 'http://localhost:11434/api/chat' 
                        : '请输入API地址(可选,使用默认地址)'
                    }
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSaveAiConfig} disabled={saving}>
                  <Save className="mr-2 h-4 w-4" />
                  {saving ? '保存中...' : '保存配置'}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>配置说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>• <strong>百度AI(文心一言)</strong>: 百度智能云平台,需要在百度智能云获取Access Token</p>
              <p>• <strong>百炼大模型</strong>: 阿里云百炼平台,需要在阿里云控制台获取API密钥</p>
              <p>• <strong>DeepSeek</strong>: DeepSeek AI平台,支持本地部署和云端调用</p>
              <p>• <strong>OpenAI</strong>: OpenAI官方API,需要OpenAI账号和API密钥</p>
              <p>• <strong>Ollama本地模型</strong>: 本地部署的开源大模型,无需API密钥,默认地址 http://localhost:11434/api/chat</p>
              <p>• <strong>自定义API</strong>: 支持任何兼容OpenAI格式的API接口</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>数据库连接配置</CardTitle>
              <CardDescription>
                配置外部数据库连接(可选),用于数据同步和备份
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 xl:grid-cols-2">
                <div className="space-y-2">
                  <Label>主机地址</Label>
                  <Input
                    value={dbConfig.host}
                    onChange={(e) => setDbConfig({ ...dbConfig, host: e.target.value })}
                    placeholder="例如: localhost 或 192.168.1.100"
                  />
                </div>

                <div className="space-y-2">
                  <Label>端口</Label>
                  <Input
                    value={dbConfig.port}
                    onChange={(e) => setDbConfig({ ...dbConfig, port: e.target.value })}
                    placeholder="例如: 5432"
                  />
                </div>

                <div className="space-y-2">
                  <Label>数据库名称</Label>
                  <Input
                    value={dbConfig.database}
                    onChange={(e) => setDbConfig({ ...dbConfig, database: e.target.value })}
                    placeholder="请输入数据库名称"
                  />
                </div>

                <div className="space-y-2">
                  <Label>用户名</Label>
                  <Input
                    value={dbConfig.username}
                    onChange={(e) => setDbConfig({ ...dbConfig, username: e.target.value })}
                    placeholder="请输入数据库用户名"
                  />
                </div>

                <div className="space-y-2 xl:col-span-2">
                  <Label>密码</Label>
                  <Input
                    type="password"
                    value={dbConfig.password}
                    onChange={(e) => setDbConfig({ ...dbConfig, password: e.target.value })}
                    placeholder="请输入数据库密码"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSaveDbConfig} disabled={saving}>
                  <Save className="mr-2 h-4 w-4" />
                  {saving ? '保存中...' : '保存配置'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
