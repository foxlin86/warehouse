import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Pencil, Trash2, Settings2, Eye, EyeOff, ChevronDown, ChevronUp } from 'lucide-react';
import { getTableConfigs, getFieldConfigs, createFieldConfig, updateFieldConfig, deleteFieldConfig } from '@/db/api';
import type { TableConfig, FieldConfig, FieldType } from '@/types/database';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

const fieldTypeOptions: { value: FieldType; label: string }[] = [
  { value: 'text', label: '文本' },
  { value: 'number', label: '数字' },
  { value: 'date', label: '日期' },
  { value: 'datetime', label: '日期时间' },
  { value: 'select', label: '单选' },
  { value: 'multi_select', label: '多选' },
  { value: 'relation', label: '关联' },
  { value: 'attachment', label: '附件' },
  { value: 'checkbox', label: '复选框' },
  { value: 'url', label: '链接' },
  { value: 'email', label: '邮箱' },
  { value: 'phone', label: '电话' },
  { value: 'formula', label: '公式' },
  { value: 'created_time', label: '创建时间' },
  { value: 'updated_time', label: '修改时间' },
  { value: 'created_by', label: '创建人' },
  { value: 'updated_by', label: '修改人' },
];

export default function FieldConfigPage() {
  const [tables, setTables] = useState<TableConfig[]>([]);
  const [selectedTable, setSelectedTable] = useState<TableConfig | null>(null);
  const [fields, setFields] = useState<FieldConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingField, setEditingField] = useState<FieldConfig | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [fieldToDelete, setFieldToDelete] = useState<FieldConfig | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectOptions, setSelectOptions] = useState<string>('');
  const [relationConfig, setRelationConfig] = useState({ table: '', display_field: '', value_field: '' });
  const [numberConfig, setNumberConfig] = useState({ min: '', max: '', precision: '' });

  const form = useForm({
    defaultValues: {
      field_name: '',
      display_name: '',
      field_type: 'text' as FieldType,
      is_required: false,
      is_unique: false,
      is_primary: false,
      default_value: '',
      description: '',
      sort_order: 0,
      is_visible: true,
      width: 150,
    },
  });

  const fetchTables = async () => {
    try {
      const data = await getTableConfigs();
      setTables(data);
      if (data.length > 0 && !selectedTable) {
        setSelectedTable(data[0]);
      }
    } catch (error) {
      toast.error('获取表格配置失败');
    }
  };

  const fetchFields = async (tableId: string) => {
    try {
      setLoading(true);
      const data = await getFieldConfigs(tableId);
      setFields(data);
    } catch (error) {
      toast.error('获取字段配置失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTables();
  }, []);

  useEffect(() => {
    if (selectedTable) {
      fetchFields(selectedTable.id);
    }
  }, [selectedTable]);

  const handleSubmit = async (values: any) => {
    if (!selectedTable) return;

    try {
      // 构建options配置
      let options: any = null;
      if (values.field_type === 'select' || values.field_type === 'multi_select') {
        if (selectOptions.trim()) {
          const choices = selectOptions.split('\n').filter(line => line.trim()).map((line, index) => {
            const [value, label] = line.split('|').map(s => s.trim());
            return {
              value: value || `option_${index + 1}`,
              label: label || value || `选项${index + 1}`,
              color: '#3b82f6'
            };
          });
          options = { choices };
        }
      } else if (values.field_type === 'relation') {
        if (relationConfig.table) {
          options = relationConfig;
        }
      } else if (values.field_type === 'number') {
        if (numberConfig.min || numberConfig.max || numberConfig.precision) {
          options = {
            min: numberConfig.min ? Number(numberConfig.min) : undefined,
            max: numberConfig.max ? Number(numberConfig.max) : undefined,
            precision: numberConfig.precision ? Number(numberConfig.precision) : undefined,
          };
        }
      }

      const fieldData = {
        ...values,
        table_config_id: selectedTable.id,
        sort_order: Number(values.sort_order),
        width: Number(values.width),
        options,
      };

      if (editingField) {
        await updateFieldConfig(editingField.id, fieldData);
        toast.success('字段更新成功');
      } else {
        await createFieldConfig(fieldData);
        toast.success('字段创建成功');
      }
      setDialogOpen(false);
      form.reset();
      setEditingField(null);
      setSelectOptions('');
      setRelationConfig({ table: '', display_field: '', value_field: '' });
      setNumberConfig({ min: '', max: '', precision: '' });
      setShowAdvanced(false);
      fetchFields(selectedTable.id);
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleEdit = (field: FieldConfig) => {
    setEditingField(field);
    form.reset({
      field_name: field.field_name,
      display_name: field.display_name,
      field_type: field.field_type,
      is_required: field.is_required,
      is_unique: field.is_unique,
      is_primary: field.is_primary,
      default_value: field.default_value || '',
      description: field.description || '',
      sort_order: field.sort_order,
      is_visible: field.is_visible,
      width: field.width,
    });

    // 加载选项配置
    if (field.options) {
      if (field.field_type === 'select' || field.field_type === 'multi_select') {
        const choices = field.options.choices || [];
        setSelectOptions(choices.map((c: any) => `${c.value}|${c.label}`).join('\n'));
        setShowAdvanced(true);
      } else if (field.field_type === 'relation') {
        setRelationConfig(field.options);
        setShowAdvanced(true);
      } else if (field.field_type === 'number') {
        setNumberConfig({
          min: field.options.min?.toString() || '',
          max: field.options.max?.toString() || '',
          precision: field.options.precision?.toString() || '',
        });
        setShowAdvanced(true);
      }
    } else {
      setSelectOptions('');
      setRelationConfig({ table: '', display_field: '', value_field: '' });
      setNumberConfig({ min: '', max: '', precision: '' });
      setShowAdvanced(false);
    }

    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!fieldToDelete) return;
    try {
      await deleteFieldConfig(fieldToDelete.id);
      toast.success('字段删除成功');
      setDeleteDialogOpen(false);
      setFieldToDelete(null);
      if (selectedTable) {
        fetchFields(selectedTable.id);
      }
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    }
  };

  const toggleVisibility = async (field: FieldConfig) => {
    try {
      await updateFieldConfig(field.id, { is_visible: !field.is_visible });
      toast.success('字段可见性已更新');
      if (selectedTable) {
        fetchFields(selectedTable.id);
      }
    } catch (error: any) {
      toast.error(error.message || '更新失败');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl xl:text-3xl font-bold">字段配置管理</h1>
      </div>

      <Tabs value={selectedTable?.id} onValueChange={(value) => {
        const table = tables.find(t => t.id === value);
        if (table) setSelectedTable(table);
      }}>
        <TabsList>
          {tables.map((table) => (
            <TabsTrigger key={table.id} value={table.id}>
              {table.icon} {table.display_name}
            </TabsTrigger>
          ))}
        </TabsList>

        {tables.map((table) => (
          <TabsContent key={table.id} value={table.id}>
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{table.display_name} - 字段配置</CardTitle>
                  <Dialog open={dialogOpen} onOpenChange={(open) => {
                    setDialogOpen(open);
                    if (!open) {
                      form.reset();
                      setEditingField(null);
                    }
                  }}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        新增字段
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{editingField ? '编辑字段' : '新增字段'}</DialogTitle>
                      </DialogHeader>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="field_name"
                              rules={{ required: '请输入字段名称' }}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>字段名称(英文) *</FormLabel>
                                  <FormControl>
                                    <Input {...field} placeholder="如: product_code" disabled={!!editingField} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="display_name"
                              rules={{ required: '请输入显示名称' }}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>显示名称 *</FormLabel>
                                  <FormControl>
                                    <Input {...field} placeholder="如: 产品编号" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="field_type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>字段类型 *</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      {fieldTypeOptions.map((option) => (
                                        <SelectItem key={option.value} value={option.value}>
                                          {option.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="width"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>列宽(px)</FormLabel>
                                  <FormControl>
                                    <Input {...field} type="number" placeholder="150" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="sort_order"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>排序</FormLabel>
                                  <FormControl>
                                    <Input {...field} type="number" placeholder="0" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="default_value"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>默认值</FormLabel>
                                  <FormControl>
                                    <Input {...field} placeholder="默认值" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>字段说明</FormLabel>
                                <FormControl>
                                  <Textarea {...field} placeholder="字段说明" rows={2} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
                            <FormField
                              control={form.control}
                              name="is_required"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between space-y-0">
                                  <FormLabel>必填</FormLabel>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="is_unique"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between space-y-0">
                                  <FormLabel>唯一</FormLabel>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="is_primary"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between space-y-0">
                                  <FormLabel>主字段</FormLabel>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="is_visible"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between space-y-0">
                                  <FormLabel>可见</FormLabel>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>

                          {/* 高级选项配置 */}
                          <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                            <CollapsibleTrigger asChild>
                              <Button type="button" variant="outline" className="w-full">
                                {showAdvanced ? <ChevronUp className="w-4 h-4 mr-2" /> : <ChevronDown className="w-4 h-4 mr-2" />}
                                高级选项配置
                              </Button>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="space-y-4 mt-4">
                              {(form.watch('field_type') === 'select' || form.watch('field_type') === 'multi_select') && (
                                <div className="space-y-2">
                                  <label className="text-sm font-medium">选项配置</label>
                                  <Textarea
                                    value={selectOptions}
                                    onChange={(e) => setSelectOptions(e.target.value)}
                                    placeholder="每行一个选项,格式: 值|标签&#10;例如:&#10;new|新品&#10;used|样机&#10;damaged|损坏报废"
                                    rows={5}
                                  />
                                  <p className="text-xs text-muted-foreground">
                                    每行一个选项,使用 | 分隔值和标签。例如: new|新品
                                  </p>
                                </div>
                              )}

                              {form.watch('field_type') === 'relation' && (
                                <div className="space-y-4">
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">关联表</label>
                                    <Input
                                      value={relationConfig.table}
                                      onChange={(e) => setRelationConfig({ ...relationConfig, table: e.target.value })}
                                      placeholder="例如: products"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">显示字段</label>
                                    <Input
                                      value={relationConfig.display_field}
                                      onChange={(e) => setRelationConfig({ ...relationConfig, display_field: e.target.value })}
                                      placeholder="例如: name"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">值字段</label>
                                    <Input
                                      value={relationConfig.value_field}
                                      onChange={(e) => setRelationConfig({ ...relationConfig, value_field: e.target.value })}
                                      placeholder="例如: id"
                                    />
                                  </div>
                                </div>
                              )}

                              {form.watch('field_type') === 'number' && (
                                <div className="grid grid-cols-3 gap-4">
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">最小值</label>
                                    <Input
                                      type="number"
                                      value={numberConfig.min}
                                      onChange={(e) => setNumberConfig({ ...numberConfig, min: e.target.value })}
                                      placeholder="最小值"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">最大值</label>
                                    <Input
                                      type="number"
                                      value={numberConfig.max}
                                      onChange={(e) => setNumberConfig({ ...numberConfig, max: e.target.value })}
                                      placeholder="最大值"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">小数位数</label>
                                    <Input
                                      type="number"
                                      value={numberConfig.precision}
                                      onChange={(e) => setNumberConfig({ ...numberConfig, precision: e.target.value })}
                                      placeholder="小数位"
                                    />
                                  </div>
                                </div>
                              )}
                            </CollapsibleContent>
                          </Collapsible>

                          <div className="flex justify-end gap-2">
                            <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                              取消
                            </Button>
                            <Button type="submit">
                              {editingField ? '更新' : '创建'}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>排序</TableHead>
                        <TableHead>字段名称</TableHead>
                        <TableHead>显示名称</TableHead>
                        <TableHead>字段类型</TableHead>
                        <TableHead>列宽</TableHead>
                        <TableHead>必填</TableHead>
                        <TableHead>唯一</TableHead>
                        <TableHead>主字段</TableHead>
                        <TableHead>可见</TableHead>
                        <TableHead>系统字段</TableHead>
                        <TableHead className="text-right">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        Array.from({ length: 5 }).map((_, i) => (
                          <TableRow key={i}>
                            {Array.from({ length: 11 }).map((_, j) => (
                              <TableCell key={j}>
                                <Skeleton className="h-4 bg-muted" />
                              </TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : fields.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={11} className="text-center text-muted-foreground">
                            暂无字段配置
                          </TableCell>
                        </TableRow>
                      ) : (
                        fields.map((field) => (
                          <TableRow key={field.id}>
                            <TableCell>{field.sort_order}</TableCell>
                            <TableCell className="font-mono text-sm">{field.field_name}</TableCell>
                            <TableCell className="font-medium">{field.display_name}</TableCell>
                            <TableCell>
                              <span className="px-2 py-1 rounded text-xs bg-blue-100 text-blue-700">
                                {fieldTypeOptions.find(t => t.value === field.field_type)?.label}
                              </span>
                            </TableCell>
                            <TableCell>{field.width}px</TableCell>
                            <TableCell>{field.is_required ? '✓' : '-'}</TableCell>
                            <TableCell>{field.is_unique ? '✓' : '-'}</TableCell>
                            <TableCell>{field.is_primary ? '✓' : '-'}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleVisibility(field)}
                              >
                                {field.is_visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                              </Button>
                            </TableCell>
                            <TableCell>{field.is_system ? '✓' : '-'}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEdit(field)}
                                >
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                {!field.is_system && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setFieldToDelete(field);
                                      setDeleteDialogOpen(true);
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除字段 "{fieldToDelete?.display_name}" 吗?此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
