import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getTableConfigs, getFieldConfigs } from '@/db/api';
import { DynamicForm, validateFields } from '@/components/DynamicField';
import type { TableConfig, FieldConfig } from '@/types/database';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { Form } from '@/components/ui/form';
import { useForm } from 'react-hook-form';

export default function DynamicFormDemoPage() {
  const [tables, setTables] = useState<TableConfig[]>([]);
  const [selectedTableId, setSelectedTableId] = useState<string>('');
  const [fields, setFields] = useState<FieldConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const form = useForm();

  useEffect(() => {
    fetchTables();
  }, []);

  useEffect(() => {
    if (selectedTableId) {
      fetchFields(selectedTableId);
    }
  }, [selectedTableId]);

  const fetchTables = async () => {
    try {
      const data = await getTableConfigs();
      setTables(data);
      if (data.length > 0) {
        setSelectedTableId(data[0].id);
      }
    } catch (error) {
      toast.error('获取表格配置失败');
    }
  };

  const fetchFields = async (tableId: string) => {
    try {
      setLoading(true);
      const data = await getFieldConfigs(tableId);
      setFields(data);
      
      // 初始化表单值
      const initialValues: Record<string, any> = {};
      data.forEach((field) => {
        if (field.default_value) {
          initialValues[field.field_name] = field.default_value;
        }
      });
      setFormValues(initialValues);
      setErrors({});
    } catch (error) {
      toast.error('获取字段配置失败');
    } finally {
      setLoading(false);
    }
  };

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormValues((prev) => ({
      ...prev,
      [fieldName]: value,
    }));
    
    // 清除该字段的错误
    if (errors[fieldName]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[fieldName];
        return newErrors;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // 验证所有字段
    const validationErrors = validateFields(fields, formValues);
    
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast.error('请检查表单填写');
      return;
    }

    // 提交数据
    console.log('提交数据:', formValues);
    toast.success('表单提交成功!');
    
    // 在控制台显示提交的数据
    console.table(formValues);
  };

  const handleReset = () => {
    const initialValues: Record<string, any> = {};
    fields.forEach((field) => {
      if (field.default_value) {
        initialValues[field.field_name] = field.default_value;
      }
    });
    setFormValues(initialValues);
    setErrors({});
    toast.success('表单已重置');
  };

  const selectedTable = tables.find((t) => t.id === selectedTableId);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl xl:text-3xl font-bold">动态表单演示</h1>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>选择表格</CardTitle>
            <Select value={selectedTableId} onValueChange={setSelectedTableId}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="选择表格" />
              </SelectTrigger>
              <SelectContent>
                {tables.map((table) => (
                  <SelectItem key={table.id} value={table.id}>
                    {table.icon} {table.display_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {selectedTable && (
            <div className="mb-4 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">{selectedTable.display_name}</h3>
              <p className="text-sm text-muted-foreground">{selectedTable.description}</p>
              <p className="text-xs text-muted-foreground mt-2">
                数据库表: <code className="bg-background px-1 py-0.5 rounded">{selectedTable.table_name}</code>
              </p>
            </div>
          )}

          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-4 w-24 bg-muted" />
                  <Skeleton className="h-10 w-full bg-muted" />
                </div>
              ))}
            </div>
          ) : fields.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              暂无字段配置
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={handleSubmit} className="space-y-6">
                <DynamicForm
                  fields={fields}
                  values={formValues}
                  onChange={handleFieldChange}
                  errors={errors}
                />

                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button type="button" variant="outline" onClick={handleReset}>
                    重置
                  </Button>
                  <Button type="submit">
                    提交
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>当前表单数据</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted p-4 rounded-lg overflow-auto text-sm">
            {JSON.stringify(formValues, null, 2)}
          </pre>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>使用说明</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">功能特点</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
              <li>根据字段配置自动生成表单</li>
              <li>支持17种字段类型的渲染</li>
              <li>自动验证必填、格式、范围等规则</li>
              <li>单选/多选字段支持选项配置</li>
              <li>数字字段支持最小值、最大值、精度配置</li>
              <li>实时显示表单数据</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-2">操作步骤</h3>
            <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
              <li>在顶部下拉框选择要测试的表格</li>
              <li>系统自动加载该表格的字段配置</li>
              <li>填写表单(必填字段标有红色星号)</li>
              <li>点击"提交"按钮验证并提交</li>
              <li>查看"当前表单数据"查看实时数据</li>
              <li>点击"重置"按钮清空表单</li>
            </ol>
          </div>

          <div>
            <h3 className="font-semibold mb-2">字段类型演示</h3>
            <div className="grid grid-cols-2 xl:grid-cols-3 gap-2 text-sm">
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">文本:</span> 单行输入框
              </div>
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">数字:</span> 数字输入框
              </div>
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">日期:</span> 日期选择器
              </div>
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">单选:</span> 下拉选择框
              </div>
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">多选:</span> 复选框组
              </div>
              <div className="p-2 bg-muted rounded">
                <span className="font-medium">复选框:</span> 开关按钮
              </div>
            </div>
          </div>

          <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <p className="text-sm text-blue-900 dark:text-blue-100">
              💡 <strong>提示:</strong> 这是一个演示页面,展示了如何根据字段配置动态生成表单。
              实际应用中,可以将这个功能集成到入库、出库等业务页面中,实现完全配置化的表单管理。
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
