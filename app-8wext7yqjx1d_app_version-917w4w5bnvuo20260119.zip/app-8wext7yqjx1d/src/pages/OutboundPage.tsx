import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, CheckCircle, Trash2, Eye, Printer } from 'lucide-react';
import { getOutboundOrders, approveOutboundOrder, deleteOutboundOrder, getOutboundOrderItems, getProducts, getShelves, getCustomers } from '@/db/api';
import type { OutboundOrder, OutboundOrderItem, Product, Shelf } from '@/types/database';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';

export default function OutboundPage() {
  const [orders, setOrders] = useState<OutboundOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<OutboundOrder | null>(null);
  const [orderItems, setOrderItems] = useState<OutboundOrderItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<string | null>(null);
  const navigate = useNavigate();
  const { profile } = useAuth();

  const fetchData = async () => {
    try {
      const [ordersData, productsData, shelvesData, customersData] = await Promise.all([
        getOutboundOrders(),
        getProducts(),
        getShelves(),
        getCustomers(),
      ]);
      setOrders(ordersData);
      setProducts(productsData);
      setShelves(shelvesData);
      setCustomers(customersData);
    } catch (error) {
      toast.error('获取出库单失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleApprove = async (orderId: string) => {
    try {
      await approveOutboundOrder(orderId);
      toast.success('出库单审核成功');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '审核失败');
    }
  };

  const handleDelete = async (orderId: string) => {
    setOrderToDelete(orderId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!orderToDelete) return;
    try {
      await deleteOutboundOrder(orderToDelete);
      toast.success('删除成功');
      setOrderToDelete(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    }
  };

  const handleViewDetails = async (order: OutboundOrder) => {
    setSelectedOrder(order);
    setDetailsOpen(true);
    setLoadingDetails(true);
    try {
      const items = await getOutboundOrderItems(order.id);
      setOrderItems(items);
    } catch (error) {
      toast.error('获取出库明细失败');
    } finally {
      setLoadingDetails(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">出库管理</h1>
          <p className="text-muted-foreground">管理产品出库单据</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.print()} className="no-print">
            <Printer className="mr-2 h-4 w-4" />
            打印表单
          </Button>
          <Button onClick={() => navigate('/outbound/create')} className="no-print">
            <Plus className="mr-2 h-4 w-4" />
            创建出库单
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full bg-muted" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>出库单号</TableHead>
                    <TableHead>出库类型</TableHead>
                    <TableHead>出库日期</TableHead>
                    <TableHead>版本号</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead className="no-print">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground">
                        暂无出库单
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.order_number}</TableCell>
                        <TableCell>{order.order_type}</TableCell>
                        <TableCell>{new Date(order.order_date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          {order.versions?.version_number || '-'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Badge variant={order.status === 'approved' ? 'default' : 'secondary'}>
                              {order.status === 'draft' ? '草稿' : order.status === 'approved' ? '已审核' : '已取消'}
                            </Badge>
                            {order.status === 'approved' && (
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleViewDetails(order)}
                                title="查看明细"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{new Date(order.created_at).toLocaleString()}</TableCell>
                        <TableCell className="no-print">
                          <div className="flex gap-2">
                            {order.status === 'draft' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => navigate(`/outbound/edit/${order.id}`)}
                              >
                                <Edit className="mr-1 h-3 w-3" />
                                编辑
                              </Button>
                            )}
                            {profile?.role === 'admin' && order.status === 'draft' && (
                              <Button
                                size="sm"
                                onClick={() => handleApprove(order.id)}
                              >
                                <CheckCircle className="mr-1 h-3 w-3" />
                                审核
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(order.id)}
                              disabled={order.status === 'approved' && profile?.role !== 'admin'}
                              title={order.status === 'approved' ? '已审核的单据需要管理员权限才能删除' : '删除出库单'}
                            >
                              <Trash2 className="mr-1 h-3 w-3" />
                              删除
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 出库明细Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              出库明细 - {selectedOrder?.order_number}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* 基本信息 */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
              <div>
                <span className="text-sm text-muted-foreground">出库类型:</span>
                <span className="ml-2 font-medium">{selectedOrder?.order_type}</span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">出库日期:</span>
                <span className="ml-2 font-medium">
                  {selectedOrder?.order_date ? new Date(selectedOrder.order_date).toLocaleDateString() : '-'}
                </span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">客户:</span>
                <span className="ml-2 font-medium">
                  {selectedOrder?.customer_name || 
                   (selectedOrder?.customer_id 
                     ? customers.find(c => c.id === selectedOrder.customer_id)?.name || '-'
                     : '-')}
                </span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">领用人:</span>
                <span className="ml-2 font-medium">{selectedOrder?.recipient || '-'}</span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">版本号:</span>
                <span className="ml-2 font-medium">{selectedOrder?.versions?.version_number || '-'}</span>
              </div>
              {selectedOrder?.notes && (
                <div className="col-span-2">
                  <span className="text-sm text-muted-foreground">备注:</span>
                  <span className="ml-2">{selectedOrder.notes}</span>
                </div>
              )}
            </div>

            {/* 明细表格 */}
            <div>
              <h3 className="text-lg font-semibold mb-2">出库明细</h3>
              {loadingDetails ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>产品编号</TableHead>
                        <TableHead>产品名称</TableHead>
                        <TableHead>数量</TableHead>
                        <TableHead>货架</TableHead>
                        <TableHead>样式</TableHead>
                        <TableHead>序列号</TableHead>
                        <TableHead>备注</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orderItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            暂无明细数据
                          </TableCell>
                        </TableRow>
                      ) : (
                        orderItems.map((item) => {
                          const product = products.find((p) => p.id === item.product_id);
                          const shelf = shelves.find((s) => s.id === item.shelf_id);
                          return (
                            <TableRow key={item.id}>
                              <TableCell className="font-medium">{product?.code || '-'}</TableCell>
                              <TableCell>{product?.name || '-'}</TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell>{shelf?.name || '-'}</TableCell>
                              <TableCell>{item.style}</TableCell>
                              <TableCell>
                                {item.serial_numbers_text ? (
                                  <div className="text-xs max-w-xs" title={item.serial_numbers_text}>
                                    {item.serial_numbers_text}
                                  </div>
                                ) : (
                                  <span className="text-muted-foreground">-</span>
                                )}
                              </TableCell>
                              <TableCell>{item.notes || '-'}</TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该出库单,请输入您的密码以确认"
      />
    </div>
  );
}
