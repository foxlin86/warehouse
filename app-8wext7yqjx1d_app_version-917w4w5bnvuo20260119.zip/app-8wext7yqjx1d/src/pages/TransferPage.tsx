import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, CheckCircle, Trash2, Eye } from 'lucide-react';
import { getTransferOrders, approveTransferOrder, deleteTransferOrder, getTransferOrderItems, getProducts, getShelves } from '@/db/api';
import type { TransferOrder, TransferOrderItem, Product, Shelf } from '@/types/database';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';

export default function TransferPage() {
  const [orders, setOrders] = useState<TransferOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<TransferOrder | null>(null);
  const [orderItems, setOrderItems] = useState<TransferOrderItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<string | null>(null);
  const navigate = useNavigate();
  const { profile } = useAuth();

  const fetchData = async () => {
    try {
      const [ordersData, productsData, shelvesData] = await Promise.all([
        getTransferOrders(),
        getProducts(),
        getShelves(),
      ]);
      setOrders(ordersData);
      setProducts(productsData);
      setShelves(shelvesData);
    } catch (error) {
      toast.error('获取调拨单失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleApprove = async (orderId: string) => {
    try {
      await approveTransferOrder(orderId);
      toast.success('调拨单审核成功');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '审核失败');
    }
  };

  const handleDelete = (orderId: string) => {
    setOrderToDelete(orderId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!orderToDelete) return;
    try {
      await deleteTransferOrder(orderToDelete);
      toast.success('删除成功');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setOrderToDelete(null);
    }
  };

  const handleViewDetails = async (order: TransferOrder) => {
    setSelectedOrder(order);
    setDetailsOpen(true);
    setLoadingDetails(true);
    try {
      const items = await getTransferOrderItems(order.id);
      setOrderItems(items);
    } catch (error) {
      toast.error('获取调拨明细失败');
    } finally {
      setLoadingDetails(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">调拨管理</h1>
          <p className="text-muted-foreground">管理产品调拨单据</p>
        </div>
        <Button onClick={() => navigate('/transfer/create')}>
          <Plus className="mr-2 h-4 w-4" />
          创建调拨单
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full bg-muted" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>调拨单号</TableHead>
                    <TableHead>调拨日期</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground">
                        暂无调拨单
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.order_number}</TableCell>
                        <TableCell>{new Date(order.transfer_date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Badge variant={order.status === 'approved' ? 'default' : 'secondary'}>
                              {order.status === 'draft' ? '草稿' : order.status === 'approved' ? '已审核' : '已取消'}
                            </Badge>
                            {order.status === 'approved' && (
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleViewDetails(order)}
                                title="查看明细"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{new Date(order.created_at).toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {order.status === 'draft' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => navigate(`/transfer/edit/${order.id}`)}
                              >
                                <Edit className="mr-1 h-3 w-3" />
                                编辑
                              </Button>
                            )}
                            {profile?.role === 'admin' && order.status === 'draft' && (
                              <Button
                                size="sm"
                                onClick={() => handleApprove(order.id)}
                              >
                                <CheckCircle className="mr-1 h-3 w-3" />
                                审核
                              </Button>
                            )}
                            {order.status === 'draft' && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDelete(order.id)}
                              >
                                <Trash2 className="mr-1 h-3 w-3" />
                                删除
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 调拨明细Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              调拨明细 - {selectedOrder?.order_number}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* 基本信息 */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
              <div>
                <span className="text-sm text-muted-foreground">调拨日期:</span>
                <span className="ml-2 font-medium">
                  {selectedOrder?.transfer_date ? new Date(selectedOrder.transfer_date).toLocaleDateString() : '-'}
                </span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">状态:</span>
                <span className="ml-2 font-medium">
                  {selectedOrder?.status === 'draft' ? '草稿' : selectedOrder?.status === 'approved' ? '已审核' : '已取消'}
                </span>
              </div>
              {selectedOrder?.notes && (
                <div className="col-span-2">
                  <span className="text-sm text-muted-foreground">备注:</span>
                  <span className="ml-2">{selectedOrder.notes}</span>
                </div>
              )}
            </div>

            {/* 明细表格 */}
            <div>
              <h3 className="text-lg font-semibold mb-2">调拨明细</h3>
              {loadingDetails ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-full bg-muted" />
                  <Skeleton className="h-10 w-full bg-muted" />
                  <Skeleton className="h-10 w-full bg-muted" />
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>产品编号</TableHead>
                        <TableHead>产品名称</TableHead>
                        <TableHead>数量</TableHead>
                        <TableHead>源货架</TableHead>
                        <TableHead>目标货架</TableHead>
                        <TableHead>样式</TableHead>
                        <TableHead>备注</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orderItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            暂无明细数据
                          </TableCell>
                        </TableRow>
                      ) : (
                        orderItems.map((item) => {
                          const product = products.find((p) => p.id === item.product_id);
                          const sourceShelf = shelves.find((s) => s.id === item.from_shelf_id);
                          const targetShelf = shelves.find((s) => s.id === item.to_shelf_id);
                          return (
                            <TableRow key={item.id}>
                              <TableCell className="font-medium">{product?.code || '-'}</TableCell>
                              <TableCell>{product?.name || '-'}</TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell>{sourceShelf?.name || '-'}</TableCell>
                              <TableCell>{targetShelf?.name || '-'}</TableCell>
                              <TableCell>{item.from_style} → {item.to_style}</TableCell>
                              <TableCell>{item.notes || '-'}</TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该调拨单,请输入您的密码以确认"
      />
    </div>
  );
}
