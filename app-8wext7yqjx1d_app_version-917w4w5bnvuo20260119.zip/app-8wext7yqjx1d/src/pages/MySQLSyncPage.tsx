import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Database, Download, Upload, RefreshCw, CheckCircle2, XCircle, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { getSyncLogs, updateSetting } from '@/db/api';
import type { MySQLConfig, SyncLog } from '@/types/database';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function MySQLSyncPage() {
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [mysqlConfig, setMysqlConfig] = useState<MySQLConfig>({
    host: '',
    port: '3306',
    database: '',
    username: '',
    password: '',
    enabled: false,
  });
  const [syncLogs, setSyncLogs] = useState<SyncLog[]>([]);

  useEffect(() => {
    loadMySQLConfig();
    loadSyncLogs();
  }, []);

  const loadMySQLConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('setting_key', 'mysql_config')
        .maybeSingle();

      if (error) throw error;
      if (data) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        setMysqlConfig((data as any).setting_value);
      }
    } catch (error: any) {
      console.error('加载MySQL配置失败:', error);
      toast.error('加载配置失败');
    }
  };

  const loadSyncLogs = async () => {
    try {
      const logs = await getSyncLogs();
      setSyncLogs(logs);
    } catch (error: any) {
      console.error('加载同步日志失败:', error);
    }
  };

  const handleSaveConfig = async () => {
    setLoading(true);
    try {
      await updateSetting('mysql_config', mysqlConfig);
      toast.success('MySQL配置已保存');
    } catch (error: any) {
      console.error('保存配置失败:', error);
      toast.error('保存配置失败');
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    if (!mysqlConfig.host || !mysqlConfig.database || !mysqlConfig.username) {
      toast.error('请填写完整的MySQL连接信息');
      return;
    }

    setTesting(true);
    try {
      // 调用Edge Function测试连接
      const { data, error } = await supabase.functions.invoke('mysql-sync', {
        body: {
          action: 'test_connection',
          config: mysqlConfig,
        },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('MySQL连接测试成功');
      } else {
        throw new Error(data?.message || '连接测试失败');
      }
    } catch (error: any) {
      console.error('测试连接失败:', error);
      toast.error(error.message || '连接测试失败');
    } finally {
      setTesting(false);
      loadSyncLogs();
    }
  };

  const handleExportToMySQL = async () => {
    if (!mysqlConfig.enabled) {
      toast.error('请先启用MySQL同步并保存配置');
      return;
    }

    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('mysql-sync', {
        body: {
          action: 'export',
          config: mysqlConfig,
        },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('数据导出到MySQL成功');
      } else {
        throw new Error(data?.message || '导出失败');
      }
    } catch (error: any) {
      console.error('导出失败:', error);
      toast.error(error.message || '导出失败');
    } finally {
      setSyncing(false);
      loadSyncLogs();
    }
  };

  const handleImportFromMySQL = async () => {
    if (!mysqlConfig.enabled) {
      toast.error('请先启用MySQL同步并保存配置');
      return;
    }

    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('mysql-sync', {
        body: {
          action: 'import',
          config: mysqlConfig,
        },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('从MySQL导入数据成功');
      } else {
        throw new Error(data?.message || '导入失败');
      }
    } catch (error: any) {
      console.error('导入失败:', error);
      toast.error(error.message || '导入失败');
    } finally {
      setSyncing(false);
      loadSyncLogs();
    }
  };

  const handleFullSync = async () => {
    if (!mysqlConfig.enabled) {
      toast.error('请先启用MySQL同步并保存配置');
      return;
    }

    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('mysql-sync', {
        body: {
          action: 'full_sync',
          config: mysqlConfig,
        },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('全量同步成功');
      } else {
        throw new Error(data?.message || '同步失败');
      }
    } catch (error: any) {
      console.error('同步失败:', error);
      toast.error(error.message || '同步失败');
    } finally {
      setSyncing(false);
      loadSyncLogs();
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-500"><CheckCircle2 className="w-3 h-3 mr-1" />成功</Badge>;
      case 'failed':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />失败</Badge>;
      case 'running':
        return <Badge variant="secondary"><Loader2 className="w-3 h-3 mr-1 animate-spin" />运行中</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getSyncTypeLabel = (type: string) => {
    switch (type) {
      case 'export':
        return '导出到MySQL';
      case 'import':
        return '从MySQL导入';
      case 'full_sync':
        return '全量同步';
      case 'test_connection':
        return '测试连接';
      default:
        return type;
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl xl:text-3xl font-bold">MySQL数据同步</h1>
        <p className="text-muted-foreground mt-1">配置MySQL数据库连接,实现数据导入导出和同步</p>
      </div>

      <Tabs defaultValue="config" className="space-y-4">
        <TabsList>
          <TabsTrigger value="config">配置管理</TabsTrigger>
          <TabsTrigger value="sync">数据同步</TabsTrigger>
          <TabsTrigger value="logs">同步日志</TabsTrigger>
        </TabsList>

        <TabsContent value="config" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>MySQL连接配置</CardTitle>
              <CardDescription>配置MySQL数据库连接信息</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>主机地址</Label>
                  <Input
                    value={mysqlConfig.host}
                    onChange={(e) => setMysqlConfig({ ...mysqlConfig, host: e.target.value })}
                    placeholder="localhost 或 IP地址"
                  />
                </div>

                <div className="space-y-2">
                  <Label>端口</Label>
                  <Input
                    value={mysqlConfig.port}
                    onChange={(e) => setMysqlConfig({ ...mysqlConfig, port: e.target.value })}
                    placeholder="3306"
                  />
                </div>

                <div className="space-y-2">
                  <Label>数据库名</Label>
                  <Input
                    value={mysqlConfig.database}
                    onChange={(e) => setMysqlConfig({ ...mysqlConfig, database: e.target.value })}
                    placeholder="数据库名称"
                  />
                </div>

                <div className="space-y-2">
                  <Label>用户名</Label>
                  <Input
                    value={mysqlConfig.username}
                    onChange={(e) => setMysqlConfig({ ...mysqlConfig, username: e.target.value })}
                    placeholder="MySQL用户名"
                  />
                </div>

                <div className="space-y-2 xl:col-span-2">
                  <Label>密码</Label>
                  <Input
                    type="password"
                    value={mysqlConfig.password}
                    onChange={(e) => setMysqlConfig({ ...mysqlConfig, password: e.target.value })}
                    placeholder="MySQL密码"
                  />
                </div>

                <div className="space-y-2 xl:col-span-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="enabled"
                      checked={mysqlConfig.enabled}
                      onChange={(e) => setMysqlConfig({ ...mysqlConfig, enabled: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <Label htmlFor="enabled" className="cursor-pointer">启用MySQL同步</Label>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSaveConfig} disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Database className="w-4 h-4 mr-2" />}
                  保存配置
                </Button>
                <Button onClick={handleTestConnection} disabled={testing} variant="outline">
                  {testing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                  测试连接
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>配置说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>• <strong>主机地址</strong>: MySQL服务器的IP地址或域名,本地使用localhost</p>
              <p>• <strong>端口</strong>: MySQL服务端口,默认为3306</p>
              <p>• <strong>数据库名</strong>: 要同步的MySQL数据库名称</p>
              <p>• <strong>用户名/密码</strong>: 具有读写权限的MySQL账号</p>
              <p>• <strong>启用同步</strong>: 勾选后才能执行数据同步操作</p>
              <p>• <strong>安全提示</strong>: 密码将加密存储,建议使用专用账号并限制权限</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync" className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-base">
                  <Download className="w-5 h-5 mr-2" />
                  导出到MySQL
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  将Supabase中的所有数据导出到MySQL数据库
                </p>
                <Button onClick={handleExportToMySQL} disabled={syncing || !mysqlConfig.enabled} className="w-full">
                  {syncing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                  开始导出
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-base">
                  <Upload className="w-5 h-5 mr-2" />
                  从MySQL导入
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  从MySQL数据库导入数据到Supabase
                </p>
                <Button onClick={handleImportFromMySQL} disabled={syncing || !mysqlConfig.enabled} className="w-full">
                  {syncing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  开始导入
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-base">
                  <RefreshCw className="w-5 h-5 mr-2" />
                  全量同步
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  双向同步所有数据,保持两个数据库一致
                </p>
                <Button onClick={handleFullSync} disabled={syncing || !mysqlConfig.enabled} className="w-full">
                  {syncing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                  开始同步
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-base">
                <AlertCircle className="w-5 h-5 mr-2" />
                重要提示
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>• <strong>导出操作</strong>: 会覆盖MySQL中的现有数据,请谨慎操作</p>
              <p>• <strong>导入操作</strong>: 会覆盖Supabase中的现有数据,建议先备份</p>
              <p>• <strong>全量同步</strong>: 会比较两个数据库的数据,以最新的为准进行同步</p>
              <p>• <strong>数据安全</strong>: 同步前请确保已备份重要数据</p>
              <p>• <strong>网络要求</strong>: 确保服务器可以访问MySQL数据库</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>同步日志</CardTitle>
                <Button onClick={loadSyncLogs} variant="outline" size="sm">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  刷新
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {syncLogs.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">暂无同步日志</p>
                ) : (
                  syncLogs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{getSyncTypeLabel(log.sync_type)}</span>
                          {getStatusBadge(log.status)}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {new Date(log.started_at).toLocaleString('zh-CN')}
                        </span>
                      </div>
                      {log.message && (
                        <p className="text-sm text-muted-foreground">{log.message}</p>
                      )}
                      {log.details && (
                        <details className="text-xs text-muted-foreground">
                          <summary className="cursor-pointer">查看详情</summary>
                          <pre className="mt-2 p-2 bg-muted rounded overflow-auto">
                            {JSON.stringify(log.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
