import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Package, Users, ArrowDownToLine, ArrowUpFromLine, TrendingUp, AlertTriangle } from 'lucide-react';
import { getProducts, getCustomers, getInboundOrders, getOutboundOrders, getInventory } from '@/db/api';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalCustomers: 0,
    totalInbound: 0,
    totalOutbound: 0,
    lowStockCount: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [products, customers, inboundOrders, outboundOrders, inventory] = await Promise.all([
          getProducts(),
          getCustomers(),
          getInboundOrders(),
          getOutboundOrders(),
          getInventory(),
        ]);

        // 计算低库存产品数量(库存小于10)
        const lowStock = inventory.filter(item => item.current_stock < 10).length;

        setStats({
          totalProducts: products.length,
          totalCustomers: customers.length,
          totalInbound: inboundOrders.filter(o => o.status === 'approved').length,
          totalOutbound: outboundOrders.filter(o => o.status === 'approved').length,
          lowStockCount: lowStock,
        });
      } catch (error) {
        console.error('获取统计数据失败:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: '产品总数',
      value: stats.totalProducts,
      icon: Package,
      color: 'text-primary',
    },
    {
      title: '客户总数',
      value: stats.totalCustomers,
      icon: Users,
      color: 'text-chart-2',
    },
    {
      title: '入库单数',
      value: stats.totalInbound,
      icon: ArrowDownToLine,
      color: 'text-chart-4',
    },
    {
      title: '出库单数',
      value: stats.totalOutbound,
      icon: ArrowUpFromLine,
      color: 'text-chart-5',
    },
    {
      title: '低库存预警',
      value: stats.lowStockCount,
      icon: AlertTriangle,
      color: 'text-destructive',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold xl:text-3xl">仪表板</h1>
        <p className="text-muted-foreground">欢迎使用库存管理系统</p>
      </div>

      <div className="grid gap-4 xl:grid-cols-2 2xl:grid-cols-5">
        {statCards.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-8 w-20 bg-muted" />
              ) : (
                <div className="text-2xl font-bold">{stat.value}</div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>快速操作</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <a
              href="/inbound"
              className="flex items-center gap-3 rounded-lg border p-3 transition-colors hover:bg-accent"
            >
              <ArrowDownToLine className="h-5 w-5 text-primary" />
              <div>
                <div className="font-medium">创建入库单</div>
                <div className="text-sm text-muted-foreground">记录新的产品入库</div>
              </div>
            </a>
            <a
              href="/outbound"
              className="flex items-center gap-3 rounded-lg border p-3 transition-colors hover:bg-accent"
            >
              <ArrowUpFromLine className="h-5 w-5 text-primary" />
              <div>
                <div className="font-medium">创建出库单</div>
                <div className="text-sm text-muted-foreground">记录产品出库</div>
              </div>
            </a>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>系统提示</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-start gap-3 rounded-lg border border-destructive/50 bg-destructive/10 p-3">
              <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <div className="font-medium">低库存预警</div>
                <div className="text-sm text-muted-foreground">
                  当前有 {stats.lowStockCount} 个产品库存不足10件,请及时补货
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
