import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';
import {
  getProducts,
  getShelves,
  getCustomers,
  createOutboundOrder,
  updateOutboundOrder,
  getOutboundOrder,
  getOutboundOrderItems,
  createOutboundOrderItem,
  deleteOutboundOrderItem,
  deleteOutboundOrder,
  getInventory,
  getVersions,
  getAvailableSerialNumbers,
  updateSerialNumbersByNumbers,
} from '@/db/api';
import type { Product, Shelf, Customer, OutboundOrderItem, Version, SerialNumber } from '@/types/database';

export default function OutboundFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [versions, setVersions] = useState<Version[]>([]);
  const [inventory, setInventory] = useState<any[]>([]);
  const [availableSerialNumbers, setAvailableSerialNumbers] = useState<SerialNumber[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // 表单数据
  const [orderNumber, setOrderNumber] = useState('');
  const [orderType, setOrderType] = useState('销售出库');
  const [customerId, setCustomerId] = useState('');
  const [versionId, setVersionId] = useState('');
  const [recipient, setRecipient] = useState('');
  const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<OutboundOrderItem[]>([]);

  // 新增明细项
  const [newItem, setNewItem] = useState({
    product_id: '',
    quantity: '',
    shelf_id: '',
    style: '新品',
    notes: '',
    serial_numbers_text: '',
  });

  useEffect(() => {
    fetchData();
  }, [id]);

  // 当选择产品时,加载可用序列号
  useEffect(() => {
    if (newItem.product_id) {
      loadAvailableSerialNumbers(newItem.product_id);
    } else {
      setAvailableSerialNumbers([]);
    }
  }, [newItem.product_id]);

  const loadAvailableSerialNumbers = async (productId: string) => {
    try {
      const serialNumbers = await getAvailableSerialNumbers(productId);
      setAvailableSerialNumbers(serialNumbers);
    } catch (error) {
      console.error('加载序列号失败:', error);
      setAvailableSerialNumbers([]);
    }
  };

  const fetchData = async () => {
    try {
      const [productsData, shelvesData, customersData, versionsData, inventoryData] = await Promise.all([
        getProducts(),
        getShelves(),
        getCustomers(),
        getVersions(),
        getInventory(),
      ]);
      setProducts(productsData);
      setShelves(shelvesData);
      setCustomers(customersData);
      setVersions(versionsData);
      setInventory(inventoryData);

      if (id) {
        const order = await getOutboundOrder(id);
        if (order) {
          setOrderNumber(order.order_number);
          setOrderType(order.order_type);
          setCustomerId(order.customer_id || '');
          setVersionId(order.version_id || '');
          setRecipient(order.recipient || '');
          setOrderDate(order.order_date);
          setNotes(order.notes || '');

          const itemsData = await getOutboundOrderItems(id);
          setItems(itemsData);
        }
      } else {
        // 生成出库单号
        const timestamp = Date.now().toString().slice(-8);
        setOrderNumber(`OUT${timestamp}`);
      }
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const getAvailableStock = (productId: string, shelfId: string, style: string) => {
    const item = inventory.find(
      (inv) =>
        inv.product_id === productId && inv.shelf_id === shelfId && inv.style === style
    );
    return item?.current_stock || 0;
  };

  const handleAddItem = () => {
    if (!newItem.product_id || !newItem.quantity || !newItem.shelf_id) {
      toast.error('请填写必填项');
      return;
    }

    const availableStock = getAvailableStock(newItem.product_id, newItem.shelf_id, newItem.style);
    if (Number(newItem.quantity) > availableStock) {
      toast.error(`库存不足,当前可用库存: ${availableStock}`);
      return;
    }

    const product = products.find((p) => p.id === newItem.product_id);
    const shelf = shelves.find((s) => s.id === newItem.shelf_id);

    if (!product || !shelf) return;

    const item: any = {
      id: `temp-${Date.now()}`,
      product_id: newItem.product_id,
      product_name: product.name,
      product_code: product.code,
      quantity: Number(newItem.quantity),
      shelf_id: newItem.shelf_id,
      shelf_name: shelf.name,
      style: newItem.style,
      notes: newItem.notes,
      serial_numbers_text: newItem.serial_numbers_text || '',
    };

    setItems([...items, item]);
    setNewItem({
      product_id: '',
      quantity: '',
      shelf_id: '',
      style: '新品',
      notes: '',
      serial_numbers_text: '',
    });
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!orderNumber || items.length === 0) {
      toast.error('请填写出库单号并添加至少一条明细');
      return;
    }

    setSaving(true);
    try {
      let orderId = id;

      if (!orderId) {
        // 创建出库单
        const order = await createOutboundOrder({
          order_number: orderNumber,
          order_type: orderType,
          customer_id: customerId && customerId !== 'none' ? customerId : undefined,
          version_id: versionId || undefined,
          recipient: recipient || undefined,
          order_date: orderDate,
          status: 'draft',
          notes: notes || undefined,
        });
        orderId = order?.id;
      } else {
        // 更新出库单
        await updateOutboundOrder(orderId, {
          order_type: orderType,
          customer_id: customerId && customerId !== 'none' ? customerId : undefined,
          version_id: versionId || undefined,
          recipient: recipient || undefined,
          order_date: orderDate,
          notes: notes || undefined,
        });
      }

      if (!orderId) {
        throw new Error('创建出库单失败');
      }

      // 删除旧明细(如果是编辑模式)
      if (isEdit) {
        const oldItems = await getOutboundOrderItems(orderId);
        for (const item of oldItems) {
          await deleteOutboundOrderItem(item.id);
        }
      }

      // 添加新明细
      for (const item of items) {
        const createdItem = await createOutboundOrderItem({
          outbound_order_id: orderId,
          product_id: item.product_id,
          quantity: item.quantity,
          shelf_id: item.shelf_id,
          style: item.style,
          notes: item.notes || undefined,
          serial_numbers_text: item.serial_numbers_text || undefined,
        });

        // 如果有序列号,更新序列号状态为"已出库"
        if (item.serial_numbers_text && createdItem) {
          const serialNumbers = item.serial_numbers_text.split(',').map((s: string) => s.trim()).filter(Boolean);
          if (serialNumbers.length > 0) {
            await updateSerialNumbersByNumbers(serialNumbers, {
              status: 'out_stock',
              outbound_order_item_id: createdItem.id,
            });
          }
        }
      }

      toast.success(isEdit ? '出库单更新成功' : '出库单创建成功');
      navigate('/outbound');
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteClick = () => {
    if (!id) {
      toast.error('无法删除未保存的出库单');
      return;
    }
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!id) return;

    try {
      setDeleting(true);
      await deleteOutboundOrder(id);
      toast.success('出库单删除成功');
      navigate('/outbound');
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/outbound')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">
            {isEdit ? '编辑出库单' : '创建出库单'}
          </h1>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-3">
            <div className="space-y-2">
              <Label>出库单号 *</Label>
              <Input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>出库类型 *</Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="销售出库">销售出库</SelectItem>
                  <SelectItem value="领用出库">领用出库</SelectItem>
                  <SelectItem value="报废出库">报废出库</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>出库日期 *</Label>
              <Input type="date" value={orderDate} onChange={(e) => setOrderDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>客户</Label>
              <Select value={customerId} onValueChange={setCustomerId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择客户" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>版本管理</Label>
              <Select value={versionId} onValueChange={setVersionId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择版本" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无</SelectItem>
                  {versions.map((version) => (
                    <SelectItem key={version.id} value={version.id}>
                      {version.version_number} - {version.version_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>领用人</Label>
              <Input
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="请输入领用人"
              />
            </div>
            <div className="space-y-2">
              <Label>备注</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="请输入备注"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>出库明细</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-6">
            <div className="space-y-2">
              <Label>产品 *</Label>
              <Select value={newItem.product_id} onValueChange={(v) => setNewItem({ ...newItem, product_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择产品" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>货架 *</Label>
              <Select value={newItem.shelf_id} onValueChange={(v) => setNewItem({ ...newItem, shelf_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择货架" />
                </SelectTrigger>
                <SelectContent>
                  {shelves.map((shelf) => (
                    <SelectItem key={shelf.id} value={shelf.id}>
                      {shelf.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>样式 *</Label>
              <Select value={newItem.style} onValueChange={(v) => setNewItem({ ...newItem, style: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="新品">新品</SelectItem>
                  <SelectItem value="样机">样机</SelectItem>
                  <SelectItem value="损坏报废">损坏报废</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>数量 *</Label>
              <Input
                type="number"
                value={newItem.quantity}
                onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
                placeholder="数量"
              />
              {newItem.product_id && newItem.shelf_id && (
                <p className="text-xs text-muted-foreground">
                  可用库存: {getAvailableStock(newItem.product_id, newItem.shelf_id, newItem.style)}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>备注</Label>
              <Input
                value={newItem.notes}
                onChange={(e) => setNewItem({ ...newItem, notes: e.target.value })}
                placeholder="备注"
              />
            </div>
          </div>

          {/* 序列号选择 */}
          {newItem.product_id && availableSerialNumbers.length > 0 && (
            <div className="space-y-2">
              <Label>序列号(可选,多个用逗号分隔)</Label>
              <Select
                value={newItem.serial_numbers_text}
                onValueChange={(v) => {
                  const currentSerials = newItem.serial_numbers_text ? newItem.serial_numbers_text.split(',').map(s => s.trim()) : [];
                  if (currentSerials.includes(v)) {
                    return;
                  }
                  const newSerials = currentSerials.length > 0 ? `${newItem.serial_numbers_text},${v}` : v;
                  setNewItem({ ...newItem, serial_numbers_text: newSerials });
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择序列号" />
                </SelectTrigger>
                <SelectContent>
                  {availableSerialNumbers.map((sn) => (
                    <SelectItem key={sn.id} value={sn.serial_number}>
                      {sn.serial_number} {sn.product_model ? `(${sn.product_model})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {newItem.serial_numbers_text && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {newItem.serial_numbers_text.split(',').map((sn, idx) => (
                    <div key={idx} className="bg-secondary text-secondary-foreground px-2 py-1 rounded text-sm flex items-center gap-1">
                      {sn.trim()}
                      <button
                        type="button"
                        onClick={() => {
                          const serials = newItem.serial_numbers_text.split(',').map(s => s.trim()).filter(s => s !== sn.trim());
                          setNewItem({ ...newItem, serial_numbers_text: serials.join(',') });
                        }}
                        className="hover:text-destructive"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                可用序列号: {availableSerialNumbers.length}个
              </p>
            </div>
          )}

          <div className="grid gap-4 xl:grid-cols-6">
            <div className="space-y-2 flex items-end xl:col-start-6">
              <Button onClick={handleAddItem} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                添加
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>产品编号</TableHead>
                  <TableHead>产品名称</TableHead>
                  <TableHead>数量</TableHead>
                  <TableHead>货架</TableHead>
                  <TableHead>样式</TableHead>
                  <TableHead>序列号</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      暂无明细,请添加
                    </TableCell>
                  </TableRow>
                ) : (
                  items.map((item, index) => {
                    const product = products.find((p) => p.id === item.product_id);
                    const shelf = shelves.find((s) => s.id === item.shelf_id);
                    return (
                      <TableRow key={index}>
                        <TableCell>{product?.code}</TableCell>
                        <TableCell>{product?.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>{shelf?.name}</TableCell>
                        <TableCell>{item.style}</TableCell>
                        <TableCell>
                          {item.serial_numbers_text ? (
                            <div className="text-xs max-w-xs truncate" title={item.serial_numbers_text}>
                              {item.serial_numbers_text}
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between gap-2">
        <div>
          {isEdit && (
            <Button 
              variant="destructive" 
              onClick={handleDeleteClick} 
              disabled={deleting || saving}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {deleting ? '删除中...' : '删除出库单'}
            </Button>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate('/outbound')}>
            取消
          </Button>
          <Button onClick={handleSave} disabled={saving || deleting}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </div>
      </div>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该出库单及其所有明细,请输入您的密码以确认"
      />
    </div>
  );
}
