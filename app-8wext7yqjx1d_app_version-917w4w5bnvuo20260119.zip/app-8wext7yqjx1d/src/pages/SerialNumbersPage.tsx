import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Plus, Eye, Trash2, Upload } from 'lucide-react';
import { getSerialNumbers, createSerialNumber, getProducts, getShelves, getInboundOrderItems, getOutboundOrderItems, deleteSerialNumber } from '@/db/api';
import type { SerialNumber, Product, Shelf } from '@/types/database';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { useForm } from 'react-hook-form';
import { Textarea } from '@/components/ui/textarea';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';
import { useAuth } from '@/contexts/AuthContext';
import { ImportSerialNumbersDialog } from '@/components/ui/ImportSerialNumbersDialog';

export default function SerialNumbersPage() {
  const [serialNumbers, setSerialNumbers] = useState<SerialNumber[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedSerial, setSelectedSerial] = useState<SerialNumber | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [serialToDelete, setSerialToDelete] = useState<string | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const { profile } = useAuth();

  const form = useForm({
    defaultValues: {
      serial_number: '',
      product_id: '',
      product_model: '',
      notes: '',
    },
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [snData, prodData, shelvesData] = await Promise.all([
        getSerialNumbers(),
        getProducts(),
        getShelves(),
      ]);
      setSerialNumbers(snData);
      setProducts(prodData);
      setShelves(shelvesData);
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values: any) => {
    try {
      const product = products.find(p => p.id === values.product_id);
      await createSerialNumber({
        serial_number: values.serial_number,
        product_id: values.product_id,
        product_model: values.product_model,
        product_name_text: product?.name || '',
        product_code_text: product?.code || '',
        status: 'in_stock',
        notes: values.notes || null,
      });
      toast.success('序列号创建成功');
      setDialogOpen(false);
      form.reset();
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '创建失败');
    }
  };

  const handleViewDetails = (serial: SerialNumber) => {
    setSelectedSerial(serial);
    setDetailsOpen(true);
  };

  const handleDelete = (id: string) => {
    setSerialToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (!serialToDelete) return;
    try {
      await deleteSerialNumber(serialToDelete);
      toast.success('序列号删除成功');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setSerialToDelete(null);
    }
  };

  const filteredSerialNumbers = serialNumbers.filter((sn) =>
    sn.serial_number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">序列号管理</h1>
          <p className="text-muted-foreground">追踪设备序列号全生命周期</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setImportDialogOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            导入
          </Button>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                新增序列号
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>新增序列号</DialogTitle>
              </DialogHeader>
              <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="serial_number"
                  rules={{ required: '请输入序列号' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>序列号 *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="请输入序列号" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="product_id"
                  rules={{ required: '请选择产品' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>产品 *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择产品" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.code} - {product.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="product_model"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>型号</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="请输入型号" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>备注</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="请输入备注" rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">
                    创建
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="mb-4 flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="搜索序列号..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full bg-muted" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>序列号</TableHead>
                    <TableHead>产品型号</TableHead>
                    <TableHead>产品名称</TableHead>
                    <TableHead>产品编号</TableHead>
                    <TableHead>当前样式</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>备注</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSerialNumbers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground">
                        暂无序列号数据
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredSerialNumbers.map((sn) => (
                      <TableRow key={sn.id}>
                        <TableCell className="font-medium">{sn.serial_number}</TableCell>
                        <TableCell>{sn.product_model || '-'}</TableCell>
                        <TableCell>{sn.product_name_text || '-'}</TableCell>
                        <TableCell>{sn.product_code_text || '-'}</TableCell>
                        <TableCell>{sn.current_style || '-'}</TableCell>
                        <TableCell>
                          <Badge variant={sn.status === 'in_stock' ? 'default' : 'secondary'}>
                            {sn.status === 'in_stock' ? '在库' : '已出库'}
                          </Badge>
                        </TableCell>
                        <TableCell>{sn.notes || '-'}</TableCell>
                        <TableCell>{new Date(sn.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleViewDetails(sn)}
                              title="查看详情"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(sn.id)}
                              disabled={sn.status !== 'in_stock'}
                              title={sn.status === 'in_stock' ? '删除序列号' : '只能删除在库状态的序列号'}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 序列号详情Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              序列号详情 - {selectedSerial?.serial_number}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* 基本信息 */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">基本信息</h3>
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
                <div>
                  <span className="text-sm text-muted-foreground">序列号:</span>
                  <span className="ml-2 font-medium">{selectedSerial?.serial_number}</span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">产品型号:</span>
                  <span className="ml-2 font-medium">{selectedSerial?.product_model || '-'}</span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">产品名称:</span>
                  <span className="ml-2 font-medium">{selectedSerial?.product_name_text || '-'}</span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">产品编号:</span>
                  <span className="ml-2 font-medium">{selectedSerial?.product_code_text || '-'}</span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">当前样式:</span>
                  <span className="ml-2 font-medium">{selectedSerial?.current_style || '-'}</span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">当前货架:</span>
                  <span className="ml-2 font-medium">
                    {selectedSerial?.current_shelf_id 
                      ? shelves.find(s => s.id === selectedSerial.current_shelf_id)?.name || '-'
                      : '-'}
                  </span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">状态:</span>
                  <span className="ml-2">
                    <Badge variant={selectedSerial?.status === 'in_stock' ? 'default' : 'secondary'}>
                      {selectedSerial?.status === 'in_stock' ? '在库' : '已出库'}
                    </Badge>
                  </span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">创建时间:</span>
                  <span className="ml-2 font-medium">
                    {selectedSerial?.created_at ? new Date(selectedSerial.created_at).toLocaleString() : '-'}
                  </span>
                </div>
                {selectedSerial?.notes && (
                  <div className="col-span-2">
                    <span className="text-sm text-muted-foreground">备注:</span>
                    <span className="ml-2">{selectedSerial.notes}</span>
                  </div>
                )}
              </div>
            </div>

            {/* 关联信息 */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">关联信息</h3>
              <div className="grid grid-cols-1 gap-4 p-4 bg-muted rounded-lg">
                <div>
                  <span className="text-sm text-muted-foreground">入库明细ID:</span>
                  <span className="ml-2 font-mono text-xs">
                    {selectedSerial?.inbound_order_item_id || '-'}
                  </span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">出库明细ID:</span>
                  <span className="ml-2 font-mono text-xs">
                    {selectedSerial?.outbound_order_item_id || '-'}
                  </span>
                </div>
              </div>
            </div>

            {/* 时间信息 */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">时间信息</h3>
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
                <div>
                  <span className="text-sm text-muted-foreground">创建时间:</span>
                  <span className="ml-2 text-sm">
                    {selectedSerial?.created_at ? new Date(selectedSerial.created_at).toLocaleString() : '-'}
                  </span>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">更新时间:</span>
                  <span className="ml-2 text-sm">
                    {selectedSerial?.updated_at ? new Date(selectedSerial.updated_at).toLocaleString() : '-'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description="此操作将永久删除该序列号,请输入您的密码以确认"
      />

      <ImportSerialNumbersDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        products={products}
        onSuccess={fetchData}
      />
    </div>
  );
}
