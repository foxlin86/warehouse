import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Download, Printer, Trash2 } from 'lucide-react';
import { getInventory, deleteProduct } from '@/db/api';
import type { InventoryView } from '@/types/database';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { PasswordVerifyDialog } from '@/components/ui/PasswordVerifyDialog';

export default function InventoryPage() {
  const [inventory, setInventory] = useState<InventoryView[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [exporting, setExporting] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const data = await getInventory();
      setInventory(data);
    } catch (error) {
      toast.error('获取库存数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedProducts(filteredInventory.map((item) => item.product_id));
    } else {
      setSelectedProducts([]);
    }
  };

  const handleSelectProduct = (productId: string, checked: boolean) => {
    if (checked) {
      setSelectedProducts([...selectedProducts, productId]);
    } else {
      setSelectedProducts(selectedProducts.filter((id) => id !== productId));
    }
  };

  const handleDeleteClick = () => {
    if (selectedProducts.length === 0) {
      toast.error('请先选择要删除的产品');
      return;
    }
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    if (selectedProducts.length === 0) return;

    try {
      setDeleting(true);
      let successCount = 0;
      let failCount = 0;
      const errors: string[] = [];

      for (const productId of selectedProducts) {
        try {
          await deleteProduct(productId);
          successCount++;
        } catch (error: any) {
          failCount++;
          const product = inventory.find((item) => item.product_id === productId);
          errors.push(`${product?.product_name || productId}: ${error.message}`);
        }
      }

      if (successCount > 0) {
        toast.success(`成功删除 ${successCount} 个产品`);
      }
      if (failCount > 0) {
        toast.error(`删除失败 ${failCount} 个产品`, {
          description: errors.join('; '),
          duration: 5000,
        });
      }

      setSelectedProducts([]);
      await fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    } finally {
      setDeleting(false);
    }
  };

  const filteredInventory = inventory.filter(
    (item) =>
      item.product_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.shelf_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // 导出Excel功能
  const handleExport = () => {
    try {
      setExporting(true);
      
      // 准备导出数据
      const exportData = inventory.map((item) => ({
        '产品编号': item.product_code,
        '产品名称': item.product_name,
        '货架': item.shelf_name,
        '样式': item.style,
        '累计入库': item.total_inbound || 0,
        '累计出库': item.total_outbound || 0,
        '当前库存': item.current_stock || 0,
      }));

      // 创建工作簿
      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, '库存数据');

      // 设置列宽
      const colWidths = [
        { wch: 15 }, // 产品编号
        { wch: 20 }, // 产品名称
        { wch: 15 }, // 货架
        { wch: 12 }, // 样式
        { wch: 12 }, // 累计入库
        { wch: 12 }, // 累计出库
        { wch: 12 }, // 当前库存
      ];
      worksheet['!cols'] = colWidths;

      // 生成文件名
      const fileName = `库存数据_${new Date().toLocaleDateString().replace(/\//g, '-')}_${Date.now()}.xlsx`;

      // 导出文件
      XLSX.writeFile(workbook, fileName);
      
      toast.success(`成功导出 ${inventory.length} 条库存数据`);
    } catch (error: any) {
      toast.error(error.message || '导出失败');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold xl:text-3xl">库存查询</h1>
          <p className="text-muted-foreground">查看实时库存信息</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="destructive" 
            onClick={handleDeleteClick} 
            disabled={loading || selectedProducts.length === 0 || deleting}
            className="no-print"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            {deleting ? '删除中...' : `删除选中 (${selectedProducts.length})`}
          </Button>
          <Button variant="outline" onClick={() => window.print()} className="no-print">
            <Printer className="w-4 h-4 mr-2" />
            打印表单
          </Button>
          <Button onClick={handleExport} disabled={loading || exporting || inventory.length === 0} className="no-print">
            <Download className="w-4 h-4 mr-2" />
            {exporting ? '导出中...' : '导出Excel'}
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="mb-4 flex items-center gap-2 no-print">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="搜索产品编号、名称或货架..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full bg-muted" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12 no-print">
                      <Checkbox
                        checked={selectedProducts.length === filteredInventory.length && filteredInventory.length > 0}
                        onCheckedChange={handleSelectAll}
                      />
                    </TableHead>
                    <TableHead>产品编号</TableHead>
                    <TableHead>产品名称</TableHead>
                    <TableHead>货架</TableHead>
                    <TableHead>样式</TableHead>
                    <TableHead className="text-right">累计入库</TableHead>
                    <TableHead className="text-right">累计出库</TableHead>
                    <TableHead className="text-right">当前库存</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInventory.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                        暂无库存数据
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredInventory.map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="no-print">
                          <Checkbox
                            checked={selectedProducts.includes(item.product_id)}
                            onCheckedChange={(checked) => handleSelectProduct(item.product_id, checked as boolean)}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{item.product_code}</TableCell>
                        <TableCell>{item.product_name}</TableCell>
                        <TableCell>{item.shelf_name}</TableCell>
                        <TableCell>
                          <span
                            className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                              item.style === '新品'
                                ? 'bg-chart-1/10 text-chart-1'
                                : item.style === '样机'
                                  ? 'bg-chart-4/10 text-chart-4'
                                  : 'bg-destructive/10 text-destructive'
                            }`}
                          >
                            {item.style}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">{item.total_inbound}</TableCell>
                        <TableCell className="text-right">{item.total_outbound}</TableCell>
                        <TableCell className="text-right font-semibold">
                          <span
                            className={
                              item.current_stock < 10
                                ? 'text-destructive'
                                : item.current_stock < 50
                                  ? 'text-warning'
                                  : 'text-foreground'
                            }
                          >
                            {item.current_stock}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <PasswordVerifyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onVerified={handleDeleteConfirmed}
        title="删除确认"
        description={`此操作将永久删除选中的 ${selectedProducts.length} 个产品及其相关数据,请输入您的密码以确认`}
      />
    </div>
  );
}
