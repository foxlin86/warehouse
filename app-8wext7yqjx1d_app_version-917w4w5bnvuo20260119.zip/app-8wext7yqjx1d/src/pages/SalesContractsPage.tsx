import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Pencil, Trash2, Download, FileText, Search } from 'lucide-react';
import { getSalesContracts, createSalesContract, updateSalesContract, deleteSalesContract, getCustomers } from '@/db/api';
import type { SalesContract, Customer } from '@/types/database';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { useForm } from 'react-hook-form';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { supabase } from '@/db/supabase';

export default function SalesContractsPage() {
  const [contracts, setContracts] = useState<SalesContract[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingContract, setEditingContract] = useState<SalesContract | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [contractToDelete, setContractToDelete] = useState<SalesContract | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [uploading, setUploading] = useState(false);
  const [fileUrl, setFileUrl] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');

  const form = useForm({
    defaultValues: {
      contract_number: '',
      contract_name: '',
      customer_id: '',
      customer_name: '',
      contract_amount: '',
      contract_date: '',
      signing_date: '',
      expiry_date: '',
      status: 'draft',
      notes: '',
    },
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [contractsData, customersData] = await Promise.all([
        getSalesContracts(),
        getCustomers(),
      ]);
      setContracts(contractsData);
      setCustomers(customersData);
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 验证文件类型 - 支持表格、文档、PDF和图片
    const allowedTypes = [
      // PDF
      'application/pdf',
      // 图片
      'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/bmp', 'image/tiff',
      // Word文档
      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      // Excel表格
      'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      // CSV
      'text/csv',
      // OpenDocument
      'application/vnd.oasis.opendocument.text', 'application/vnd.oasis.opendocument.spreadsheet',
      // 文本
      'text/plain',
      // RTF
      'application/rtf',
    ];
    
    if (!allowedTypes.includes(file.type)) {
      toast.error('支持的文件格式: PDF、图片(JPG/PNG/GIF/WebP/SVG/BMP/TIFF)、Word(DOC/DOCX)、Excel(XLS/XLSX)、CSV、文本(TXT)、RTF、OpenDocument(ODT/ODS)');
      return;
    }

    // 验证文件大小(最大20MB)
    if (file.size > 20 * 1024 * 1024) {
      toast.error('文件大小不能超过20MB');
      return;
    }

    try {
      setUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `contracts/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('documents')
        .getPublicUrl(filePath);

      setFileUrl(publicUrl);
      setFileName(file.name);
      toast.success('文件上传成功');
    } catch (error: any) {
      toast.error(error.message || '文件上传失败');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (values: any) => {
    try {
      const customer = customers.find(c => c.id === values.customer_id);
      const contractData = {
        contract_number: values.contract_number,
        contract_name: values.contract_name,
        customer_id: values.customer_id || undefined,
        customer_name: customer?.name || values.customer_name || undefined,
        contract_amount: values.contract_amount ? Number(values.contract_amount) : undefined,
        contract_date: values.contract_date || undefined,
        signing_date: values.signing_date || undefined,
        expiry_date: values.expiry_date || undefined,
        file_url: fileUrl || undefined,
        file_name: fileName || undefined,
        status: values.status,
        notes: values.notes || undefined,
      };

      if (editingContract) {
        await updateSalesContract(editingContract.id, contractData);
        toast.success('合同更新成功');
      } else {
        await createSalesContract(contractData);
        toast.success('合同创建成功');
      }

      setDialogOpen(false);
      form.reset();
      setFileUrl('');
      setFileName('');
      setEditingContract(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleEdit = (contract: SalesContract) => {
    setEditingContract(contract);
    form.reset({
      contract_number: contract.contract_number,
      contract_name: contract.contract_name,
      customer_id: contract.customer_id || '',
      customer_name: contract.customer_name || '',
      contract_amount: contract.contract_amount?.toString() || '',
      contract_date: contract.contract_date || '',
      signing_date: contract.signing_date || '',
      expiry_date: contract.expiry_date || '',
      status: contract.status || 'draft',
      notes: contract.notes || '',
    });
    setFileUrl(contract.file_url || '');
    setFileName(contract.file_name || '');
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!contractToDelete) return;
    try {
      await deleteSalesContract(contractToDelete.id);
      toast.success('合同删除成功');
      setDeleteDialogOpen(false);
      setContractToDelete(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    }
  };

  const filteredContracts = contracts.filter((contract) =>
    contract.contract_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contract.contract_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contract.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      draft: { label: '草稿', variant: 'secondary' },
      pending: { label: '待签署', variant: 'outline' },
      signed: { label: '已签署', variant: 'default' },
      expired: { label: '已过期', variant: 'destructive' },
      terminated: { label: '已终止', variant: 'destructive' },
    };
    const config = statusMap[status] || { label: status, variant: 'secondary' };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold">合同管理</h1>
          <p className="text-muted-foreground">管理所有销售合同信息</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            form.reset();
            setEditingContract(null);
            setFileUrl('');
            setFileName('');
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              新增合同
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingContract ? '编辑合同' : '新增合同'}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="contract_number"
                    rules={{ required: '请输入合同编号' }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>合同编号 *</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="请输入合同编号" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contract_name"
                    rules={{ required: '请输入合同名称' }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>合同名称 *</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="请输入合同名称" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="customer_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>客户</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="选择客户" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {customers.map((customer) => (
                              <SelectItem key={customer.id} value={customer.id}>
                                {customer.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contract_amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>合同金额</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" placeholder="请输入合同金额" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contract_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>合同日期</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="signing_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>签署日期</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="expiry_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>到期日期</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>状态</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="draft">草稿</SelectItem>
                            <SelectItem value="pending">待签署</SelectItem>
                            <SelectItem value="signed">已签署</SelectItem>
                            <SelectItem value="expired">已过期</SelectItem>
                            <SelectItem value="terminated">已终止</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-2">
                  <FormLabel>上传文件</FormLabel>
                  <Input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.svg,.bmp,.tiff,.doc,.docx,.xls,.xlsx,.csv,.odt,.ods,.txt,.rtf"
                    onChange={handleFileUpload}
                    disabled={uploading}
                  />
                  {uploading && <p className="text-sm text-muted-foreground">上传中...</p>}
                  {fileName && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <FileText className="w-4 h-4" />
                      <span>{fileName}</span>
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    支持PDF和图片格式(JPG, PNG),最大10MB
                  </p>
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>备注</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="请输入备注" rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit" disabled={uploading}>
                    {editingContract ? '更新' : '创建'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="搜索合同编号、名称或客户..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 bg-muted" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>合同编号</TableHead>
                    <TableHead>合同名称</TableHead>
                    <TableHead>客户名称</TableHead>
                    <TableHead>合同金额</TableHead>
                    <TableHead>合同日期</TableHead>
                    <TableHead>签署日期</TableHead>
                    <TableHead>到期日期</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>文件</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredContracts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center text-muted-foreground">
                        暂无合同数据
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredContracts.map((contract) => (
                      <TableRow key={contract.id}>
                        <TableCell className="font-medium">{contract.contract_number}</TableCell>
                        <TableCell>{contract.contract_name}</TableCell>
                        <TableCell>{contract.customer_name || '-'}</TableCell>
                        <TableCell>¥{contract.contract_amount?.toFixed(2) || '0.00'}</TableCell>
                        <TableCell>
                          {contract.contract_date ? new Date(contract.contract_date).toLocaleDateString() : '-'}
                        </TableCell>
                        <TableCell>
                          {contract.signing_date ? new Date(contract.signing_date).toLocaleDateString() : '-'}
                        </TableCell>
                        <TableCell>
                          {contract.expiry_date ? new Date(contract.expiry_date).toLocaleDateString() : '-'}
                        </TableCell>
                        <TableCell>{getStatusBadge(contract.status || 'draft')}</TableCell>
                        <TableCell>
                          {contract.file_url ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(contract.file_url!, '_blank')}
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(contract)}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setContractToDelete(contract);
                                setDeleteDialogOpen(true);
                              }}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除合同 "{contractToDelete?.contract_number}" 吗?此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
