import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import { getVersions, createVersion, updateVersion, deleteVersion } from '@/db/api';
import type { Version } from '@/types/database';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';

export default function VersionsPage() {
  const [versions, setVersions] = useState<Version[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingVersion, setEditingVersion] = useState<Version | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [versionToDelete, setVersionToDelete] = useState<Version | null>(null);

  const form = useForm({
    defaultValues: {
      version_number: '',
      version_name: '',
      atp_btps: '',
      applicable_products: '',
      version_time: '',
      description: '',
      release_date: '',
      status: 'active' as 'active' | 'archived',
    },
  });

  const fetchData = async () => {
    try {
      const data = await getVersions();
      setVersions(data);
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (values: any) => {
    try {
      if (editingVersion) {
        await updateVersion(editingVersion.id, values);
        toast.success('版本更新成功');
      } else {
        await createVersion(values);
        toast.success('版本创建成功');
      }
      setDialogOpen(false);
      form.reset();
      setEditingVersion(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleEdit = (version: Version) => {
    setEditingVersion(version);
    form.reset({
      version_number: version.version_number,
      version_name: version.version_name,
      atp_btps: version.atp_btps || '',
      applicable_products: version.applicable_products || '',
      version_time: version.version_time ? new Date(version.version_time).toISOString().slice(0, 16) : '',
      description: version.description || '',
      release_date: version.release_date || '',
      status: version.status,
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!versionToDelete) return;
    try {
      await deleteVersion(versionToDelete.id);
      toast.success('版本删除成功');
      setDeleteDialogOpen(false);
      setVersionToDelete(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    }
  };

  const filteredVersions = versions.filter(v =>
    v.version_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.version_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (v.applicable_products && v.applicable_products.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl xl:text-3xl font-bold">软件版本管理</h1>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            form.reset();
            setEditingVersion(null);
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              新增版本
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingVersion ? '编辑版本' : '新增版本'}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="version_number"
                    rules={{ required: '请输入版本号' }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>版本号 *</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="如: V1.0.0" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="version_name"
                    rules={{ required: '请输入版本名称' }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>版本名称 *</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="版本名称" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="atp_btps"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ATP/BTPS</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="ATP或BTPS" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="applicable_products"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>使用产品</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="适用的产品" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="version_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>版本时间</FormLabel>
                        <FormControl>
                          <Input {...field} type="datetime-local" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="release_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>发布日期</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>状态</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">活跃</SelectItem>
                            <SelectItem value="archived">已归档</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>备注</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="版本说明" rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">
                    {editingVersion ? '更新' : '创建'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="搜索版本号、名称、产品..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>版本号</TableHead>
                  <TableHead>版本名称</TableHead>
                  <TableHead>ATP/BTPS</TableHead>
                  <TableHead>使用产品</TableHead>
                  <TableHead>版本时间</TableHead>
                  <TableHead>发布日期</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>备注</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 9 }).map((_, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-4 bg-muted" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : filteredVersions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-muted-foreground">
                      暂无数据
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredVersions.map((version) => (
                    <TableRow key={version.id}>
                      <TableCell className="font-medium">{version.version_number}</TableCell>
                      <TableCell>{version.version_name}</TableCell>
                      <TableCell>{version.atp_btps || '-'}</TableCell>
                      <TableCell>{version.applicable_products || '-'}</TableCell>
                      <TableCell>
                        {version.version_time ? new Date(version.version_time).toLocaleString('zh-CN') : '-'}
                      </TableCell>
                      <TableCell>{version.release_date || '-'}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded text-xs ${
                          version.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {version.status === 'active' ? '活跃' : '已归档'}
                        </span>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{version.description || '-'}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(version)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setVersionToDelete(version);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除版本 "{versionToDelete?.version_number}" 吗?此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
