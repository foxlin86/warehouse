import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { getWarehouses, createWarehouse, updateWarehouse, deleteWarehouse, getShelves, createShelf, updateShelf, deleteShelf } from '@/db/api';
import type { Warehouse, Shelf } from '@/types/database';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export default function WarehousesPage() {
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [shelves, setShelves] = useState<Shelf[]>([]);
  const [loading, setLoading] = useState(true);
  const [warehouseDialogOpen, setWarehouseDialogOpen] = useState(false);
  const [shelfDialogOpen, setShelfDialogOpen] = useState(false);
  const [editingWarehouse, setEditingWarehouse] = useState<Warehouse | null>(null);
  const [editingShelf, setEditingShelf] = useState<Shelf | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ type: 'warehouse' | 'shelf'; item: any } | null>(null);

  const warehouseForm = useForm({
    defaultValues: {
      code: '',
      name: '',
      location: '',
    },
  });

  const shelfForm = useForm({
    defaultValues: {
      code: '',
      name: '',
      warehouse_id: '',
      location: '',
    },
  });

  const fetchData = async () => {
    try {
      const [warehousesData, shelvesData] = await Promise.all([getWarehouses(), getShelves()]);
      setWarehouses(warehousesData);
      setShelves(shelvesData);
    } catch (error) {
      toast.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleWarehouseSubmit = async (data: any) => {
    try {
      if (editingWarehouse) {
        await updateWarehouse(editingWarehouse.id, data);
        toast.success('仓库更新成功');
      } else {
        await createWarehouse(data);
        toast.success('仓库创建成功');
      }
      setWarehouseDialogOpen(false);
      warehouseForm.reset();
      setEditingWarehouse(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleShelfSubmit = async (data: any) => {
    try {
      if (editingShelf) {
        await updateShelf(editingShelf.id, data);
        toast.success('货架更新成功');
      } else {
        await createShelf(data);
        toast.success('货架创建成功');
      }
      setShelfDialogOpen(false);
      shelfForm.reset();
      setEditingShelf(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    try {
      if (itemToDelete.type === 'warehouse') {
        await deleteWarehouse(itemToDelete.item.id);
        toast.success('仓库删除成功');
      } else {
        await deleteShelf(itemToDelete.item.id);
        toast.success('货架删除成功');
      }
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || '删除失败');
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold xl:text-3xl">仓库货架管理</h1>
        <p className="text-muted-foreground">管理仓库和货架信息</p>
      </div>

      <Tabs defaultValue="warehouses" className="space-y-4">
        <TabsList>
          <TabsTrigger value="warehouses">仓库管理</TabsTrigger>
          <TabsTrigger value="shelves">货架管理</TabsTrigger>
        </TabsList>

        <TabsContent value="warehouses" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={warehouseDialogOpen} onOpenChange={(open) => {
              setWarehouseDialogOpen(open);
              if (!open) {
                warehouseForm.reset();
                setEditingWarehouse(null);
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  新增仓库
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingWarehouse ? '编辑仓库' : '新增仓库'}</DialogTitle>
                </DialogHeader>
                <Form {...warehouseForm}>
                  <form onSubmit={warehouseForm.handleSubmit(handleWarehouseSubmit)} className="space-y-4">
                    <FormField
                      control={warehouseForm.control}
                      name="code"
                      rules={{ required: '仓库编码不能为空' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>仓库编码 *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入仓库编码" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={warehouseForm.control}
                      name="name"
                      rules={{ required: '仓库名称不能为空' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>仓库名称 *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入仓库名称" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={warehouseForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>位置描述</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入位置描述" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setWarehouseDialogOpen(false)}>
                        取消
                      </Button>
                      <Button type="submit">保存</Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="pt-6">
              {loading ? (
                <div className="space-y-2">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full bg-muted" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>仓库编码</TableHead>
                      <TableHead>仓库名称</TableHead>
                      <TableHead>位置</TableHead>
                      <TableHead>操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {warehouses.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground">
                          暂无数据
                        </TableCell>
                      </TableRow>
                    ) : (
                      warehouses.map((warehouse) => (
                        <TableRow key={warehouse.id}>
                          <TableCell className="font-medium">{warehouse.code}</TableCell>
                          <TableCell>{warehouse.name}</TableCell>
                          <TableCell>{warehouse.location || '-'}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditingWarehouse(warehouse);
                                  warehouseForm.reset({
                                    code: warehouse.code,
                                    name: warehouse.name,
                                    location: warehouse.location || '',
                                  });
                                  setWarehouseDialogOpen(true);
                                }}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setItemToDelete({ type: 'warehouse', item: warehouse });
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shelves" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={shelfDialogOpen} onOpenChange={(open) => {
              setShelfDialogOpen(open);
              if (!open) {
                shelfForm.reset();
                setEditingShelf(null);
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  新增货架
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingShelf ? '编辑货架' : '新增货架'}</DialogTitle>
                </DialogHeader>
                <Form {...shelfForm}>
                  <form onSubmit={shelfForm.handleSubmit(handleShelfSubmit)} className="space-y-4">
                    <FormField
                      control={shelfForm.control}
                      name="code"
                      rules={{ required: '货架编码不能为空' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>货架编码 *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入货架编码" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={shelfForm.control}
                      name="name"
                      rules={{ required: '货架名称不能为空' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>货架名称 *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入货架名称" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={shelfForm.control}
                      name="warehouse_id"
                      rules={{ required: '所属仓库不能为空' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>所属仓库 *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="选择所属仓库" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {warehouses.map((warehouse) => (
                                <SelectItem key={warehouse.id} value={warehouse.id}>
                                  {warehouse.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={shelfForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>位置描述</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="请输入位置描述" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setShelfDialogOpen(false)}>
                        取消
                      </Button>
                      <Button type="submit">保存</Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="pt-6">
              {loading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full bg-muted" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>货架编码</TableHead>
                      <TableHead>货架名称</TableHead>
                      <TableHead>所属仓库</TableHead>
                      <TableHead>位置</TableHead>
                      <TableHead>操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {shelves.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground">
                          暂无数据
                        </TableCell>
                      </TableRow>
                    ) : (
                      shelves.map((shelf) => {
                        const warehouse = warehouses.find((w) => w.id === shelf.warehouse_id);
                        return (
                          <TableRow key={shelf.id}>
                            <TableCell className="font-medium">{shelf.code}</TableCell>
                            <TableCell>{shelf.name}</TableCell>
                            <TableCell>{warehouse?.name || '-'}</TableCell>
                            <TableCell>{shelf.location || '-'}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setEditingShelf(shelf);
                                    shelfForm.reset({
                                      code: shelf.code,
                                      name: shelf.name,
                                      warehouse_id: shelf.warehouse_id || '',
                                      location: shelf.location || '',
                                    });
                                    setShelfDialogOpen(true);
                                  }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setItemToDelete({ type: 'shelf', item: shelf });
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除{itemToDelete?.type === 'warehouse' ? '仓库' : '货架'} "{itemToDelete?.item?.name}" 吗?此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
