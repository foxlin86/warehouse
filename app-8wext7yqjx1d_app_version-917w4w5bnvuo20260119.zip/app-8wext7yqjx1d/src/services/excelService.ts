import * as XLSX from 'xlsx';

// Excel导出服务
export const exportToExcel = (data: any[], filename: string, sheetName: string = 'Sheet1') => {
  // 创建工作簿
  const wb = XLSX.utils.book_new();
  
  // 创建工作表
  const ws = XLSX.utils.json_to_sheet(data);
  
  // 添加工作表到工作簿
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  
  // 导出文件
  XLSX.writeFile(wb, `${filename}.xlsx`);
};

// Excel导入服务
export const importFromExcel = (file: File): Promise<any[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        
        // 读取第一个工作表
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // 转换为JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        resolve(jsonData);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => {
      reject(new Error('文件读取失败'));
    };
    
    reader.readAsBinaryString(file);
  });
};

// 生成客户导入模板
export const generateCustomerTemplate = () => {
  const template = [
    {
      '客户编号': 'C001',
      '客户名称': '示例客户',
      '联系人': '张三',
      '电话': '13800138000',
      '地址': '北京市朝阳区',
      '分类': '经销商',
      '备注': '示例数据',
    },
  ];
  
  exportToExcel(template, '客户导入模板', '客户信息');
};

// 生成入库单导入模板
export const generateInboundTemplate = () => {
  const template = [
    {
      '单据编号': 'IN202601130001',
      '入库类型': '采购入库',
      '供应商编号': 'S001',
      '入库日期': '2026-01-13',
      '产品编号': 'P001',
      '产品名称': '示例产品',
      '数量': 10,
      '货架': 'A库',
      '样式': '新品',
      '批次号': 'BATCH001',
      '生产日期': '2026-01-01',
      '序列号': 'SN001,SN002',
      '备注': '示例数据',
    },
  ];
  
  exportToExcel(template, '入库单导入模板', '入库信息');
};

// 生成出库单导入模板
export const generateOutboundTemplate = () => {
  const template = [
    {
      '单据编号': 'OUT202601130001',
      '出库类型': '销售出库',
      '客户编号': 'C001',
      '收货人': '李四',
      '出库日期': '2026-01-13',
      '版本号': 'V1.0',
      '产品编号': 'P001',
      '产品名称': '示例产品',
      '数量': 5,
      '货架': 'A库',
      '样式': '新品',
      '序列号': 'SN001,SN002',
      '备注': '示例数据',
    },
  ];
  
  exportToExcel(template, '出库单导入模板', '出库信息');
};

// 导出客户数据
export const exportCustomers = (customers: any[]) => {
  const data = customers.map(c => ({
    '客户编号': c.code,
    '客户名称': c.name,
    '联系人': c.contact_person,
    '电话': c.phone,
    '地址': c.address,
    '分类': c.category,
    '备注': c.notes,
    '创建时间': new Date(c.created_at).toLocaleString('zh-CN'),
  }));
  
  exportToExcel(data, `客户数据_${new Date().toLocaleDateString('zh-CN')}`, '客户信息');
};

// 导出入库单数据
export const exportInboundOrders = (orders: any[]) => {
  const data: any[] = [];
  
  orders.forEach(order => {
    order.inbound_order_items?.forEach((item: any) => {
      data.push({
        '单据编号': order.order_number,
        '入库类型': order.order_type,
        '供应商': order.suppliers?.name || '',
        '入库日期': order.order_date,
        '产品编号': item.products?.code || '',
        '产品名称': item.products?.name || '',
        '数量': item.quantity,
        '货架': item.shelves?.name || '',
        '样式': item.style,
        '批次号': item.batch_number,
        '生产日期': item.production_date,
        '备注': item.notes,
        '状态': order.status === 'approved' ? '已审核' : order.status === 'pending' ? '待审核' : '草稿',
        '创建时间': new Date(order.created_at).toLocaleString('zh-CN'),
      });
    });
  });
  
  exportToExcel(data, `入库单_${new Date().toLocaleDateString('zh-CN')}`, '入库信息');
};

// 导出出库单数据
export const exportOutboundOrders = (orders: any[]) => {
  const data: any[] = [];
  
  orders.forEach(order => {
    order.outbound_order_items?.forEach((item: any) => {
      data.push({
        '单据编号': order.order_number,
        '出库类型': order.order_type,
        '客户': order.customers?.name || '',
        '收货人': order.recipient,
        '出库日期': order.order_date,
        '版本号': order.versions?.version_number || '',
        '产品编号': item.products?.code || '',
        '产品名称': item.products?.name || '',
        '数量': item.quantity,
        '货架': item.shelves?.name || '',
        '样式': item.style,
        '备注': item.notes,
        '状态': order.status === 'approved' ? '已审核' : order.status === 'pending' ? '待审核' : '草稿',
        '创建时间': new Date(order.created_at).toLocaleString('zh-CN'),
      });
    });
  });
  
  exportToExcel(data, `出库单_${new Date().toLocaleDateString('zh-CN')}`, '出库信息');
};
