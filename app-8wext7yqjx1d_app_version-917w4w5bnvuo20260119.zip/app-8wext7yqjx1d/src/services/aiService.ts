import { supabase } from '@/db/supabase';

// AI分析服务 - 前端直接调用AI API
export const analyzeWithAI = async (question: string) => {
  // 获取AI配置
  const { data: aiConfigData, error: configError } = await supabase
    .from('settings')
    .select('setting_value')
    .eq('setting_key', 'ai_config')
    .maybeSingle();

  if (configError || !aiConfigData) {
    throw new Error('AI配置未找到,请先在系统设置中配置');
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const aiConfig = (aiConfigData as any).setting_value;

  // Ollama本地模型不需要API密钥
  if (aiConfig.provider !== 'ollama' && !aiConfig.api_key) {
    throw new Error('API密钥未配置,请先在系统设置中配置');
  }

  // 获取库存数据
  const currentDate = new Date();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const monthStr = firstDayOfMonth.toISOString().split('T')[0];

  // 获取本月入库数据
  const { data: inboundData } = await supabase
    .from('inbound_orders')
    .select(`
      *,
      inbound_order_items(
        *,
        products(code, name),
        shelves(name)
      )
    `)
    .gte('order_date', monthStr)
    .eq('status', 'approved');

  // 获取本月出库数据
  const { data: outboundData } = await supabase
    .from('outbound_orders')
    .select(`
      *,
      outbound_order_items(
        *,
        products(code, name),
        shelves(name)
      )
    `)
    .gte('order_date', monthStr)
    .eq('status', 'approved');

  // 获取当前库存数据
  const { data: inventoryData } = await supabase
    .from('inventory_view')
    .select('*');

  // 构建数据摘要
  const dataSummary = {
    本月入库: inboundData?.map((order: any) => ({
      单号: order.order_number,
      日期: order.order_date,
      类型: order.order_type,
      明细: order.inbound_order_items?.map((item: any) => ({
        产品: item.products?.name,
        数量: item.quantity,
        货架: item.shelves?.name,
        样式: item.style,
      })),
    })),
    本月出库: outboundData?.map((order: any) => ({
      单号: order.order_number,
      日期: order.order_date,
      类型: order.order_type,
      明细: order.outbound_order_items?.map((item: any) => ({
        产品: item.products?.name,
        数量: item.quantity,
        货架: item.shelves?.name,
        样式: item.style,
      })),
    })),
    当前库存: inventoryData?.map((inv: any) => ({
      产品: inv.product_name,
      货架: inv.shelf_name,
      样式: inv.style,
      当前库存: inv.current_stock,
      累计入库: inv.total_inbound,
      累计出库: inv.total_outbound,
    })),
  };

  // 构建AI提示词
  const systemPrompt = `你是一个专业的库存管理分析助手。你需要根据提供的库存数据回答用户的问题。

数据说明:
- 本月入库: 本月所有已审核的入库单据
- 本月出库: 本月所有已审核的出库单据  
- 当前库存: 所有产品在各个货架的实时库存情况

请用简洁、专业的语言回答问题,并提供具体的数据支持。如果需要统计,请给出准确的数字。`;

  const userPrompt = `数据:
${JSON.stringify(dataSummary, null, 2)}

问题: ${question}

请分析以上数据并回答问题。`;

  // 调用AI API
  let analysis = '';

  if (aiConfig.provider === 'baidu') {
    // 百度AI(文心一言)
    // 百度API需要先获取access_token,这里简化处理,直接使用API Key作为access_token
    // 实际使用时,API Key应该是access_token
    const apiUrl = aiConfig.api_url || `https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=${aiConfig.api_key}`;
    
    // 百度API格式: messages数组,不支持system role,需要转换
    const messages = [
      { role: 'user', content: systemPrompt + '\n\n' + userPrompt },
    ];

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`百度AI调用失败: ${response.status} ${errorText}`);
    }

    const result = await response.json();
    analysis = result.result || '分析失败';
  } else if (aiConfig.provider === 'bailian') {
    // 百炼大模型
    const apiUrl = aiConfig.api_url || 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation';
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${aiConfig.api_key}`,
      },
      body: JSON.stringify({
        model: aiConfig.model,
        input: {
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
        },
        parameters: {
          result_format: 'message',
        },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`百炼API调用失败: ${response.status} ${errorText}`);
    }

    const result = await response.json();
    analysis = result.output?.choices?.[0]?.message?.content || '分析失败';
  } else if (aiConfig.provider === 'ollama') {
    // Ollama本地模型
    const apiUrl = aiConfig.api_url || 'http://localhost:11434/api/chat';
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Ollama调用失败: ${response.status} ${errorText}。请确保Ollama服务正在运行(http://localhost:11434)`);
    }

    const result = await response.json();
    analysis = result.message?.content || '分析失败';
  } else if (aiConfig.provider === 'deepseek' || aiConfig.provider === 'openai' || aiConfig.provider === 'custom') {
    // DeepSeek / OpenAI / 自定义API (兼容OpenAI格式)
    const apiUrl = aiConfig.api_url || (aiConfig.provider === 'deepseek' ? 'https://api.deepseek.com/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions');
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${aiConfig.api_key}`,
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API调用失败: ${response.status} ${errorText}`);
    }

    const result = await response.json();
    analysis = result.choices?.[0]?.message?.content || '分析失败';
  } else {
    throw new Error('不支持的AI服务商');
  }

  return analysis;
};
