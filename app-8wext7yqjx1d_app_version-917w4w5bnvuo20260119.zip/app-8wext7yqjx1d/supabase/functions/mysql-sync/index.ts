import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { action, config } = await req.json();

    // 创建同步日志
    const { data: logData } = await supabaseClient
      .from('sync_logs')
      .insert({
        sync_type: action,
        status: 'running',
        message: `开始${getActionLabel(action)}`,
      })
      .select()
      .single();

    const logId = logData?.id;

    try {
      let result;

      switch (action) {
        case 'test_connection':
          result = await testMySQLConnection(config);
          break;
        case 'export':
          result = await exportToMySQL(supabaseClient, config);
          break;
        case 'import':
          result = await importFromMySQL(supabaseClient, config);
          break;
        case 'full_sync':
          result = await fullSync(supabaseClient, config);
          break;
        default:
          throw new Error('不支持的操作类型');
      }

      // 更新日志为成功
      if (logId) {
        await supabaseClient
          .from('sync_logs')
          .update({
            status: 'success',
            message: result.message,
            details: result.details,
            completed_at: new Date().toISOString(),
          })
          .eq('id', logId);
      }

      return new Response(
        JSON.stringify({ success: true, ...result }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    } catch (error: any) {
      // 更新日志为失败
      if (logId) {
        await supabaseClient
          .from('sync_logs')
          .update({
            status: 'failed',
            message: error.message,
            completed_at: new Date().toISOString(),
          })
          .eq('id', logId);
      }

      throw error;
    }
  } catch (error: any) {
    console.error('MySQL同步错误:', error);
    return new Response(
      JSON.stringify({
        success: false,
        message: error.message || 'MySQL同步失败',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});

function getActionLabel(action: string): string {
  switch (action) {
    case 'test_connection':
      return '测试连接';
    case 'export':
      return '导出到MySQL';
    case 'import':
      return '从MySQL导入';
    case 'full_sync':
      return '全量同步';
    default:
      return action;
  }
}

// 测试MySQL连接
async function testMySQLConnection(config: any) {
  // 注意: Deno Deploy不支持直接连接MySQL
  // 这里提供接口预留,实际使用需要部署到支持MySQL的环境
  // 或者通过中间API服务器进行连接
  
  return {
    message: 'MySQL连接接口已预留,需要部署到支持MySQL的环境或使用中间API服务器',
    details: {
      note: '当前Edge Function运行在Deno Deploy环境,不支持直接连接MySQL',
      suggestion: '建议使用以下方案之一:',
      options: [
        '1. 部署到支持MySQL的自托管环境',
        '2. 创建中间API服务器处理MySQL连接',
        '3. 使用MySQL REST API或HTTP接口',
      ],
      config: {
        host: config.host,
        port: config.port,
        database: config.database,
        username: config.username,
      },
    },
  };
}

// 导出到MySQL
async function exportToMySQL(supabaseClient: any, config: any) {
  // 获取所有表的数据
  const tables = [
    'products',
    'customers',
    'suppliers',
    'warehouses',
    'shelves',
    'dictionaries',
    'inbound_orders',
    'inbound_order_items',
    'outbound_orders',
    'outbound_order_items',
    'transfer_orders',
    'transfer_order_items',
    'serial_numbers',
  ];

  const exportData: any = {};
  let totalRecords = 0;

  for (const table of tables) {
    const { data, error } = await supabaseClient.from(table).select('*');
    if (!error && data) {
      exportData[table] = data;
      totalRecords += data.length;
    }
  }

  return {
    message: `数据导出接口已预留,共${totalRecords}条记录待导出`,
    details: {
      tables: Object.keys(exportData),
      records: Object.entries(exportData).map(([table, data]: [string, any]) => ({
        table,
        count: data.length,
      })),
      totalRecords,
      note: '实际导出需要MySQL连接支持',
    },
  };
}

// 从MySQL导入
async function importFromMySQL(supabaseClient: any, config: any) {
  return {
    message: 'MySQL导入接口已预留',
    details: {
      note: '实际导入需要MySQL连接支持',
      config: {
        host: config.host,
        database: config.database,
      },
    },
  };
}

// 全量同步
async function fullSync(supabaseClient: any, config: any) {
  return {
    message: 'MySQL全量同步接口已预留',
    details: {
      note: '实际同步需要MySQL连接支持',
      config: {
        host: config.host,
        database: config.database,
      },
    },
  };
}
