-- 为serial_numbers表添加notes字段(如果不存在)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'serial_numbers' AND column_name = 'notes'
  ) THEN
    ALTER TABLE serial_numbers ADD COLUMN notes TEXT;
  END IF;
END $$;