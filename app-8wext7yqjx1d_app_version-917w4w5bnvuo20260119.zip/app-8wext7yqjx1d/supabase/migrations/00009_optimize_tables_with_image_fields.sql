-- 更新入库单明细表,添加图片中的字段
ALTER TABLE inbound_order_items ADD COLUMN IF NOT EXISTS initial_quantity INTEGER DEFAULT 0;
ALTER TABLE inbound_order_items ADD COLUMN IF NOT EXISTS return_quantity INTEGER DEFAULT 0;
ALTER TABLE inbound_order_items ADD COLUMN IF NOT EXISTS serial_numbers_text TEXT;

-- 更新出库单表,添加图片中的字段
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS fill_id TEXT;
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS customer_name TEXT;
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS contact_name TEXT;
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS express_number TEXT;

-- 更新出库单明细表,添加图片中的字段
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS unit_price DECIMAL(15,2);
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS total_amount DECIMAL(15,2);
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS color TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS product_type TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS location TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS serial_numbers_text TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS production_batch TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS production_date DATE;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS software_version TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS manufacturer_registration TEXT;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS batch_expiry_date DATE;
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS storage_conditions TEXT;

-- 更新序列号表,添加产品型号字段
ALTER TABLE serial_numbers ADD COLUMN IF NOT EXISTS product_model TEXT;

-- 更新版本管理表,添加图片中的字段
ALTER TABLE versions ADD COLUMN IF NOT EXISTS atp_btps TEXT;
ALTER TABLE versions ADD COLUMN IF NOT EXISTS applicable_products TEXT;
ALTER TABLE versions ADD COLUMN IF NOT EXISTS version_time TIMESTAMPTZ;

-- 为出库单明细添加版本关联
ALTER TABLE outbound_order_items ADD COLUMN IF NOT EXISTS version_id UUID REFERENCES versions(id);
CREATE INDEX IF NOT EXISTS idx_outbound_items_version ON outbound_order_items(version_id);

-- 为序列号添加出库单明细关联
ALTER TABLE serial_numbers ADD COLUMN IF NOT EXISTS outbound_order_item_id UUID REFERENCES outbound_order_items(id);
CREATE INDEX IF NOT EXISTS idx_serial_numbers_outbound_item ON serial_numbers(outbound_order_item_id);

-- 添加注释
COMMENT ON COLUMN inbound_order_items.initial_quantity IS '期初数量';
COMMENT ON COLUMN inbound_order_items.return_quantity IS '退货入库数量';
COMMENT ON COLUMN inbound_order_items.serial_numbers_text IS '序列号(文本)';

COMMENT ON COLUMN outbound_orders.fill_id IS '填写ID';
COMMENT ON COLUMN outbound_orders.customer_name IS '客户名称';
COMMENT ON COLUMN outbound_orders.contact_name IS '联系人姓名';
COMMENT ON COLUMN outbound_orders.phone IS '手机号';
COMMENT ON COLUMN outbound_orders.address IS '地址';
COMMENT ON COLUMN outbound_orders.express_number IS '快递单号';

COMMENT ON COLUMN outbound_order_items.unit_price IS '单价';
COMMENT ON COLUMN outbound_order_items.total_amount IS '总金额';
COMMENT ON COLUMN outbound_order_items.color IS '颜色';
COMMENT ON COLUMN outbound_order_items.product_type IS '类型';
COMMENT ON COLUMN outbound_order_items.location IS '库位';
COMMENT ON COLUMN outbound_order_items.serial_numbers_text IS '序列号(文本)';
COMMENT ON COLUMN outbound_order_items.production_batch IS '生产批号';
COMMENT ON COLUMN outbound_order_items.production_date IS '生产日期';
COMMENT ON COLUMN outbound_order_items.software_version IS '软件版本';
COMMENT ON COLUMN outbound_order_items.manufacturer_registration IS '生产企业注册证号';
COMMENT ON COLUMN outbound_order_items.batch_expiry_date IS '批号有效期';
COMMENT ON COLUMN outbound_order_items.storage_conditions IS '储运条件';

COMMENT ON COLUMN serial_numbers.product_model IS '产品型号';

COMMENT ON COLUMN versions.atp_btps IS 'ATP/BTPS';
COMMENT ON COLUMN versions.applicable_products IS '使用产品';
COMMENT ON COLUMN versions.version_time IS '版本时间';