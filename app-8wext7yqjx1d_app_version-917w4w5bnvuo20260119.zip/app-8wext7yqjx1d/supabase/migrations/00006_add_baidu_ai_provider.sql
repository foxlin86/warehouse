-- 更新AI服务商列表,添加百度AI
UPDATE settings 
SET setting_value = '[
  {"id": "baidu", "name": "百度AI(文心一言)", "models": ["ernie-4.0-turbo-8k", "ernie-4.0-8k", "ernie-3.5-8k", "ernie-speed-128k", "ernie-lite-8k"]},
  {"id": "bailian", "name": "百炼大模型", "models": ["qwen-max", "qwen-plus", "qwen-turbo"]},
  {"id": "deepseek", "name": "DeepSeek", "models": ["deepseek-chat", "deepseek-coder"]},
  {"id": "openai", "name": "OpenAI", "models": ["gpt-4", "gpt-3.5-turbo"]},
  {"id": "ollama", "name": "Ollama本地模型", "models": ["llama2", "llama3", "mistral", "qwen", "qwen2", "gemma", "phi", "custom"]},
  {"id": "custom", "name": "自定义API", "models": ["custom-model"]}
]'
WHERE setting_key = 'ai_providers';