-- 创建入库单表
CREATE TABLE inbound_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL, -- 入库单号
  order_type text NOT NULL, -- 入库类型(采购入库/退货入库/调拨入库/期初入库)
  supplier_id uuid REFERENCES suppliers(id), -- 供应商
  order_date date NOT NULL DEFAULT CURRENT_DATE, -- 入库日期
  status text NOT NULL DEFAULT 'draft', -- 状态(draft草稿/approved已审核)
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id),
  approved_at timestamptz, -- 审核时间
  approved_by uuid REFERENCES profiles(id) -- 审核人
);

-- 创建入库单明细表
CREATE TABLE inbound_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inbound_order_id uuid NOT NULL REFERENCES inbound_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity numeric NOT NULL CHECK (quantity > 0), -- 数量
  batch_number text, -- 批次号
  production_date date, -- 生产日期
  shelf_id uuid NOT NULL REFERENCES shelves(id), -- 存放货架
  style text NOT NULL, -- 样式(新品/样机/损坏报废)
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 创建出库单表
CREATE TABLE outbound_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL, -- 出库单号
  order_type text NOT NULL, -- 出库类型(销售出库/领用出库/报废出库)
  customer_id uuid REFERENCES customers(id), -- 客户
  recipient text, -- 领用人
  order_date date NOT NULL DEFAULT CURRENT_DATE, -- 出库日期
  status text NOT NULL DEFAULT 'draft', -- 状态(draft草稿/approved已审核)
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id),
  approved_at timestamptz, -- 审核时间
  approved_by uuid REFERENCES profiles(id) -- 审核人
);

-- 创建出库单明细表
CREATE TABLE outbound_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  outbound_order_id uuid NOT NULL REFERENCES outbound_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity numeric NOT NULL CHECK (quantity > 0), -- 数量
  shelf_id uuid NOT NULL REFERENCES shelves(id), -- 从哪个货架出库
  style text NOT NULL, -- 样式(新品/样机/损坏报废)
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 创建调拨单表
CREATE TABLE transfer_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL, -- 调拨单号
  transfer_date date NOT NULL DEFAULT CURRENT_DATE, -- 调拨日期
  status text NOT NULL DEFAULT 'draft', -- 状态(draft草稿/approved已审核)
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id),
  approved_at timestamptz, -- 审核时间
  approved_by uuid REFERENCES profiles(id) -- 审核人
);

-- 创建调拨单明细表
CREATE TABLE transfer_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_order_id uuid NOT NULL REFERENCES transfer_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity numeric NOT NULL CHECK (quantity > 0), -- 数量
  from_shelf_id uuid NOT NULL REFERENCES shelves(id), -- 调出货架
  to_shelf_id uuid NOT NULL REFERENCES shelves(id), -- 调入货架
  from_style text NOT NULL, -- 调出样式
  to_style text NOT NULL, -- 调入样式
  notes text, -- 备注
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (from_shelf_id != to_shelf_id OR from_style != to_style) -- 确保有变化
);

-- 创建序列号表
CREATE TABLE serial_numbers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number text UNIQUE NOT NULL, -- 序列号
  product_id uuid NOT NULL REFERENCES products(id),
  inbound_order_item_id uuid REFERENCES inbound_order_items(id), -- 入库明细
  outbound_order_item_id uuid REFERENCES outbound_order_items(id), -- 出库明细
  current_shelf_id uuid REFERENCES shelves(id), -- 当前货架
  current_style text, -- 当前样式
  status text NOT NULL DEFAULT 'in_stock', -- 状态(in_stock在库/out_stock已出库)
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建库存视图(动态计算)
CREATE VIEW inventory_view AS
WITH inbound_summary AS (
  SELECT 
    ioi.product_id,
    ioi.shelf_id,
    ioi.style,
    SUM(ioi.quantity) as total_inbound
  FROM inbound_order_items ioi
  INNER JOIN inbound_orders io ON io.id = ioi.inbound_order_id
  WHERE io.status = 'approved'
  GROUP BY ioi.product_id, ioi.shelf_id, ioi.style
),
outbound_summary AS (
  SELECT 
    ooi.product_id,
    ooi.shelf_id,
    ooi.style,
    SUM(ooi.quantity) as total_outbound
  FROM outbound_order_items ooi
  INNER JOIN outbound_orders oo ON oo.id = ooi.outbound_order_id
  WHERE oo.status = 'approved'
  GROUP BY ooi.product_id, ooi.shelf_id, ooi.style
)
SELECT 
  p.id as product_id,
  p.code as product_code,
  p.name as product_name,
  s.id as shelf_id,
  s.code as shelf_code,
  s.name as shelf_name,
  styles.style,
  COALESCE(inb.total_inbound, 0) as total_inbound,
  COALESCE(outb.total_outbound, 0) as total_outbound,
  COALESCE(inb.total_inbound, 0) - COALESCE(outb.total_outbound, 0) as current_stock
FROM products p
CROSS JOIN shelves s
CROSS JOIN (SELECT UNNEST(ARRAY['新品', '样机', '损坏报废']) as style) styles
LEFT JOIN inbound_summary inb ON inb.product_id = p.id AND inb.shelf_id = s.id AND inb.style = styles.style
LEFT JOIN outbound_summary outb ON outb.product_id = p.id AND outb.shelf_id = s.id AND outb.style = styles.style
WHERE COALESCE(inb.total_inbound, 0) - COALESCE(outb.total_outbound, 0) > 0;

-- 配置RLS策略
ALTER TABLE inbound_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbound_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbound_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbound_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE serial_numbers ENABLE ROW LEVEL SECURITY;

-- 管理员完全访问
CREATE POLICY "管理员完全访问入库单" ON inbound_orders FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问入库明细" ON inbound_order_items FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问出库单" ON outbound_orders FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问出库明细" ON outbound_order_items FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问调拨单" ON transfer_orders FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问调拨明细" ON transfer_order_items FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问序列号" ON serial_numbers FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 普通用户可查看和创建(但不能审核)
CREATE POLICY "用户可查看入库单" ON inbound_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建入库单" ON inbound_orders FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "用户可更新自己创建的草稿入库单" ON inbound_orders FOR UPDATE TO authenticated 
  USING (created_by = auth.uid() AND status = 'draft') 
  WITH CHECK (status = 'draft');

CREATE POLICY "用户可查看入库明细" ON inbound_order_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建入库明细" ON inbound_order_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "用户可更新入库明细" ON inbound_order_items FOR UPDATE TO authenticated USING (true);
CREATE POLICY "用户可删除入库明细" ON inbound_order_items FOR DELETE TO authenticated USING (true);

CREATE POLICY "用户可查看出库单" ON outbound_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建出库单" ON outbound_orders FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "用户可更新自己创建的草稿出库单" ON outbound_orders FOR UPDATE TO authenticated 
  USING (created_by = auth.uid() AND status = 'draft') 
  WITH CHECK (status = 'draft');

CREATE POLICY "用户可查看出库明细" ON outbound_order_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建出库明细" ON outbound_order_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "用户可更新出库明细" ON outbound_order_items FOR UPDATE TO authenticated USING (true);
CREATE POLICY "用户可删除出库明细" ON outbound_order_items FOR DELETE TO authenticated USING (true);

CREATE POLICY "用户可查看调拨单" ON transfer_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建调拨单" ON transfer_orders FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "用户可更新自己创建的草稿调拨单" ON transfer_orders FOR UPDATE TO authenticated 
  USING (created_by = auth.uid() AND status = 'draft') 
  WITH CHECK (status = 'draft');

CREATE POLICY "用户可查看调拨明细" ON transfer_order_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建调拨明细" ON transfer_order_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "用户可更新调拨明细" ON transfer_order_items FOR UPDATE TO authenticated USING (true);
CREATE POLICY "用户可删除调拨明细" ON transfer_order_items FOR DELETE TO authenticated USING (true);

CREATE POLICY "用户可查看序列号" ON serial_numbers FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可创建序列号" ON serial_numbers FOR INSERT TO authenticated WITH CHECK (true);