-- 创建产品主数据表
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL, -- 产品编号
  name text NOT NULL, -- 产品名称
  specification text, -- 规格型号
  unit text, -- 单位
  manufacturer text, -- 生产企业
  license_number text, -- 许可证号
  registration_number text, -- 注册证号
  default_shelf_id uuid, -- 默认货架
  default_style text, -- 默认样式(新品/样机/损坏报废)
  storage_conditions text, -- 储运条件
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id)
);

-- 创建客户表
CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, -- 客户名称
  contact_person text, -- 联系人
  phone text, -- 电话
  address text, -- 地址
  category text, -- 分类(经销商/终端客户)
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id)
);

-- 创建供应商表
CREATE TABLE suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, -- 供应商名称
  contact_person text, -- 联系人
  phone text, -- 电话
  address text, -- 地址
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id)
);

-- 创建仓库表
CREATE TABLE warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL, -- 仓库编码
  name text NOT NULL, -- 仓库名称
  location text, -- 位置描述
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id)
);

-- 创建货架表
CREATE TABLE shelves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL, -- 货架编码
  name text NOT NULL, -- 货架名称
  warehouse_id uuid REFERENCES warehouses(id) ON DELETE CASCADE,
  location text, -- 位置描述
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  updated_by uuid REFERENCES profiles(id)
);

-- 创建字典表(用于管理样式、入库类型等枚举值)
CREATE TABLE dictionaries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL, -- 字典分类(style/inbound_type/outbound_type等)
  code text NOT NULL, -- 字典代码
  name text NOT NULL, -- 字典名称
  sort_order int DEFAULT 0, -- 排序
  is_active boolean DEFAULT true, -- 是否启用
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(category, code)
);

-- 添加外键约束
ALTER TABLE products ADD CONSTRAINT fk_products_shelf FOREIGN KEY (default_shelf_id) REFERENCES shelves(id);

-- 配置RLS策略
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE shelves ENABLE ROW LEVEL SECURITY;
ALTER TABLE dictionaries ENABLE ROW LEVEL SECURITY;

-- 管理员完全访问
CREATE POLICY "管理员完全访问产品" ON products FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问客户" ON customers FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问供应商" ON suppliers FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问仓库" ON warehouses FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问货架" ON shelves FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员完全访问字典" ON dictionaries FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 普通用户只读访问
CREATE POLICY "用户可查看产品" ON products FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可查看客户" ON customers FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可查看供应商" ON suppliers FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可查看仓库" ON warehouses FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可查看货架" ON shelves FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可查看字典" ON dictionaries FOR SELECT TO authenticated USING (true);