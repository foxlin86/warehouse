-- 添加MySQL配置到settings表
INSERT INTO settings (setting_key, setting_value, description) VALUES
  ('mysql_config', '{"host": "", "port": "3306", "database": "", "username": "", "password": "", "enabled": false}', 'MySQL数据库连接配置')
ON CONFLICT (setting_key) DO NOTHING;

-- 创建数据同步日志表
CREATE TABLE IF NOT EXISTS sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sync_type TEXT NOT NULL, -- 'export', 'import', 'full_sync', 'test_connection'
  status TEXT NOT NULL, -- 'success', 'failed', 'running'
  message TEXT,
  details JSONB,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  created_by UUID REFERENCES profiles(id)
);

-- 创建索引
CREATE INDEX idx_sync_logs_type ON sync_logs(sync_type);
CREATE INDEX idx_sync_logs_status ON sync_logs(status);
CREATE INDEX idx_sync_logs_created_at ON sync_logs(started_at DESC);

-- RLS策略
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;

-- 管理员可以查看所有同步日志
CREATE POLICY "管理员可以查看所有同步日志" ON sync_logs
  FOR SELECT TO authenticated
  USING (is_admin(auth.uid()));

-- 管理员可以创建同步日志
CREATE POLICY "管理员可以创建同步日志" ON sync_logs
  FOR INSERT TO authenticated
  WITH CHECK (is_admin(auth.uid()));