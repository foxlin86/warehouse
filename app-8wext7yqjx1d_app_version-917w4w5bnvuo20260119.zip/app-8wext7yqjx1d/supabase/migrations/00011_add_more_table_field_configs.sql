-- 为调拨管理、序列号管理、库存查询添加表格和字段配置
DO $$
DECLARE
  app_id UUID;
  transfer_table_id UUID;
  serial_table_id UUID;
  inventory_table_id UUID;
BEGIN
  -- 获取应用ID
  SELECT id INTO app_id FROM applications WHERE name = '库存管理' LIMIT 1;
  
  -- 创建调拨管理表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'transfer_orders', '调拨管理', '管理库存调拨单据', '🔄')
  RETURNING id INTO transfer_table_id;
  
  -- 创建序列号管理表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'serial_numbers', '序列号管理', '管理设备序列号', '🔢')
  RETURNING id INTO serial_table_id;
  
  -- 创建库存查询表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'inventory_view', '库存查询', '查询实时库存信息', '📊')
  RETURNING id INTO inventory_table_id;
  
  -- 为调拨管理创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, sort_order, width, description) VALUES
  (transfer_table_id, 'order_number', '调拨单号', 'text', true, true, true, 1, 150, '调拨单唯一编号'),
  (transfer_table_id, 'transfer_date', '调拨日期', 'date', true, false, false, 2, 120, '调拨执行日期'),
  (transfer_table_id, 'from_warehouse_id', '调出仓库', 'relation', false, false, false, 3, 120, '关联仓库表'),
  (transfer_table_id, 'to_warehouse_id', '调入仓库', 'relation', false, false, false, 4, 120, '关联仓库表'),
  (transfer_table_id, 'status', '状态', 'select', true, true, false, 5, 100, '待审核/已审核/已完成'),
  (transfer_table_id, 'notes', '备注', 'text', false, false, false, 6, 200, '调拨说明'),
  (transfer_table_id, 'created_at', '创建时间', 'created_time', false, true, false, 7, 160, '记录创建时间'),
  (transfer_table_id, 'created_by', '创建人', 'created_by', false, true, false, 8, 120, '记录创建人'),
  (transfer_table_id, 'approved_at', '审核时间', 'datetime', false, false, false, 9, 160, '审核通过时间'),
  (transfer_table_id, 'approved_by', '审核人', 'updated_by', false, false, false, 10, 120, '审核人员');
  
  -- 为序列号管理创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, is_unique, sort_order, width, description) VALUES
  (serial_table_id, 'serial_number', '序列号', 'text', true, true, true, true, 1, 180, '设备唯一序列号'),
  (serial_table_id, 'product_id', '产品', 'relation', true, false, false, false, 2, 150, '关联产品表'),
  (serial_table_id, 'product_model', '产品型号', 'text', false, false, false, false, 3, 120, '产品规格型号'),
  (serial_table_id, 'product_name_text', '产品名称', 'text', false, false, false, false, 4, 150, '产品名称文本'),
  (serial_table_id, 'product_code_text', '产品编号', 'text', false, false, false, false, 5, 120, '产品编号文本'),
  (serial_table_id, 'inbound_order_item_id', '入库明细', 'relation', false, false, false, false, 6, 150, '关联入库明细'),
  (serial_table_id, 'outbound_order_item_id', '出库明细', 'relation', false, false, false, false, 7, 150, '关联出库明细'),
  (serial_table_id, 'current_shelf_id', '当前货架', 'relation', false, false, false, false, 8, 120, '关联货架表'),
  (serial_table_id, 'current_style', '当前样式', 'select', false, false, false, false, 9, 100, '新品/样机/损坏报废'),
  (serial_table_id, 'status', '状态', 'select', true, true, false, false, 10, 100, '在库/出库'),
  (serial_table_id, 'created_at', '创建时间', 'created_time', false, true, false, false, 11, 160, '记录创建时间'),
  (serial_table_id, 'updated_at', '更新时间', 'updated_time', false, true, false, false, 12, 160, '记录更新时间');
  
  -- 为库存查询创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, sort_order, width, description) VALUES
  (inventory_table_id, 'product_code', '产品编号', 'text', false, true, true, 1, 120, '产品唯一编号'),
  (inventory_table_id, 'product_name', '产品名称', 'text', false, true, false, 2, 180, '产品名称'),
  (inventory_table_id, 'specifications', '规格型号', 'text', false, false, false, 3, 150, '产品规格'),
  (inventory_table_id, 'unit', '单位', 'text', false, false, false, 4, 80, '计量单位'),
  (inventory_table_id, 'shelf_name', '货架', 'text', false, false, false, 5, 100, '存放货架'),
  (inventory_table_id, 'style', '样式', 'select', false, false, false, 6, 100, '新品/样机/损坏报废'),
  (inventory_table_id, 'initial_stock', '期初库存', 'number', false, false, false, 7, 100, '期初数量'),
  (inventory_table_id, 'total_inbound', '累计入库', 'number', false, false, false, 8, 100, '累计入库数量'),
  (inventory_table_id, 'total_outbound', '累计出库', 'number', false, false, false, 9, 100, '累计出库数量'),
  (inventory_table_id, 'current_stock', '当前库存', 'number', false, false, false, 10, 100, '实时库存数量'),
  (inventory_table_id, 'manufacturer', '生产企业', 'text', false, false, false, 11, 150, '生产厂家');
  
  -- 为入库管理添加更多字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'supplier_name', '供应商名称', 'text', false, false, 8, 150, '供应商名称文本'
  FROM table_configs tc WHERE tc.table_name = 'inbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'approved_at', '审核时间', 'datetime', false, false, 9, 160, '审核通过时间'
  FROM table_configs tc WHERE tc.table_name = 'inbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'approved_by', '审核人', 'updated_by', false, false, 10, 120, '审核人员'
  FROM table_configs tc WHERE tc.table_name = 'inbound_orders';
  
  -- 为出库管理添加更多字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'fill_id', '填写ID', 'text', false, false, 9, 120, '填写人员ID'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'customer_name', '客户名称', 'text', false, false, 10, 150, '客户名称文本'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'contact_name', '联系人', 'text', false, false, 11, 120, '客户联系人'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'phone', '手机号', 'phone', false, false, 12, 130, '联系电话'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'address', '地址', 'text', false, false, 13, 200, '收货地址'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'express_number', '快递单号', 'text', false, false, 14, 150, '物流快递单号'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'approved_at', '审核时间', 'datetime', false, false, 15, 160, '审核通过时间'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, sort_order, width, description)
  SELECT tc.id, 'approved_by', '审核人', 'updated_by', false, false, 16, 120, '审核人员'
  FROM table_configs tc WHERE tc.table_name = 'outbound_orders';
  
  -- 创建默认视图
  INSERT INTO view_configs (table_config_id, view_name, view_type, is_default, config) VALUES
  (transfer_table_id, '所有调拨单', 'table', true, '{"sort": [{"field": "created_at", "order": "desc"}]}'),
  (serial_table_id, '所有序列号', 'table', true, '{"sort": [{"field": "serial_number", "order": "asc"}]}'),
  (inventory_table_id, '库存总览', 'table', true, '{"sort": [{"field": "product_code", "order": "asc"}]}');
  
END $$;

-- 为字段配置添加选项配置的注释
COMMENT ON COLUMN field_configs.options IS '字段选项配置JSON: 
- select/multi_select: {"choices": [{"value": "option1", "label": "选项1", "color": "#3b82f6"}]}
- relation: {"table": "products", "display_field": "name", "value_field": "id"}
- number: {"min": 0, "max": 9999, "precision": 2}
- text: {"maxLength": 255, "pattern": "regex"}';

COMMENT ON COLUMN field_configs.validation IS '验证规则JSON:
- required: {"message": "此字段为必填项"}
- pattern: {"regex": "^[A-Z0-9]+$", "message": "只能包含大写字母和数字"}
- range: {"min": 0, "max": 100, "message": "值必须在0-100之间"}
- custom: {"function": "validateFunction", "message": "自定义验证失败"}';