-- 创建版本管理表
CREATE TABLE IF NOT EXISTS versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version_number TEXT NOT NULL UNIQUE,
  version_name TEXT NOT NULL,
  description TEXT,
  release_date DATE,
  status TEXT DEFAULT 'active', -- 'active', 'archived'
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id)
);

-- 创建索引
CREATE INDEX idx_versions_number ON versions(version_number);
CREATE INDEX idx_versions_status ON versions(status);

-- 出库单表添加版本号字段
ALTER TABLE outbound_orders ADD COLUMN IF NOT EXISTS version_id UUID REFERENCES versions(id);
CREATE INDEX IF NOT EXISTS idx_outbound_orders_version ON outbound_orders(version_id);

-- 序列号表添加文本字段
ALTER TABLE serial_numbers ADD COLUMN IF NOT EXISTS product_name_text TEXT;
ALTER TABLE serial_numbers ADD COLUMN IF NOT EXISTS product_code_text TEXT;

-- 创建销售合同表
CREATE TABLE IF NOT EXISTS sales_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_number TEXT NOT NULL UNIQUE,
  contract_name TEXT NOT NULL,
  customer_id UUID REFERENCES customers(id),
  customer_name TEXT,
  contract_amount DECIMAL(15,2),
  contract_date DATE,
  signing_date DATE,
  expiry_date DATE,
  file_url TEXT,
  file_name TEXT,
  status TEXT DEFAULT 'active', -- 'active', 'expired', 'terminated'
  ocr_data JSONB,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES profiles(id)
);

-- 创建索引
CREATE INDEX idx_contracts_number ON sales_contracts(contract_number);
CREATE INDEX idx_contracts_customer ON sales_contracts(customer_id);
CREATE INDEX idx_contracts_status ON sales_contracts(status);
CREATE INDEX idx_contracts_date ON sales_contracts(contract_date);

-- 创建发票管理表
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_type TEXT, -- '增值税专用发票', '增值税普通发票'
  invoice_code TEXT,
  customer_id UUID REFERENCES customers(id),
  customer_name TEXT,
  invoice_amount DECIMAL(15,2),
  tax_amount DECIMAL(15,2),
  total_amount DECIMAL(15,2),
  invoice_date DATE,
  file_url TEXT,
  file_name TEXT,
  status TEXT DEFAULT 'valid', -- 'valid', 'invalid', 'cancelled'
  ocr_data JSONB,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES profiles(id)
);

-- 创建索引
CREATE INDEX idx_invoices_number ON invoices(invoice_number);
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_date ON invoices(invoice_date);

-- RLS策略
ALTER TABLE versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- 版本管理策略
CREATE POLICY "所有人可以查看版本" ON versions FOR SELECT TO authenticated USING (true);
CREATE POLICY "管理员可以管理版本" ON versions FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 销售合同策略
CREATE POLICY "所有人可以查看合同" ON sales_contracts FOR SELECT TO authenticated USING (true);
CREATE POLICY "管理员可以管理合同" ON sales_contracts FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 发票策略
CREATE POLICY "所有人可以查看发票" ON invoices FOR SELECT TO authenticated USING (true);
CREATE POLICY "管理员可以管理发票" ON invoices FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 创建Storage bucket用于合同和发票文件
INSERT INTO storage.buckets (id, name, public) VALUES ('contracts', 'contracts', false) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('invoices', 'invoices', false) ON CONFLICT DO NOTHING;

-- Storage策略
CREATE POLICY "认证用户可以上传合同" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'contracts');
CREATE POLICY "认证用户可以查看合同" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'contracts');
CREATE POLICY "管理员可以删除合同" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'contracts' AND is_admin(auth.uid()));

CREATE POLICY "认证用户可以上传发票" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'invoices');
CREATE POLICY "认证用户可以查看发票" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'invoices');
CREATE POLICY "管理员可以删除发票" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'invoices' AND is_admin(auth.uid()));