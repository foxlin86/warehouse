-- 创建系统设置表
CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES profiles(id)
);

-- 创建索引
CREATE INDEX idx_settings_key ON settings(setting_key);

-- 插入默认配置
INSERT INTO settings (setting_key, setting_value, description) VALUES
  ('database_config', '{"host": "", "port": "", "database": "", "username": "", "password": ""}', '数据库连接配置'),
  ('ai_config', '{"provider": "bailian", "api_key": "", "api_url": "", "model": "qwen-max"}', 'AI模型配置'),
  ('ai_providers', '[
    {"id": "bailian", "name": "百炼大模型", "models": ["qwen-max", "qwen-plus", "qwen-turbo"]},
    {"id": "deepseek", "name": "DeepSeek", "models": ["deepseek-chat", "deepseek-coder"]},
    {"id": "openai", "name": "OpenAI", "models": ["gpt-4", "gpt-3.5-turbo"]},
    {"id": "custom", "name": "自定义API", "models": ["custom-model"]}
  ]', '支持的AI服务商列表')
ON CONFLICT (setting_key) DO NOTHING;

-- RLS策略
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- 管理员可以查看和修改所有设置
CREATE POLICY "管理员可以查看所有设置" ON settings
  FOR SELECT TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "管理员可以更新所有设置" ON settings
  FOR UPDATE TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- 所有认证用户可以查看AI服务商列表
CREATE POLICY "所有用户可以查看AI服务商列表" ON settings
  FOR SELECT TO authenticated
  USING (setting_key = 'ai_providers');