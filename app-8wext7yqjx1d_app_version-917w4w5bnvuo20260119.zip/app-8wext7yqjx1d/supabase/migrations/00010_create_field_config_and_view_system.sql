-- 创建应用表
CREATE TABLE IF NOT EXISTS applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  color TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建表格配置表
CREATE TABLE IF NOT EXISTS table_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID REFERENCES applications(id) ON DELETE CASCADE,
  table_name TEXT NOT NULL, -- 对应实际数据库表名
  display_name TEXT NOT NULL, -- 显示名称
  description TEXT,
  icon TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建字段配置表
CREATE TABLE IF NOT EXISTS field_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_config_id UUID REFERENCES table_configs(id) ON DELETE CASCADE,
  field_name TEXT NOT NULL, -- 对应数据库字段名
  display_name TEXT NOT NULL, -- 显示名称
  field_type TEXT NOT NULL, -- text, number, date, datetime, select, multi_select, relation, attachment, checkbox, url, email, phone, formula, created_time, updated_time, created_by, updated_by
  is_required BOOLEAN DEFAULT false,
  is_unique BOOLEAN DEFAULT false,
  is_primary BOOLEAN DEFAULT false, -- 是否为主字段
  default_value TEXT,
  options JSONB, -- 字段选项配置(如单选多选的选项、关联表配置等)
  validation JSONB, -- 验证规则
  description TEXT,
  sort_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT false, -- 是否为系统字段(不可删除)
  is_visible BOOLEAN DEFAULT true,
  width INTEGER DEFAULT 150, -- 列宽
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建视图配置表
CREATE TABLE IF NOT EXISTS view_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_config_id UUID REFERENCES table_configs(id) ON DELETE CASCADE,
  view_name TEXT NOT NULL,
  view_type TEXT NOT NULL, -- table, kanban, calendar, gallery, form
  is_default BOOLEAN DEFAULT false,
  config JSONB, -- 视图配置(显示字段、排序、筛选、分组等)
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建索引
CREATE INDEX idx_table_configs_app ON table_configs(application_id);
CREATE INDEX idx_field_configs_table ON field_configs(table_config_id);
CREATE INDEX idx_view_configs_table ON view_configs(table_config_id);

-- RLS策略
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE table_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE field_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE view_configs ENABLE ROW LEVEL SECURITY;

-- 所有人可以查看
CREATE POLICY "所有人可以查看应用" ON applications FOR SELECT TO authenticated USING (true);
CREATE POLICY "所有人可以查看表格配置" ON table_configs FOR SELECT TO authenticated USING (true);
CREATE POLICY "所有人可以查看字段配置" ON field_configs FOR SELECT TO authenticated USING (true);
CREATE POLICY "所有人可以查看视图配置" ON view_configs FOR SELECT TO authenticated USING (true);

-- 管理员可以管理
CREATE POLICY "管理员可以管理应用" ON applications FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员可以管理表格配置" ON table_configs FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员可以管理字段配置" ON field_configs FOR ALL TO authenticated USING (is_admin(auth.uid()));
CREATE POLICY "管理员可以管理视图配置" ON view_configs FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 插入默认应用和配置
INSERT INTO applications (name, description, icon, color) VALUES 
('库存管理', '医疗设备库存管理系统', '📦', '#3b82f6')
ON CONFLICT DO NOTHING;

-- 获取应用ID
DO $$
DECLARE
  app_id UUID;
  inbound_table_id UUID;
  outbound_table_id UUID;
  product_table_id UUID;
BEGIN
  SELECT id INTO app_id FROM applications WHERE name = '库存管理' LIMIT 1;
  
  -- 创建入库管理表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'inbound_orders', '入库管理', '管理所有入库单据', '📥')
  RETURNING id INTO inbound_table_id;
  
  -- 创建出库管理表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'outbound_orders', '出库管理', '管理所有出库单据', '📤')
  RETURNING id INTO outbound_table_id;
  
  -- 创建产品管理表配置
  INSERT INTO table_configs (application_id, table_name, display_name, description, icon)
  VALUES (app_id, 'products', '产品管理', '管理所有产品信息', '📦')
  RETURNING id INTO product_table_id;
  
  -- 为入库管理创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, sort_order) VALUES
  (inbound_table_id, 'order_number', '入库单号', 'text', true, true, true, 1),
  (inbound_table_id, 'order_type', '入库类型', 'select', true, false, false, 2),
  (inbound_table_id, 'order_date', '入库日期', 'date', true, false, false, 3),
  (inbound_table_id, 'supplier_id', '供应商', 'relation', false, false, false, 4),
  (inbound_table_id, 'status', '状态', 'select', true, true, false, 5),
  (inbound_table_id, 'notes', '备注', 'text', false, false, false, 6),
  (inbound_table_id, 'created_at', '创建时间', 'created_time', false, true, false, 7);
  
  -- 为出库管理创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, sort_order) VALUES
  (outbound_table_id, 'order_number', '出库单号', 'text', true, true, true, 1),
  (outbound_table_id, 'order_type', '出库类型', 'select', true, false, false, 2),
  (outbound_table_id, 'order_date', '出库日期', 'date', true, false, false, 3),
  (outbound_table_id, 'customer_id', '客户', 'relation', false, false, false, 4),
  (outbound_table_id, 'version_id', '软件版本', 'relation', false, false, false, 5),
  (outbound_table_id, 'status', '状态', 'select', true, true, false, 6),
  (outbound_table_id, 'notes', '备注', 'text', false, false, false, 7),
  (outbound_table_id, 'created_at', '创建时间', 'created_time', false, true, false, 8);
  
  -- 为产品管理创建字段配置
  INSERT INTO field_configs (table_config_id, field_name, display_name, field_type, is_required, is_system, is_primary, sort_order) VALUES
  (product_table_id, 'code', '产品编号', 'text', true, true, true, 1),
  (product_table_id, 'name', '产品名称', 'text', true, false, false, 2),
  (product_table_id, 'specifications', '规格型号', 'text', false, false, false, 3),
  (product_table_id, 'unit', '单位', 'text', false, false, false, 4),
  (product_table_id, 'manufacturer', '生产企业', 'text', false, false, false, 5),
  (product_table_id, 'created_at', '创建时间', 'created_time', false, true, false, 6);
  
  -- 创建默认视图
  INSERT INTO view_configs (table_config_id, view_name, view_type, is_default, config) VALUES
  (inbound_table_id, '所有入库单', 'table', true, '{"sort": [{"field": "created_at", "order": "desc"}]}'),
  (outbound_table_id, '所有出库单', 'table', true, '{"sort": [{"field": "created_at", "order": "desc"}]}'),
  (product_table_id, '所有产品', 'table', true, '{"sort": [{"field": "code", "order": "asc"}]}');
END $$;